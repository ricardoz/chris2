
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks818139 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818139");

var horseLinks817075 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817075","http://www.racingpost.com/horses/result_home.sd?race_id=559725");

var horseLinks802549 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802549","http://www.racingpost.com/horses/result_home.sd?race_id=560106");

var horseLinks805248 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805248");

var horseLinks810142 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810142","http://www.racingpost.com/horses/result_home.sd?race_id=560019");

var horseLinks818132 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818132");

var horseLinks813975 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813975","http://www.racingpost.com/horses/result_home.sd?race_id=557406","http://www.racingpost.com/horses/result_home.sd?race_id=559268");

var horseLinks817374 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817374","http://www.racingpost.com/horses/result_home.sd?race_id=560067");

var horseLinks815837 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815837","http://www.racingpost.com/horses/result_home.sd?race_id=558587","http://www.racingpost.com/horses/result_home.sd?race_id=559994");

var horseLinks817953 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817953");

var horseLinks816245 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816245","http://www.racingpost.com/horses/result_home.sd?race_id=559670","http://www.racingpost.com/horses/result_home.sd?race_id=560116");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562384" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562384" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Sovereign+Power&id=818139&rnumber=562384" <?php $thisId=818139; include("markHorse.php");?>>Sovereign Power</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Storming&id=817075&rnumber=562384" <?php $thisId=817075; include("markHorse.php");?>>Storming</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=The+Gatling+Boy&id=802549&rnumber=562384" <?php $thisId=802549; include("markHorse.php");?>>The Gatling Boy</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lucky+Black+Star&id=805248&rnumber=562384" <?php $thisId=805248; include("markHorse.php");?>>Lucky Black Star</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Vallarta&id=810142&rnumber=562384" <?php $thisId=810142; include("markHorse.php");?>>Vallarta</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=North+Weald&id=818132&rnumber=562384" <?php $thisId=818132; include("markHorse.php");?>>North Weald</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Swift+Cedar&id=813975&rnumber=562384" <?php $thisId=813975; include("markHorse.php");?>>Swift Cedar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Clear+Loch&id=817374&rnumber=562384" <?php $thisId=817374; include("markHorse.php");?>>Clear Loch</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Muskat+Link&id=815837&rnumber=562384" <?php $thisId=815837; include("markHorse.php");?>>Muskat Link</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sakhee's+Rose&id=817953&rnumber=562384" <?php $thisId=817953; include("markHorse.php");?>>Sakhee's Rose</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Just+Duchess&id=816245&rnumber=562384" <?php $thisId=816245; include("markHorse.php");?>>Just Duchess</a></li>

<ol> 
</ol> 
</ol>