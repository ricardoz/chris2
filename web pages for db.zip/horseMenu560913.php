
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks765310 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=765310","http://www.racingpost.com/horses/result_home.sd?race_id=512364","http://www.racingpost.com/horses/result_home.sd?race_id=513399","http://www.racingpost.com/horses/result_home.sd?race_id=514454","http://www.racingpost.com/horses/result_home.sd?race_id=527630","http://www.racingpost.com/horses/result_home.sd?race_id=530326","http://www.racingpost.com/horses/result_home.sd?race_id=531836","http://www.racingpost.com/horses/result_home.sd?race_id=534007","http://www.racingpost.com/horses/result_home.sd?race_id=534882","http://www.racingpost.com/horses/result_home.sd?race_id=536500","http://www.racingpost.com/horses/result_home.sd?race_id=537260","http://www.racingpost.com/horses/result_home.sd?race_id=547308","http://www.racingpost.com/horses/result_home.sd?race_id=548214","http://www.racingpost.com/horses/result_home.sd?race_id=548611","http://www.racingpost.com/horses/result_home.sd?race_id=553269","http://www.racingpost.com/horses/result_home.sd?race_id=554400","http://www.racingpost.com/horses/result_home.sd?race_id=556276","http://www.racingpost.com/horses/result_home.sd?race_id=559148","http://www.racingpost.com/horses/result_home.sd?race_id=559735");

var horseLinks306877 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=306877","http://www.racingpost.com/horses/result_home.sd?race_id=529673","http://www.racingpost.com/horses/result_home.sd?race_id=531178","http://www.racingpost.com/horses/result_home.sd?race_id=534005","http://www.racingpost.com/horses/result_home.sd?race_id=535269","http://www.racingpost.com/horses/result_home.sd?race_id=537253","http://www.racingpost.com/horses/result_home.sd?race_id=538039","http://www.racingpost.com/horses/result_home.sd?race_id=538549","http://www.racingpost.com/horses/result_home.sd?race_id=551638","http://www.racingpost.com/horses/result_home.sd?race_id=555119","http://www.racingpost.com/horses/result_home.sd?race_id=557464","http://www.racingpost.com/horses/result_home.sd?race_id=559148","http://www.racingpost.com/horses/result_home.sd?race_id=559722","http://www.racingpost.com/horses/result_home.sd?race_id=560609");

var horseLinks793659 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793659","http://www.racingpost.com/horses/result_home.sd?race_id=538406","http://www.racingpost.com/horses/result_home.sd?race_id=551136","http://www.racingpost.com/horses/result_home.sd?race_id=556278","http://www.racingpost.com/horses/result_home.sd?race_id=559686","http://www.racingpost.com/horses/result_home.sd?race_id=560465");

var horseLinks793786 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793786","http://www.racingpost.com/horses/result_home.sd?race_id=539704","http://www.racingpost.com/horses/result_home.sd?race_id=540359","http://www.racingpost.com/horses/result_home.sd?race_id=543159","http://www.racingpost.com/horses/result_home.sd?race_id=558075","http://www.racingpost.com/horses/result_home.sd?race_id=558611","http://www.racingpost.com/horses/result_home.sd?race_id=559982");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560913" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560913" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Mojolika&id=765310&rnumber=560913" <?php $thisId=765310; include("markHorse.php");?>>Mojolika</a></li>

<ol> 
<li><a href="horse.php?name=Mojolika&id=765310&rnumber=560913&url=/horses/result_home.sd?race_id=559148" id='h2hFormLink'>Moon Trip </a></li> 
</ol> 
<li> <a href="horse.php?name=Moon+Trip&id=306877&rnumber=560913" <?php $thisId=306877; include("markHorse.php");?>>Moon Trip</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Gabrial's+Star&id=793659&rnumber=560913" <?php $thisId=793659; include("markHorse.php");?>>Gabrial's Star</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Yours+Ever&id=793786&rnumber=560913" <?php $thisId=793786; include("markHorse.php");?>>Yours Ever</a></li>

<ol> 
</ol> 
</ol>