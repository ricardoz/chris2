<html><head>
<?php

/*start the session*/

session_start();

/*redirect if not logged in*/

if (!isset($_COOKIE['userId']))

{



echo "<META HTTP-EQUIV='Refresh' Content='0; URL=homepage.php'/> "; 

} else if (isset($_COOKIE['username'])){ 

$_SESSION['username'] = $_COOKIE['username'];

}

?>
<title><?php echo $_GET['name'];?></title><link rel="stylesheet" type="text/css" href="layout.php" >
<?php include("handleResponse.library.php");

/*get functions*/

include ("database.library.php");

?>


</head><body>
<?php



/*set variables*/

$horse = $_GET['name'];;

$userID = $_COOKIE['userId'];

/*$userID = 5;*/

$database = "a1270291_racing";

$note ='';



/*$getHorseIDQuery=

" SELECT id

FROM runners

WHERE name = '" .$horse. "';";



$horseID = getHorseID($horse, $getHorseIDQuery);*/

$horseID = $_GET['id'];



$insertHorseQuery =

"INSERT INTO runners

VALUES (null, '" .$horse. "')";



$getHorseNotes =

"SELECT notes

FROM notes

WHERE Horse_ID='" .$horseID . "'AND User_ID = '" .$userID ."';";



$insertNoteQuery =

"INSERT INTO notes

VALUES ('" .$horseID . "','".$userID . "','".$note ."')";

$updateNoteQuery =

"UPDATE notes SET notes = '" .$note. "' WHERE Horse_ID='" .$horseID.

"'AND User_ID = '" .$userID . "';";





$connection = getConnection()

or die ('Could not connect: '.MYSQL_ERROR());



MYSQL_SELECT_DB($database,$connection)

or die('Could not connect: '.mysql_error());



mysql_select_db($database,$connection)

or die('Error in selecting the database:'.mysql_error());

?>

<div id = 'raceMenuDiv'>

<?php

$horseMenu = "horseMenu" . $_GET['rnumber'] . ".php";

include($horseMenu);



?>
</div>
<div id='raceMainDiv'>

<form method='get' action='hiddenFrame.php'target='hiddenFrame' id='saveHorseNoteForm'>
<textarea name='horseNote' id='horseNote' cols='70' rows='25'><?php
if (queryIsNull($getHorseNotes)){
 echo "no note";
} else {
$result = getResult($getHorseNotes);
$row=mysql_fetch_array($result);
echo $row[0];
}?></textarea>
<input type='hidden' name='horse' <?php echo "value='" . $horse . "'>";?>

<br>

<input id = 'saveNote' type='submit' name='saveNote' value='Save'>

</form>

<script type='text/javascript'>

function handleResponse(){

alert('this function is called from server.html');

}

var counter = 0;

var horseLinks = horseLinks<?php echo $_GET['id'];?>;

function findIndex(arr,obj) {
 	var ind = arr.indexOf(obj);
 	if (ind > -1){
		return ind;
	} else {
		return counter;
	}
    
}


//alert(horseLinks);

 <?php include ("updateIframe.php");?>

</script>

<?php

include("horseCarouselTable.php");

if (isset($_GET['url']))

{

$url = "http://www.racingpost.com/" . $_GET['url'];

echo "<script type='text/javascript'>";
echo "counter = findIndex(horseLinks,'" . $url ."');\n" ;
echo "window.onload=alert(counter);";
echo "</script>";

} else {

$url ='http://www.racingpost.com/horses/horse_home.sd?horse_id=' . $horseID;

}

echo

"

<iframe name=horseFrame src =$url height = 100% width = 100% frameborder = 1 scrolling = yes>

</iframe>

";?>

</div>
</body> 
</html> 
