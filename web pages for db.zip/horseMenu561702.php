
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks766696 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=766696","http://www.racingpost.com/horses/result_home.sd?race_id=513478","http://www.racingpost.com/horses/result_home.sd?race_id=514158","http://www.racingpost.com/horses/result_home.sd?race_id=529009","http://www.racingpost.com/horses/result_home.sd?race_id=530428","http://www.racingpost.com/horses/result_home.sd?race_id=531944","http://www.racingpost.com/horses/result_home.sd?race_id=533988","http://www.racingpost.com/horses/result_home.sd?race_id=534156","http://www.racingpost.com/horses/result_home.sd?race_id=535248","http://www.racingpost.com/horses/result_home.sd?race_id=552460","http://www.racingpost.com/horses/result_home.sd?race_id=556909","http://www.racingpost.com/horses/result_home.sd?race_id=557239","http://www.racingpost.com/horses/result_home.sd?race_id=558197","http://www.racingpost.com/horses/result_home.sd?race_id=558724","http://www.racingpost.com/horses/result_home.sd?race_id=560110","http://www.racingpost.com/horses/result_home.sd?race_id=560409");

var horseLinks808376 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=808376","http://www.racingpost.com/horses/result_home.sd?race_id=553781","http://www.racingpost.com/horses/result_home.sd?race_id=554381","http://www.racingpost.com/horses/result_home.sd?race_id=555792","http://www.racingpost.com/horses/result_home.sd?race_id=556909","http://www.racingpost.com/horses/result_home.sd?race_id=557525","http://www.racingpost.com/horses/result_home.sd?race_id=558727","http://www.racingpost.com/horses/result_home.sd?race_id=560110","http://www.racingpost.com/horses/result_home.sd?race_id=560590","http://www.racingpost.com/horses/result_home.sd?race_id=561317");

var horseLinks774552 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=774552","http://www.racingpost.com/horses/result_home.sd?race_id=553172","http://www.racingpost.com/horses/result_home.sd?race_id=556902","http://www.racingpost.com/horses/result_home.sd?race_id=558161","http://www.racingpost.com/horses/result_home.sd?race_id=560035");

var horseLinks816199 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816199","http://www.racingpost.com/horses/result_home.sd?race_id=560110");

var horseLinks790677 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790677","http://www.racingpost.com/horses/result_home.sd?race_id=536072","http://www.racingpost.com/horses/result_home.sd?race_id=552450","http://www.racingpost.com/horses/result_home.sd?race_id=554294","http://www.racingpost.com/horses/result_home.sd?race_id=556314","http://www.racingpost.com/horses/result_home.sd?race_id=559170","http://www.racingpost.com/horses/result_home.sd?race_id=560616","http://www.racingpost.com/horses/result_home.sd?race_id=560979","http://www.racingpost.com/horses/result_home.sd?race_id=561427");

var horseLinks793663 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793663","http://www.racingpost.com/horses/result_home.sd?race_id=538381","http://www.racingpost.com/horses/result_home.sd?race_id=539336","http://www.racingpost.com/horses/result_home.sd?race_id=546109","http://www.racingpost.com/horses/result_home.sd?race_id=546493","http://www.racingpost.com/horses/result_home.sd?race_id=548493","http://www.racingpost.com/horses/result_home.sd?race_id=553695","http://www.racingpost.com/horses/result_home.sd?race_id=556898","http://www.racingpost.com/horses/result_home.sd?race_id=556933","http://www.racingpost.com/horses/result_home.sd?race_id=558064","http://www.racingpost.com/horses/result_home.sd?race_id=558200","http://www.racingpost.com/horses/result_home.sd?race_id=559737","http://www.racingpost.com/horses/result_home.sd?race_id=561260");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561702" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561702" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Face+East&id=766696&rnumber=561702" <?php $thisId=766696; include("markHorse.php");?>>Face East</a></li>

<ol> 
<li><a href="horse.php?name=Face+East&id=766696&rnumber=561702&url=/horses/result_home.sd?race_id=556909" id='h2hFormLink'>Dragon Spirit </a></li> 
<li><a href="horse.php?name=Face+East&id=766696&rnumber=561702&url=/horses/result_home.sd?race_id=560110" id='h2hFormLink'>Dragon Spirit </a></li> 
<li><a href="horse.php?name=Face+East&id=766696&rnumber=561702&url=/horses/result_home.sd?race_id=560110" id='h2hFormLink'>Roseisle </a></li> 
</ol> 
<li> <a href="horse.php?name=Dragon+Spirit&id=808376&rnumber=561702" <?php $thisId=808376; include("markHorse.php");?>>Dragon Spirit</a></li>

<ol> 
<li><a href="horse.php?name=Dragon+Spirit&id=808376&rnumber=561702&url=/horses/result_home.sd?race_id=560110" id='h2hFormLink'>Roseisle </a></li> 
</ol> 
<li> <a href="horse.php?name=Legal+Bond&id=774552&rnumber=561702" <?php $thisId=774552; include("markHorse.php");?>>Legal Bond</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Roseisle&id=816199&rnumber=561702" <?php $thisId=816199; include("markHorse.php");?>>Roseisle</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sabore&id=790677&rnumber=561702" <?php $thisId=790677; include("markHorse.php");?>>Sabore</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Script&id=793663&rnumber=561702" <?php $thisId=793663; include("markHorse.php");?>>Script</a></li>

<ol> 
</ol> 
</ol>