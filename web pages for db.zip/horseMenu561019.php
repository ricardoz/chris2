
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks727434 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=727434","http://www.racingpost.com/horses/result_home.sd?race_id=477463","http://www.racingpost.com/horses/result_home.sd?race_id=4802834","http://www.racingpost.com/horses/result_home.sd?race_id=482097","http://www.racingpost.com/horses/result_home.sd?race_id=494929","http://www.racingpost.com/horses/result_home.sd?race_id=510617","http://www.racingpost.com/horses/result_home.sd?race_id=514620","http://www.racingpost.com/horses/result_home.sd?race_id=515316","http://www.racingpost.com/horses/result_home.sd?race_id=515765","http://www.racingpost.com/horses/result_home.sd?race_id=521678","http://www.racingpost.com/horses/result_home.sd?race_id=539796","http://www.racingpost.com/horses/result_home.sd?race_id=553216","http://www.racingpost.com/horses/result_home.sd?race_id=556314");

var horseLinks763421 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=763421","http://www.racingpost.com/horses/result_home.sd?race_id=529829","http://www.racingpost.com/horses/result_home.sd?race_id=555766","http://www.racingpost.com/horses/result_home.sd?race_id=558589","http://www.racingpost.com/horses/result_home.sd?race_id=560094");

var horseLinks818033 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818033","http://www.racingpost.com/horses/result_home.sd?race_id=560906");

var horseLinks796845 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=796845","http://www.racingpost.com/horses/result_home.sd?race_id=540508","http://www.racingpost.com/horses/result_home.sd?race_id=559243","http://www.racingpost.com/horses/result_home.sd?race_id=559358");

var horseLinks810782 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810782","http://www.racingpost.com/horses/result_home.sd?race_id=555005","http://www.racingpost.com/horses/result_home.sd?race_id=555303","http://www.racingpost.com/horses/result_home.sd?race_id=557409","http://www.racingpost.com/horses/result_home.sd?race_id=559661");

var horseLinks816647 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816647","http://www.racingpost.com/horses/result_home.sd?race_id=560094","http://www.racingpost.com/horses/result_home.sd?race_id=560771");

var horseLinks788236 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=788236","http://www.racingpost.com/horses/result_home.sd?race_id=533625","http://www.racingpost.com/horses/result_home.sd?race_id=559235");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561019" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561019" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Alaskan+Prince&id=727434&rnumber=561019" <?php $thisId=727434; include("markHorse.php");?>>Alaskan Prince</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=All+Time&id=763421&rnumber=561019" <?php $thisId=763421; include("markHorse.php");?>>All Time</a></li>

<ol> 
<li><a href="horse.php?name=All+Time&id=763421&rnumber=561019&url=/horses/result_home.sd?race_id=560094" id='h2hFormLink'>Eamaadd </a></li> 
</ol> 
<li> <a href="horse.php?name=Lady+Oz&id=818033&rnumber=561019" <?php $thisId=818033; include("markHorse.php");?>>Lady Oz</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Alraased&id=796845&rnumber=561019" <?php $thisId=796845; include("markHorse.php");?>>Alraased</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cool+Sky&id=810782&rnumber=561019" <?php $thisId=810782; include("markHorse.php");?>>Cool Sky</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Eamaadd&id=816647&rnumber=561019" <?php $thisId=816647; include("markHorse.php");?>>Eamaadd</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sunnybridge+Boy&id=788236&rnumber=561019" <?php $thisId=788236; include("markHorse.php");?>>Sunnybridge Boy</a></li>

<ol> 
</ol> 
</ol>