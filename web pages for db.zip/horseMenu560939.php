
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks696037 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=696037","http://www.racingpost.com/horses/result_home.sd?race_id=447420","http://www.racingpost.com/horses/result_home.sd?race_id=450584","http://www.racingpost.com/horses/result_home.sd?race_id=480794","http://www.racingpost.com/horses/result_home.sd?race_id=513685","http://www.racingpost.com/horses/result_home.sd?race_id=514044","http://www.racingpost.com/horses/result_home.sd?race_id=515523","http://www.racingpost.com/horses/result_home.sd?race_id=515965","http://www.racingpost.com/horses/result_home.sd?race_id=518400","http://www.racingpost.com/horses/result_home.sd?race_id=533822","http://www.racingpost.com/horses/result_home.sd?race_id=535991","http://www.racingpost.com/horses/result_home.sd?race_id=536361","http://www.racingpost.com/horses/result_home.sd?race_id=537491","http://www.racingpost.com/horses/result_home.sd?race_id=538220","http://www.racingpost.com/horses/result_home.sd?race_id=541188","http://www.racingpost.com/horses/result_home.sd?race_id=541871","http://www.racingpost.com/horses/result_home.sd?race_id=543316","http://www.racingpost.com/horses/result_home.sd?race_id=544462","http://www.racingpost.com/horses/result_home.sd?race_id=545216","http://www.racingpost.com/horses/result_home.sd?race_id=546999","http://www.racingpost.com/horses/result_home.sd?race_id=550746","http://www.racingpost.com/horses/result_home.sd?race_id=554680","http://www.racingpost.com/horses/result_home.sd?race_id=558790");

var horseLinks746799 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=746799","http://www.racingpost.com/horses/result_home.sd?race_id=493402","http://www.racingpost.com/horses/result_home.sd?race_id=496813","http://www.racingpost.com/horses/result_home.sd?race_id=499726","http://www.racingpost.com/horses/result_home.sd?race_id=502972","http://www.racingpost.com/horses/result_home.sd?race_id=505097","http://www.racingpost.com/horses/result_home.sd?race_id=528413","http://www.racingpost.com/horses/result_home.sd?race_id=530530","http://www.racingpost.com/horses/result_home.sd?race_id=534178","http://www.racingpost.com/horses/result_home.sd?race_id=534604","http://www.racingpost.com/horses/result_home.sd?race_id=537324","http://www.racingpost.com/horses/result_home.sd?race_id=538820","http://www.racingpost.com/horses/result_home.sd?race_id=553847","http://www.racingpost.com/horses/result_home.sd?race_id=555154","http://www.racingpost.com/horses/result_home.sd?race_id=559771","http://www.racingpost.com/horses/result_home.sd?race_id=560426");

var horseLinks787363 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=787363","http://www.racingpost.com/horses/result_home.sd?race_id=532979");

var horseLinks747934 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=747934","http://www.racingpost.com/horses/result_home.sd?race_id=495226","http://www.racingpost.com/horses/result_home.sd?race_id=514605","http://www.racingpost.com/horses/result_home.sd?race_id=515337","http://www.racingpost.com/horses/result_home.sd?race_id=517099","http://www.racingpost.com/horses/result_home.sd?race_id=523414","http://www.racingpost.com/horses/result_home.sd?race_id=524018","http://www.racingpost.com/horses/result_home.sd?race_id=524127","http://www.racingpost.com/horses/result_home.sd?race_id=525543","http://www.racingpost.com/horses/result_home.sd?race_id=527161","http://www.racingpost.com/horses/result_home.sd?race_id=528413","http://www.racingpost.com/horses/result_home.sd?race_id=529092","http://www.racingpost.com/horses/result_home.sd?race_id=531344","http://www.racingpost.com/horses/result_home.sd?race_id=534161","http://www.racingpost.com/horses/result_home.sd?race_id=535052","http://www.racingpost.com/horses/result_home.sd?race_id=535816","http://www.racingpost.com/horses/result_home.sd?race_id=536981","http://www.racingpost.com/horses/result_home.sd?race_id=537346","http://www.racingpost.com/horses/result_home.sd?race_id=554483","http://www.racingpost.com/horses/result_home.sd?race_id=557016","http://www.racingpost.com/horses/result_home.sd?race_id=558203","http://www.racingpost.com/horses/result_home.sd?race_id=559322","http://www.racingpost.com/horses/result_home.sd?race_id=560186");

var horseLinks756743 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=756743","http://www.racingpost.com/horses/result_home.sd?race_id=503682","http://www.racingpost.com/horses/result_home.sd?race_id=507719","http://www.racingpost.com/horses/result_home.sd?race_id=511351","http://www.racingpost.com/horses/result_home.sd?race_id=512832","http://www.racingpost.com/horses/result_home.sd?race_id=514574","http://www.racingpost.com/horses/result_home.sd?race_id=533160","http://www.racingpost.com/horses/result_home.sd?race_id=539046","http://www.racingpost.com/horses/result_home.sd?race_id=542818","http://www.racingpost.com/horses/result_home.sd?race_id=561875");

var horseLinks813215 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813215","http://www.racingpost.com/horses/result_home.sd?race_id=556928");

var horseLinks795613 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795613","http://www.racingpost.com/horses/result_home.sd?race_id=540073","http://www.racingpost.com/horses/result_home.sd?race_id=554365","http://www.racingpost.com/horses/result_home.sd?race_id=559621");

var horseLinks773545 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=773545","http://www.racingpost.com/horses/result_home.sd?race_id=559212","http://www.racingpost.com/horses/result_home.sd?race_id=559621","http://www.racingpost.com/horses/result_home.sd?race_id=560426");

var horseLinks792947 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792947","http://www.racingpost.com/horses/result_home.sd?race_id=538309","http://www.racingpost.com/horses/result_home.sd?race_id=553785","http://www.racingpost.com/horses/result_home.sd?race_id=558092");

var horseLinks816581 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816581","http://www.racingpost.com/horses/result_home.sd?race_id=559212","http://www.racingpost.com/horses/result_home.sd?race_id=560094");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560939" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560939" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Father+Shine&id=696037&rnumber=560939" <?php $thisId=696037; include("markHorse.php");?>>Father Shine</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mr+Tallyman&id=746799&rnumber=560939" <?php $thisId=746799; include("markHorse.php");?>>Mr Tallyman</a></li>

<ol> 
<li><a href="horse.php?name=Mr+Tallyman&id=746799&rnumber=560939&url=/horses/result_home.sd?race_id=528413" id='h2hFormLink'>The Tiddly Tadpole </a></li> 
<li><a href="horse.php?name=Mr+Tallyman&id=746799&rnumber=560939&url=/horses/result_home.sd?race_id=560426" id='h2hFormLink'>Cottesmore </a></li> 
</ol> 
<li> <a href="horse.php?name=Roubiliac&id=787363&rnumber=560939" <?php $thisId=787363; include("markHorse.php");?>>Roubiliac</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=The+Tiddly+Tadpole&id=747934&rnumber=560939" <?php $thisId=747934; include("markHorse.php");?>>The Tiddly Tadpole</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Muzey's+Princess&id=756743&rnumber=560939" <?php $thisId=756743; include("markHorse.php");?>>Muzey's Princess</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Showmehow&id=813215&rnumber=560939" <?php $thisId=813215; include("markHorse.php");?>>Showmehow</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Al+Mamzar&id=795613&rnumber=560939" <?php $thisId=795613; include("markHorse.php");?>>Al Mamzar</a></li>

<ol> 
<li><a href="horse.php?name=Al+Mamzar&id=795613&rnumber=560939&url=/horses/result_home.sd?race_id=559621" id='h2hFormLink'>Cottesmore </a></li> 
</ol> 
<li> <a href="horse.php?name=Cottesmore&id=773545&rnumber=560939" <?php $thisId=773545; include("markHorse.php");?>>Cottesmore</a></li>

<ol> 
<li><a href="horse.php?name=Cottesmore&id=773545&rnumber=560939&url=/horses/result_home.sd?race_id=559212" id='h2hFormLink'>Shatin Spirit </a></li> 
</ol> 
<li> <a href="horse.php?name=Galleon&id=792947&rnumber=560939" <?php $thisId=792947; include("markHorse.php");?>>Galleon</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Shatin+Spirit&id=816581&rnumber=560939" <?php $thisId=816581; include("markHorse.php");?>>Shatin Spirit</a></li>

<ol> 
</ol> 
</ol>