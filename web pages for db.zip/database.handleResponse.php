<script type="text/javascript">
function displayMessage(message)
{
alert(message);
}
</script>