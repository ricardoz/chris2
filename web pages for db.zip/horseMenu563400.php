
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks717373 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=717373","http://www.racingpost.com/horses/result_home.sd?race_id=467529","http://www.racingpost.com/horses/result_home.sd?race_id=482766","http://www.racingpost.com/horses/result_home.sd?race_id=484633","http://www.racingpost.com/horses/result_home.sd?race_id=487123","http://www.racingpost.com/horses/result_home.sd?race_id=488231","http://www.racingpost.com/horses/result_home.sd?race_id=489659","http://www.racingpost.com/horses/result_home.sd?race_id=507232","http://www.racingpost.com/horses/result_home.sd?race_id=533753","http://www.racingpost.com/horses/result_home.sd?race_id=535476","http://www.racingpost.com/horses/result_home.sd?race_id=537429","http://www.racingpost.com/horses/result_home.sd?race_id=538898","http://www.racingpost.com/horses/result_home.sd?race_id=539549","http://www.racingpost.com/horses/result_home.sd?race_id=540281","http://www.racingpost.com/horses/result_home.sd?race_id=555288","http://www.racingpost.com/horses/result_home.sd?race_id=557176","http://www.racingpost.com/horses/result_home.sd?race_id=560213","http://www.racingpost.com/horses/result_home.sd?race_id=561535","http://www.racingpost.com/horses/result_home.sd?race_id=562660");

var horseLinks788825 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=788825","http://www.racingpost.com/horses/result_home.sd?race_id=535541","http://www.racingpost.com/horses/result_home.sd?race_id=563353","http://www.racingpost.com/horses/result_home.sd?race_id=563354");

var horseLinks687951 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=687951","http://www.racingpost.com/horses/result_home.sd?race_id=465927","http://www.racingpost.com/horses/result_home.sd?race_id=490478","http://www.racingpost.com/horses/result_home.sd?race_id=499561","http://www.racingpost.com/horses/result_home.sd?race_id=514284","http://www.racingpost.com/horses/result_home.sd?race_id=514337","http://www.racingpost.com/horses/result_home.sd?race_id=539164","http://www.racingpost.com/horses/result_home.sd?race_id=563353","http://www.racingpost.com/horses/result_home.sd?race_id=563354");

var horseLinks819278 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819278","http://www.racingpost.com/horses/result_home.sd?race_id=563354");

var horseLinks819280 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819280","http://www.racingpost.com/horses/result_home.sd?race_id=563353");

var horseLinks766947 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=766947","http://www.racingpost.com/horses/result_home.sd?race_id=515069","http://www.racingpost.com/horses/result_home.sd?race_id=515902","http://www.racingpost.com/horses/result_home.sd?race_id=516755","http://www.racingpost.com/horses/result_home.sd?race_id=517559","http://www.racingpost.com/horses/result_home.sd?race_id=525650","http://www.racingpost.com/horses/result_home.sd?race_id=526704","http://www.racingpost.com/horses/result_home.sd?race_id=527883","http://www.racingpost.com/horses/result_home.sd?race_id=528532","http://www.racingpost.com/horses/result_home.sd?race_id=529163","http://www.racingpost.com/horses/result_home.sd?race_id=530676","http://www.racingpost.com/horses/result_home.sd?race_id=539398","http://www.racingpost.com/horses/result_home.sd?race_id=539889","http://www.racingpost.com/horses/result_home.sd?race_id=539890","http://www.racingpost.com/horses/result_home.sd?race_id=539891","http://www.racingpost.com/horses/result_home.sd?race_id=539892","http://www.racingpost.com/horses/result_home.sd?race_id=539893","http://www.racingpost.com/horses/result_home.sd?race_id=540533","http://www.racingpost.com/horses/result_home.sd?race_id=554419","http://www.racingpost.com/horses/result_home.sd?race_id=555584","http://www.racingpost.com/horses/result_home.sd?race_id=556905","http://www.racingpost.com/horses/result_home.sd?race_id=558731","http://www.racingpost.com/horses/result_home.sd?race_id=560015");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=563400" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=563400" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Flamingo+Fantasy&id=717373&rnumber=563400" <?php $thisId=717373; include("markHorse.php");?>>Flamingo Fantasy</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hanbes&id=788825&rnumber=563400" <?php $thisId=788825; include("markHorse.php");?>>Hanbes</a></li>

<ol> 
<li><a href="horse.php?name=Hanbes&id=788825&rnumber=563400&url=/horses/result_home.sd?race_id=563353" id='h2hFormLink'>Inspector </a></li> 
<li><a href="horse.php?name=Hanbes&id=788825&rnumber=563400&url=/horses/result_home.sd?race_id=563354" id='h2hFormLink'>Inspector </a></li> 
<li><a href="horse.php?name=Hanbes&id=788825&rnumber=563400&url=/horses/result_home.sd?race_id=563354" id='h2hFormLink'>Kutbey </a></li> 
<li><a href="horse.php?name=Hanbes&id=788825&rnumber=563400&url=/horses/result_home.sd?race_id=563353" id='h2hFormLink'>Mitico </a></li> 
</ol> 
<li> <a href="horse.php?name=Inspector&id=687951&rnumber=563400" <?php $thisId=687951; include("markHorse.php");?>>Inspector</a></li>

<ol> 
<li><a href="horse.php?name=Inspector&id=687951&rnumber=563400&url=/horses/result_home.sd?race_id=563354" id='h2hFormLink'>Kutbey </a></li> 
<li><a href="horse.php?name=Inspector&id=687951&rnumber=563400&url=/horses/result_home.sd?race_id=563353" id='h2hFormLink'>Mitico </a></li> 
</ol> 
<li> <a href="horse.php?name=Kutbey&id=819278&rnumber=563400" <?php $thisId=819278; include("markHorse.php");?>>Kutbey</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mitico&id=819280&rnumber=563400" <?php $thisId=819280; include("markHorse.php");?>>Mitico</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Retrieve&id=766947&rnumber=563400" <?php $thisId=766947; include("markHorse.php");?>>Retrieve</a></li>

<ol> 
</ol> 
</ol>