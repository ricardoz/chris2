
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks805359 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805359","http://www.racingpost.com/horses/result_home.sd?race_id=560087");

var horseLinks817822 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817822","http://www.racingpost.com/horses/result_home.sd?race_id=560963");

var horseLinks817814 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817814","http://www.racingpost.com/horses/result_home.sd?race_id=560574");

var horseLinks802535 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802535");

var horseLinks800133 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800133");

var horseLinks817815 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817815","http://www.racingpost.com/horses/result_home.sd?race_id=560574");

var horseLinks800367 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800367","http://www.racingpost.com/horses/result_home.sd?race_id=560574");

var horseLinks817181 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817181","http://www.racingpost.com/horses/result_home.sd?race_id=560106");

var horseLinks816196 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816196","http://www.racingpost.com/horses/result_home.sd?race_id=558705","http://www.racingpost.com/horses/result_home.sd?race_id=560527");

var horseLinks818963 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818963");

var horseLinks810129 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810129","http://www.racingpost.com/horses/result_home.sd?race_id=560607");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561726" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561726" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Correggio&id=805359&rnumber=561726" <?php $thisId=805359; include("markHorse.php");?>>Correggio</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Depict&id=817822&rnumber=561726" <?php $thisId=817822; include("markHorse.php");?>>Depict</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Etijaah&id=817814&rnumber=561726" <?php $thisId=817814; include("markHorse.php");?>>Etijaah</a></li>

<ol> 
<li><a href="horse.php?name=Etijaah&id=817814&rnumber=561726&url=/horses/result_home.sd?race_id=560574" id='h2hFormLink'>Lancelot Du Lac </a></li> 
<li><a href="horse.php?name=Etijaah&id=817814&rnumber=561726&url=/horses/result_home.sd?race_id=560574" id='h2hFormLink'>Rangi </a></li> 
</ol> 
<li> <a href="horse.php?name=Havana+Beat&id=802535&rnumber=561726" <?php $thisId=802535; include("markHorse.php");?>>Havana Beat</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hillstar&id=800133&rnumber=561726" <?php $thisId=800133; include("markHorse.php");?>>Hillstar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lancelot+Du+Lac&id=817815&rnumber=561726" <?php $thisId=817815; include("markHorse.php");?>>Lancelot Du Lac</a></li>

<ol> 
<li><a href="horse.php?name=Lancelot+Du+Lac&id=817815&rnumber=561726&url=/horses/result_home.sd?race_id=560574" id='h2hFormLink'>Rangi </a></li> 
</ol> 
<li> <a href="horse.php?name=Rangi&id=800367&rnumber=561726" <?php $thisId=800367; include("markHorse.php");?>>Rangi</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Rock+God&id=817181&rnumber=561726" <?php $thisId=817181; include("markHorse.php");?>>Rock God</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Star+Of+Missouri&id=816196&rnumber=561726" <?php $thisId=816196; include("markHorse.php");?>>Star Of Missouri</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sweet+Deal&id=818963&rnumber=561726" <?php $thisId=818963; include("markHorse.php");?>>Sweet Deal</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tilstarr&id=810129&rnumber=561726" <?php $thisId=810129; include("markHorse.php");?>>Tilstarr</a></li>

<ol> 
</ol> 
</ol>