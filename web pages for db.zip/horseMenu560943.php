
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks816736 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816736","http://www.racingpost.com/horses/result_home.sd?race_id=559581");

var horseLinks773496 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=773496","http://www.racingpost.com/horses/result_home.sd?race_id=551648","http://www.racingpost.com/horses/result_home.sd?race_id=556080","http://www.racingpost.com/horses/result_home.sd?race_id=556925");

var horseLinks778875 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778875","http://www.racingpost.com/horses/result_home.sd?race_id=536561","http://www.racingpost.com/horses/result_home.sd?race_id=537569","http://www.racingpost.com/horses/result_home.sd?race_id=537982","http://www.racingpost.com/horses/result_home.sd?race_id=538673","http://www.racingpost.com/horses/result_home.sd?race_id=553701","http://www.racingpost.com/horses/result_home.sd?race_id=554376","http://www.racingpost.com/horses/result_home.sd?race_id=555805","http://www.racingpost.com/horses/result_home.sd?race_id=559630","http://www.racingpost.com/horses/result_home.sd?race_id=560065");

var horseLinks791478 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791478");

var horseLinks791479 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791479","http://www.racingpost.com/horses/result_home.sd?race_id=541972","http://www.racingpost.com/horses/result_home.sd?race_id=556503");

var horseLinks775046 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=775046");

var horseLinks796464 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=796464","http://www.racingpost.com/horses/result_home.sd?race_id=541972");

var horseLinks812144 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812144");

var horseLinks790274 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790274","http://www.racingpost.com/horses/result_home.sd?race_id=556427","http://www.racingpost.com/horses/result_home.sd?race_id=557584","http://www.racingpost.com/horses/result_home.sd?race_id=559212");

var horseLinks778891 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778891","http://www.racingpost.com/horses/result_home.sd?race_id=561876");

var horseLinks802519 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802519","http://www.racingpost.com/horses/result_home.sd?race_id=553908","http://www.racingpost.com/horses/result_home.sd?race_id=555078");

var horseLinks812393 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812393","http://www.racingpost.com/horses/result_home.sd?race_id=554302");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560943" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560943" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Broughtons+Maxim&id=816736&rnumber=560943" <?php $thisId=816736; include("markHorse.php");?>>Broughtons Maxim</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Chapelle+du+Roi&id=773496&rnumber=560943" <?php $thisId=773496; include("markHorse.php");?>>Chapelle du Roi</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dynamic+Duo&id=778875&rnumber=560943" <?php $thisId=778875; include("markHorse.php");?>>Dynamic Duo</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Maori+Dancer&id=791478&rnumber=560943" <?php $thisId=791478; include("markHorse.php");?>>Maori Dancer</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mossbrae&id=791479&rnumber=560943" <?php $thisId=791479; include("markHorse.php");?>>Mossbrae</a></li>

<ol> 
<li><a href="horse.php?name=Mossbrae&id=791479&rnumber=560943&url=/horses/result_home.sd?race_id=541972" id='h2hFormLink'>Ruban </a></li> 
</ol> 
<li> <a href="horse.php?name=Mutaaleq&id=775046&rnumber=560943" <?php $thisId=775046; include("markHorse.php");?>>Mutaaleq</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ruban&id=796464&rnumber=560943" <?php $thisId=796464; include("markHorse.php");?>>Ruban</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sands+Of+Fortune&id=812144&rnumber=560943" <?php $thisId=812144; include("markHorse.php");?>>Sands Of Fortune</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sir+Quintin&id=790274&rnumber=560943" <?php $thisId=790274; include("markHorse.php");?>>Sir Quintin</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ustura&id=778891&rnumber=560943" <?php $thisId=778891; include("markHorse.php");?>>Ustura</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cape+Alex&id=802519&rnumber=560943" <?php $thisId=802519; include("markHorse.php");?>>Cape Alex</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=My+Espoir&id=812393&rnumber=560943" <?php $thisId=812393; include("markHorse.php");?>>My Espoir</a></li>

<ol> 
</ol> 
</ol>