
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks816579 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816579");

var horseLinks818888 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818888");

var horseLinks818899 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818899");

var horseLinks818890 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818890");

var horseLinks818898 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818898");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561698" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561698" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Hanalei+Bay&id=816579&rnumber=561698" <?php $thisId=816579; include("markHorse.php");?>>Hanalei Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Indie+Banned&id=818888&rnumber=561698" <?php $thisId=818888; include("markHorse.php");?>>Indie Banned</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Marcus+Caesar&id=818899&rnumber=561698" <?php $thisId=818899; include("markHorse.php");?>>Marcus Caesar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Willie+The+Whipper&id=818890&rnumber=561698" <?php $thisId=818890; include("markHorse.php");?>>Willie The Whipper</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dark+Marvel&id=818898&rnumber=561698" <?php $thisId=818898; include("markHorse.php");?>>Dark Marvel</a></li>

<ol> 
</ol> 
</ol>