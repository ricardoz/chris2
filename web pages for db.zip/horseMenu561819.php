
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks719460 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=719460","http://www.racingpost.com/horses/result_home.sd?race_id=470115","http://www.racingpost.com/horses/result_home.sd?race_id=473325","http://www.racingpost.com/horses/result_home.sd?race_id=484599","http://www.racingpost.com/horses/result_home.sd?race_id=558202","http://www.racingpost.com/horses/result_home.sd?race_id=559301","http://www.racingpost.com/horses/result_home.sd?race_id=560176","http://www.racingpost.com/horses/result_home.sd?race_id=561026");

var horseLinks778782 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778782","http://www.racingpost.com/horses/result_home.sd?race_id=526881","http://www.racingpost.com/horses/result_home.sd?race_id=528081","http://www.racingpost.com/horses/result_home.sd?race_id=541631","http://www.racingpost.com/horses/result_home.sd?race_id=543233","http://www.racingpost.com/horses/result_home.sd?race_id=544736","http://www.racingpost.com/horses/result_home.sd?race_id=546930");

var horseLinks781058 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=781058","http://www.racingpost.com/horses/result_home.sd?race_id=515452","http://www.racingpost.com/horses/result_home.sd?race_id=527947","http://www.racingpost.com/horses/result_home.sd?race_id=541867","http://www.racingpost.com/horses/result_home.sd?race_id=550840","http://www.racingpost.com/horses/result_home.sd?race_id=552080","http://www.racingpost.com/horses/result_home.sd?race_id=553913","http://www.racingpost.com/horses/result_home.sd?race_id=554801","http://www.racingpost.com/horses/result_home.sd?race_id=556112","http://www.racingpost.com/horses/result_home.sd?race_id=556633","http://www.racingpost.com/horses/result_home.sd?race_id=559351","http://www.racingpost.com/horses/result_home.sd?race_id=559786","http://www.racingpost.com/horses/result_home.sd?race_id=562287");

var horseLinks747362 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=747362","http://www.racingpost.com/horses/result_home.sd?race_id=522362","http://www.racingpost.com/horses/result_home.sd?race_id=524066","http://www.racingpost.com/horses/result_home.sd?race_id=540574","http://www.racingpost.com/horses/result_home.sd?race_id=545616","http://www.racingpost.com/horses/result_home.sd?race_id=546949","http://www.racingpost.com/horses/result_home.sd?race_id=548222","http://www.racingpost.com/horses/result_home.sd?race_id=556989","http://www.racingpost.com/horses/result_home.sd?race_id=559304");

var horseLinks765003 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=765003","http://www.racingpost.com/horses/result_home.sd?race_id=522860","http://www.racingpost.com/horses/result_home.sd?race_id=524073","http://www.racingpost.com/horses/result_home.sd?race_id=525065","http://www.racingpost.com/horses/result_home.sd?race_id=525558","http://www.racingpost.com/horses/result_home.sd?race_id=527723","http://www.racingpost.com/horses/result_home.sd?race_id=528900","http://www.racingpost.com/horses/result_home.sd?race_id=544406");

var horseLinks747026 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=747026","http://www.racingpost.com/horses/result_home.sd?race_id=495778","http://www.racingpost.com/horses/result_home.sd?race_id=498067","http://www.racingpost.com/horses/result_home.sd?race_id=499804","http://www.racingpost.com/horses/result_home.sd?race_id=533425","http://www.racingpost.com/horses/result_home.sd?race_id=542091","http://www.racingpost.com/horses/result_home.sd?race_id=551234","http://www.racingpost.com/horses/result_home.sd?race_id=553287","http://www.racingpost.com/horses/result_home.sd?race_id=555193","http://www.racingpost.com/horses/result_home.sd?race_id=555835");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561819" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561819" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Dancing+Jack&id=719460&rnumber=561819" <?php $thisId=719460; include("markHorse.php");?>>Dancing Jack</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Redbridge+Rebel&id=778782&rnumber=561819" <?php $thisId=778782; include("markHorse.php");?>>Redbridge Rebel</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Patsy+Cline&id=781058&rnumber=561819" <?php $thisId=781058; include("markHorse.php");?>>Patsy Cline</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Motou&id=747362&rnumber=561819" <?php $thisId=747362; include("markHorse.php");?>>Motou</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sleeping+Du+Granit&id=765003&rnumber=561819" <?php $thisId=765003; include("markHorse.php");?>>Sleeping Du Granit</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Burnt+Again&id=747026&rnumber=561819" <?php $thisId=747026; include("markHorse.php");?>>Burnt Again</a></li>

<ol> 
</ol> 
</ol>