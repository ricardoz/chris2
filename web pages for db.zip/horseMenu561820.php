
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks782185 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=782185","http://www.racingpost.com/horses/result_home.sd?race_id=527167","http://www.racingpost.com/horses/result_home.sd?race_id=530607","http://www.racingpost.com/horses/result_home.sd?race_id=540165","http://www.racingpost.com/horses/result_home.sd?race_id=540993","http://www.racingpost.com/horses/result_home.sd?race_id=543648","http://www.racingpost.com/horses/result_home.sd?race_id=544368","http://www.racingpost.com/horses/result_home.sd?race_id=546213","http://www.racingpost.com/horses/result_home.sd?race_id=547748","http://www.racingpost.com/horses/result_home.sd?race_id=549607","http://www.racingpost.com/horses/result_home.sd?race_id=553867","http://www.racingpost.com/horses/result_home.sd?race_id=555178","http://www.racingpost.com/horses/result_home.sd?race_id=557608","http://www.racingpost.com/horses/result_home.sd?race_id=559757","http://www.racingpost.com/horses/result_home.sd?race_id=560184");

var horseLinks782665 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=782665","http://www.racingpost.com/horses/result_home.sd?race_id=527722","http://www.racingpost.com/horses/result_home.sd?race_id=540252","http://www.racingpost.com/horses/result_home.sd?race_id=541074","http://www.racingpost.com/horses/result_home.sd?race_id=542307","http://www.racingpost.com/horses/result_home.sd?race_id=544472","http://www.racingpost.com/horses/result_home.sd?race_id=552695","http://www.racingpost.com/horses/result_home.sd?race_id=554801","http://www.racingpost.com/horses/result_home.sd?race_id=556511","http://www.racingpost.com/horses/result_home.sd?race_id=559972");

var horseLinks806983 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=806983","http://www.racingpost.com/horses/result_home.sd?race_id=551866","http://www.racingpost.com/horses/result_home.sd?race_id=556460","http://www.racingpost.com/horses/result_home.sd?race_id=557605","http://www.racingpost.com/horses/result_home.sd?race_id=560191");

var horseLinks784568 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=784568","http://www.racingpost.com/horses/result_home.sd?race_id=530517","http://www.racingpost.com/horses/result_home.sd?race_id=539789","http://www.racingpost.com/horses/result_home.sd?race_id=540988","http://www.racingpost.com/horses/result_home.sd?race_id=556470","http://www.racingpost.com/horses/result_home.sd?race_id=560821","http://www.racingpost.com/horses/result_home.sd?race_id=561022");

var horseLinks795936 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795936","http://www.racingpost.com/horses/result_home.sd?race_id=541023","http://www.racingpost.com/horses/result_home.sd?race_id=542836","http://www.racingpost.com/horses/result_home.sd?race_id=556470","http://www.racingpost.com/horses/result_home.sd?race_id=558765");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561820" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561820" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=An+Capall+Mor&id=782185&rnumber=561820" <?php $thisId=782185; include("markHorse.php");?>>An Capall Mor</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Churchfield+Champ&id=782665&rnumber=561820" <?php $thisId=782665; include("markHorse.php");?>>Churchfield Champ</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Thegaygardener&id=806983&rnumber=561820" <?php $thisId=806983; include("markHorse.php");?>>Thegaygardener</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Violets+Boy&id=784568&rnumber=561820" <?php $thisId=784568; include("markHorse.php");?>>Violets Boy</a></li>

<ol> 
<li><a href="horse.php?name=Violets+Boy&id=784568&rnumber=561820&url=/horses/result_home.sd?race_id=556470" id='h2hFormLink'>Breakoutthebooze </a></li> 
</ol> 
<li> <a href="horse.php?name=Breakoutthebooze&id=795936&rnumber=561820" <?php $thisId=795936; include("markHorse.php");?>>Breakoutthebooze</a></li>

<ol> 
</ol> 
</ol>