

<?php

function getConnection()
{

    /*set db variables*/
    /*$host = "localhost";*/
    /*$user = "root";*/
    /*$password = "random";*/
    /*$database = "mydb";*/

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "a1270291_racing";


    /*connect database*/


    $connection = mysql_connect($host, $user, $password) or die("Could not connect: " .
        mysql_error());

    return $connection;
}

function getHorseID($horse, $query)
{

    /*set db variables
    $host = "mysql13.000webhost.com";
    $user = "a1270291_racing";
    $password = "random17";
    $database = "a1270291_racing";*/
    
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "a1270291_racing";


    /*connect database*/
    $connection = getConnection();
    mysql_select_db($database, $connection) or die("Error in selecting the database:" .
        mysql_error());


    $result = mysql_query($query) or die("Error in getHorseId: $query " .
        mysql_error());


    $sql_row = mysql_fetch_array($result);    {
        $id = $sql_row["id"];

        return $id;
    }
    
    mysql_close($connection);
}

function queryIsNull($query)
{


    $result = getResult($query);
    $row = mysql_fetch_array($result);
    $num_results = mysql_num_rows($result);

    if ($num_results > 0) {
        return false;
    } else {
        return true;
    }
}

function getResult($query)
{

    /*set db variables
    $host = "mysql13.000webhost.com";
    $user = "a1270291_racing";
    $password = "random17";
    $database = "a1270291_racing";*/
    
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "a1270291_racing";


    /*connect database*/
    $connection = mysql_connect($host, $user, $password) or die("Could not connect: " .
        mysql_error());
    mysql_select_db($database, $connection) or die("Error in selecting the database:" .
        mysql_error());

    $result = mysql_query($query) or die("Error in queryIsNull: $query " .
        mysql_error());

    return $result;
    
    mysql_close($connection);
}

function getValue($query)
{

    /*set db variables
    $host = "mysql13.000webhost.com";
    $user = "a1270291_racing";
    $password = "random17";
    $database = "a1270291_racing";*/
    
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "a1270291_racing";


    /*connect database*/
    $connection = mysql_connect($host, $user, $password) or die("Could not connect: " .
        mysql_error());
    mysql_select_db($database, $connection) or die("Error in selecting the database:" .
        mysql_error());

    $result = mysql_query($query) or die("Error in getValue: $query " .
        mysql_error());

    $row = mysql_fetch_array($result);
    
    return $row[0];
    
    mysql_close($connection);
}




?>