
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks765888 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=765888","http://www.racingpost.com/horses/result_home.sd?race_id=513178","http://www.racingpost.com/horses/result_home.sd?race_id=514570","http://www.racingpost.com/horses/result_home.sd?race_id=515174","http://www.racingpost.com/horses/result_home.sd?race_id=527652","http://www.racingpost.com/horses/result_home.sd?race_id=528971","http://www.racingpost.com/horses/result_home.sd?race_id=530451","http://www.racingpost.com/horses/result_home.sd?race_id=532476","http://www.racingpost.com/horses/result_home.sd?race_id=533642","http://www.racingpost.com/horses/result_home.sd?race_id=534568","http://www.racingpost.com/horses/result_home.sd?race_id=536877","http://www.racingpost.com/horses/result_home.sd?race_id=538032","http://www.racingpost.com/horses/result_home.sd?race_id=538760","http://www.racingpost.com/horses/result_home.sd?race_id=539407","http://www.racingpost.com/horses/result_home.sd?race_id=549535","http://www.racingpost.com/horses/result_home.sd?race_id=551852","http://www.racingpost.com/horses/result_home.sd?race_id=555060","http://www.racingpost.com/horses/result_home.sd?race_id=556423","http://www.racingpost.com/horses/result_home.sd?race_id=559291","http://www.racingpost.com/horses/result_home.sd?race_id=560597");

var horseLinks732348 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=732348","http://www.racingpost.com/horses/result_home.sd?race_id=472134","http://www.racingpost.com/horses/result_home.sd?race_id=487626","http://www.racingpost.com/horses/result_home.sd?race_id=488414","http://www.racingpost.com/horses/result_home.sd?race_id=489435","http://www.racingpost.com/horses/result_home.sd?race_id=513468","http://www.racingpost.com/horses/result_home.sd?race_id=516344","http://www.racingpost.com/horses/result_home.sd?race_id=523490","http://www.racingpost.com/horses/result_home.sd?race_id=524970","http://www.racingpost.com/horses/result_home.sd?race_id=526189","http://www.racingpost.com/horses/result_home.sd?race_id=537681","http://www.racingpost.com/horses/result_home.sd?race_id=539679","http://www.racingpost.com/horses/result_home.sd?race_id=540115","http://www.racingpost.com/horses/result_home.sd?race_id=544549","http://www.racingpost.com/horses/result_home.sd?race_id=560027");

var horseLinks773447 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=773447","http://www.racingpost.com/horses/result_home.sd?race_id=560528","http://www.racingpost.com/horses/result_home.sd?race_id=560729");

var horseLinks783521 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783521","http://www.racingpost.com/horses/result_home.sd?race_id=528361","http://www.racingpost.com/horses/result_home.sd?race_id=529673","http://www.racingpost.com/horses/result_home.sd?race_id=532565","http://www.racingpost.com/horses/result_home.sd?race_id=536430","http://www.racingpost.com/horses/result_home.sd?race_id=537253","http://www.racingpost.com/horses/result_home.sd?race_id=538369","http://www.racingpost.com/horses/result_home.sd?race_id=539386","http://www.racingpost.com/horses/result_home.sd?race_id=540076","http://www.racingpost.com/horses/result_home.sd?race_id=540400","http://www.racingpost.com/horses/result_home.sd?race_id=546146","http://www.racingpost.com/horses/result_home.sd?race_id=548100","http://www.racingpost.com/horses/result_home.sd?race_id=557025","http://www.racingpost.com/horses/result_home.sd?race_id=559721","http://www.racingpost.com/horses/result_home.sd?race_id=560528");

var horseLinks687477 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=687477","http://www.racingpost.com/horses/result_home.sd?race_id=438891","http://www.racingpost.com/horses/result_home.sd?race_id=453967","http://www.racingpost.com/horses/result_home.sd?race_id=455227","http://www.racingpost.com/horses/result_home.sd?race_id=458108","http://www.racingpost.com/horses/result_home.sd?race_id=469645","http://www.racingpost.com/horses/result_home.sd?race_id=471063","http://www.racingpost.com/horses/result_home.sd?race_id=472178","http://www.racingpost.com/horses/result_home.sd?race_id=477676","http://www.racingpost.com/horses/result_home.sd?race_id=480420","http://www.racingpost.com/horses/result_home.sd?race_id=485126","http://www.racingpost.com/horses/result_home.sd?race_id=502825");

var horseLinks758414 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=758414","http://www.racingpost.com/horses/result_home.sd?race_id=504945","http://www.racingpost.com/horses/result_home.sd?race_id=527670","http://www.racingpost.com/horses/result_home.sd?race_id=529599","http://www.racingpost.com/horses/result_home.sd?race_id=530395","http://www.racingpost.com/horses/result_home.sd?race_id=532509","http://www.racingpost.com/horses/result_home.sd?race_id=535378","http://www.racingpost.com/horses/result_home.sd?race_id=535677","http://www.racingpost.com/horses/result_home.sd?race_id=536595","http://www.racingpost.com/horses/result_home.sd?race_id=537624","http://www.racingpost.com/horses/result_home.sd?race_id=538264","http://www.racingpost.com/horses/result_home.sd?race_id=549534","http://www.racingpost.com/horses/result_home.sd?race_id=560108","http://www.racingpost.com/horses/result_home.sd?race_id=561278");

var horseLinks801081 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=801081","http://www.racingpost.com/horses/result_home.sd?race_id=544240","http://www.racingpost.com/horses/result_home.sd?race_id=545098","http://www.racingpost.com/horses/result_home.sd?race_id=546486","http://www.racingpost.com/horses/result_home.sd?race_id=560899");

var horseLinks719958 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=719958","http://www.racingpost.com/horses/result_home.sd?race_id=468143","http://www.racingpost.com/horses/result_home.sd?race_id=468763","http://www.racingpost.com/horses/result_home.sd?race_id=470196","http://www.racingpost.com/horses/result_home.sd?race_id=483923","http://www.racingpost.com/horses/result_home.sd?race_id=485116","http://www.racingpost.com/horses/result_home.sd?race_id=487635","http://www.racingpost.com/horses/result_home.sd?race_id=488698","http://www.racingpost.com/horses/result_home.sd?race_id=490173","http://www.racingpost.com/horses/result_home.sd?race_id=507575","http://www.racingpost.com/horses/result_home.sd?race_id=509676","http://www.racingpost.com/horses/result_home.sd?race_id=510487","http://www.racingpost.com/horses/result_home.sd?race_id=511171","http://www.racingpost.com/horses/result_home.sd?race_id=511522","http://www.racingpost.com/horses/result_home.sd?race_id=512414","http://www.racingpost.com/horses/result_home.sd?race_id=513088","http://www.racingpost.com/horses/result_home.sd?race_id=514169","http://www.racingpost.com/horses/result_home.sd?race_id=516517","http://www.racingpost.com/horses/result_home.sd?race_id=517151","http://www.racingpost.com/horses/result_home.sd?race_id=517399","http://www.racingpost.com/horses/result_home.sd?race_id=519358","http://www.racingpost.com/horses/result_home.sd?race_id=519670","http://www.racingpost.com/horses/result_home.sd?race_id=529727","http://www.racingpost.com/horses/result_home.sd?race_id=531899","http://www.racingpost.com/horses/result_home.sd?race_id=532534","http://www.racingpost.com/horses/result_home.sd?race_id=533555","http://www.racingpost.com/horses/result_home.sd?race_id=534511","http://www.racingpost.com/horses/result_home.sd?race_id=535328","http://www.racingpost.com/horses/result_home.sd?race_id=536906","http://www.racingpost.com/horses/result_home.sd?race_id=537310","http://www.racingpost.com/horses/result_home.sd?race_id=537688","http://www.racingpost.com/horses/result_home.sd?race_id=538319","http://www.racingpost.com/horses/result_home.sd?race_id=538725","http://www.racingpost.com/horses/result_home.sd?race_id=540490","http://www.racingpost.com/horses/result_home.sd?race_id=541313","http://www.racingpost.com/horses/result_home.sd?race_id=549985","http://www.racingpost.com/horses/result_home.sd?race_id=553195","http://www.racingpost.com/horses/result_home.sd?race_id=556423","http://www.racingpost.com/horses/result_home.sd?race_id=557463","http://www.racingpost.com/horses/result_home.sd?race_id=559229","http://www.racingpost.com/horses/result_home.sd?race_id=559702","http://www.racingpost.com/horses/result_home.sd?race_id=561278");

var horseLinks759745 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=759745","http://www.racingpost.com/horses/result_home.sd?race_id=506339","http://www.racingpost.com/horses/result_home.sd?race_id=527032","http://www.racingpost.com/horses/result_home.sd?race_id=530720","http://www.racingpost.com/horses/result_home.sd?race_id=538319","http://www.racingpost.com/horses/result_home.sd?race_id=540115","http://www.racingpost.com/horses/result_home.sd?race_id=540532","http://www.racingpost.com/horses/result_home.sd?race_id=541294","http://www.racingpost.com/horses/result_home.sd?race_id=542158","http://www.racingpost.com/horses/result_home.sd?race_id=549013","http://www.racingpost.com/horses/result_home.sd?race_id=550518","http://www.racingpost.com/horses/result_home.sd?race_id=560896","http://www.racingpost.com/horses/result_home.sd?race_id=561267");

var horseLinks753225 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=753225","http://www.racingpost.com/horses/result_home.sd?race_id=514132","http://www.racingpost.com/horses/result_home.sd?race_id=515183","http://www.racingpost.com/horses/result_home.sd?race_id=518707","http://www.racingpost.com/horses/result_home.sd?race_id=528256","http://www.racingpost.com/horses/result_home.sd?race_id=529636","http://www.racingpost.com/horses/result_home.sd?race_id=531817","http://www.racingpost.com/horses/result_home.sd?race_id=533571","http://www.racingpost.com/horses/result_home.sd?race_id=534866","http://www.racingpost.com/horses/result_home.sd?race_id=536181","http://www.racingpost.com/horses/result_home.sd?race_id=538014","http://www.racingpost.com/horses/result_home.sd?race_id=551722","http://www.racingpost.com/horses/result_home.sd?race_id=555731","http://www.racingpost.com/horses/result_home.sd?race_id=558729","http://www.racingpost.com/horses/result_home.sd?race_id=560086");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561710" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561710" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Weapon+Of+Choice&id=765888&rnumber=561710" <?php $thisId=765888; include("markHorse.php");?>>Weapon Of Choice</a></li>

<ol> 
<li><a href="horse.php?name=Weapon+Of+Choice&id=765888&rnumber=561710&url=/horses/result_home.sd?race_id=556423" id='h2hFormLink'>Fantasy Gladiator </a></li> 
</ol> 
<li> <a href="horse.php?name=Atlantis+Star&id=732348&rnumber=561710" <?php $thisId=732348; include("markHorse.php");?>>Atlantis Star</a></li>

<ol> 
<li><a href="horse.php?name=Atlantis+Star&id=732348&rnumber=561710&url=/horses/result_home.sd?race_id=540115" id='h2hFormLink'>Afkar </a></li> 
</ol> 
<li> <a href="horse.php?name=Royal+Empire&id=773447&rnumber=561710" <?php $thisId=773447; include("markHorse.php");?>>Royal Empire</a></li>

<ol> 
<li><a href="horse.php?name=Royal+Empire&id=773447&rnumber=561710&url=/horses/result_home.sd?race_id=560528" id='h2hFormLink'>Come On Blue Chip </a></li> 
</ol> 
<li> <a href="horse.php?name=Come+On+Blue+Chip&id=783521&rnumber=561710" <?php $thisId=783521; include("markHorse.php");?>>Come On Blue Chip</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Everybody+Knows&id=687477&rnumber=561710" <?php $thisId=687477; include("markHorse.php");?>>Everybody Knows</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Little+Black+Book&id=758414&rnumber=561710" <?php $thisId=758414; include("markHorse.php");?>>Little Black Book</a></li>

<ol> 
<li><a href="horse.php?name=Little+Black+Book&id=758414&rnumber=561710&url=/horses/result_home.sd?race_id=561278" id='h2hFormLink'>Fantasy Gladiator </a></li> 
</ol> 
<li> <a href="horse.php?name=Discoverer&id=801081&rnumber=561710" <?php $thisId=801081; include("markHorse.php");?>>Discoverer</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Fantasy+Gladiator&id=719958&rnumber=561710" <?php $thisId=719958; include("markHorse.php");?>>Fantasy Gladiator</a></li>

<ol> 
<li><a href="horse.php?name=Fantasy+Gladiator&id=719958&rnumber=561710&url=/horses/result_home.sd?race_id=538319" id='h2hFormLink'>Afkar </a></li> 
</ol> 
<li> <a href="horse.php?name=Afkar&id=759745&rnumber=561710" <?php $thisId=759745; include("markHorse.php");?>>Afkar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hurricane+Lady&id=753225&rnumber=561710" <?php $thisId=753225; include("markHorse.php");?>>Hurricane Lady</a></li>

<ol> 
</ol> 
</ol>