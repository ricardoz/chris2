
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks763920 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=763920","http://www.racingpost.com/horses/result_home.sd?race_id=513026","http://www.racingpost.com/horses/result_home.sd?race_id=513594","http://www.racingpost.com/horses/result_home.sd?race_id=533729","http://www.racingpost.com/horses/result_home.sd?race_id=534381","http://www.racingpost.com/horses/result_home.sd?race_id=535210","http://www.racingpost.com/horses/result_home.sd?race_id=537094","http://www.racingpost.com/horses/result_home.sd?race_id=537912","http://www.racingpost.com/horses/result_home.sd?race_id=538917","http://www.racingpost.com/horses/result_home.sd?race_id=540367","http://www.racingpost.com/horses/result_home.sd?race_id=558287","http://www.racingpost.com/horses/result_home.sd?race_id=560678");

var horseLinks759218 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=759218","http://www.racingpost.com/horses/result_home.sd?race_id=507967","http://www.racingpost.com/horses/result_home.sd?race_id=508753","http://www.racingpost.com/horses/result_home.sd?race_id=509500","http://www.racingpost.com/horses/result_home.sd?race_id=510358","http://www.racingpost.com/horses/result_home.sd?race_id=517125","http://www.racingpost.com/horses/result_home.sd?race_id=517337","http://www.racingpost.com/horses/result_home.sd?race_id=531157","http://www.racingpost.com/horses/result_home.sd?race_id=532762","http://www.racingpost.com/horses/result_home.sd?race_id=536277","http://www.racingpost.com/horses/result_home.sd?race_id=540367","http://www.racingpost.com/horses/result_home.sd?race_id=541203","http://www.racingpost.com/horses/result_home.sd?race_id=543055","http://www.racingpost.com/horses/result_home.sd?race_id=556640","http://www.racingpost.com/horses/result_home.sd?race_id=558545","http://www.racingpost.com/horses/result_home.sd?race_id=559533");

var horseLinks783915 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783915","http://www.racingpost.com/horses/result_home.sd?race_id=537403","http://www.racingpost.com/horses/result_home.sd?race_id=538842","http://www.racingpost.com/horses/result_home.sd?race_id=542699","http://www.racingpost.com/horses/result_home.sd?race_id=554668","http://www.racingpost.com/horses/result_home.sd?race_id=556748");

var horseLinks755984 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=755984","http://www.racingpost.com/horses/result_home.sd?race_id=508914","http://www.racingpost.com/horses/result_home.sd?race_id=526773","http://www.racingpost.com/horses/result_home.sd?race_id=527961","http://www.racingpost.com/horses/result_home.sd?race_id=534626","http://www.racingpost.com/horses/result_home.sd?race_id=535457","http://www.racingpost.com/horses/result_home.sd?race_id=535877","http://www.racingpost.com/horses/result_home.sd?race_id=536688","http://www.racingpost.com/horses/result_home.sd?race_id=537796","http://www.racingpost.com/horses/result_home.sd?race_id=538138","http://www.racingpost.com/horses/result_home.sd?race_id=546063","http://www.racingpost.com/horses/result_home.sd?race_id=547059","http://www.racingpost.com/horses/result_home.sd?race_id=547902","http://www.racingpost.com/horses/result_home.sd?race_id=549699","http://www.racingpost.com/horses/result_home.sd?race_id=551391","http://www.racingpost.com/horses/result_home.sd?race_id=554668","http://www.racingpost.com/horses/result_home.sd?race_id=559533","http://www.racingpost.com/horses/result_home.sd?race_id=560678");

var horseLinks745570 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=745570","http://www.racingpost.com/horses/result_home.sd?race_id=504601","http://www.racingpost.com/horses/result_home.sd?race_id=510342","http://www.racingpost.com/horses/result_home.sd?race_id=512110","http://www.racingpost.com/horses/result_home.sd?race_id=515143","http://www.racingpost.com/horses/result_home.sd?race_id=516407","http://www.racingpost.com/horses/result_home.sd?race_id=527341","http://www.racingpost.com/horses/result_home.sd?race_id=528592","http://www.racingpost.com/horses/result_home.sd?race_id=532762","http://www.racingpost.com/horses/result_home.sd?race_id=533976","http://www.racingpost.com/horses/result_home.sd?race_id=536367","http://www.racingpost.com/horses/result_home.sd?race_id=537037","http://www.racingpost.com/horses/result_home.sd?race_id=537798","http://www.racingpost.com/horses/result_home.sd?race_id=539287","http://www.racingpost.com/horses/result_home.sd?race_id=539978","http://www.racingpost.com/horses/result_home.sd?race_id=551312","http://www.racingpost.com/horses/result_home.sd?race_id=552573","http://www.racingpost.com/horses/result_home.sd?race_id=554668","http://www.racingpost.com/horses/result_home.sd?race_id=555364","http://www.racingpost.com/horses/result_home.sd?race_id=558287","http://www.racingpost.com/horses/result_home.sd?race_id=560723");

var horseLinks790549 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790549","http://www.racingpost.com/horses/result_home.sd?race_id=537111","http://www.racingpost.com/horses/result_home.sd?race_id=542694","http://www.racingpost.com/horses/result_home.sd?race_id=544930","http://www.racingpost.com/horses/result_home.sd?race_id=556641","http://www.racingpost.com/horses/result_home.sd?race_id=561177");

var horseLinks813286 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813286","http://www.racingpost.com/horses/result_home.sd?race_id=557212","http://www.racingpost.com/horses/result_home.sd?race_id=561099");

var horseLinks756930 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=756930","http://www.racingpost.com/horses/result_home.sd?race_id=546501","http://www.racingpost.com/horses/result_home.sd?race_id=547278","http://www.racingpost.com/horses/result_home.sd?race_id=547817","http://www.racingpost.com/horses/result_home.sd?race_id=548073","http://www.racingpost.com/horses/result_home.sd?race_id=549045","http://www.racingpost.com/horses/result_home.sd?race_id=549493","http://www.racingpost.com/horses/result_home.sd?race_id=556430","http://www.racingpost.com/horses/result_home.sd?race_id=557037","http://www.racingpost.com/horses/result_home.sd?race_id=557482","http://www.racingpost.com/horses/result_home.sd?race_id=559123","http://www.racingpost.com/horses/result_home.sd?race_id=559697","http://www.racingpost.com/horses/result_home.sd?race_id=560020");

var horseLinks740556 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=740556","http://www.racingpost.com/horses/result_home.sd?race_id=490097","http://www.racingpost.com/horses/result_home.sd?race_id=492377","http://www.racingpost.com/horses/result_home.sd?race_id=493273","http://www.racingpost.com/horses/result_home.sd?race_id=494645","http://www.racingpost.com/horses/result_home.sd?race_id=495058","http://www.racingpost.com/horses/result_home.sd?race_id=501322","http://www.racingpost.com/horses/result_home.sd?race_id=502019","http://www.racingpost.com/horses/result_home.sd?race_id=504509","http://www.racingpost.com/horses/result_home.sd?race_id=505394","http://www.racingpost.com/horses/result_home.sd?race_id=507301","http://www.racingpost.com/horses/result_home.sd?race_id=508393","http://www.racingpost.com/horses/result_home.sd?race_id=509498","http://www.racingpost.com/horses/result_home.sd?race_id=509834","http://www.racingpost.com/horses/result_home.sd?race_id=510597","http://www.racingpost.com/horses/result_home.sd?race_id=516814","http://www.racingpost.com/horses/result_home.sd?race_id=518888","http://www.racingpost.com/horses/result_home.sd?race_id=519587","http://www.racingpost.com/horses/result_home.sd?race_id=519993","http://www.racingpost.com/horses/result_home.sd?race_id=532884","http://www.racingpost.com/horses/result_home.sd?race_id=533976","http://www.racingpost.com/horses/result_home.sd?race_id=534383","http://www.racingpost.com/horses/result_home.sd?race_id=535464","http://www.racingpost.com/horses/result_home.sd?race_id=536240","http://www.racingpost.com/horses/result_home.sd?race_id=537025","http://www.racingpost.com/horses/result_home.sd?race_id=537395","http://www.racingpost.com/horses/result_home.sd?race_id=538100","http://www.racingpost.com/horses/result_home.sd?race_id=538918","http://www.racingpost.com/horses/result_home.sd?race_id=539520","http://www.racingpost.com/horses/result_home.sd?race_id=541606","http://www.racingpost.com/horses/result_home.sd?race_id=544122","http://www.racingpost.com/horses/result_home.sd?race_id=544932","http://www.racingpost.com/horses/result_home.sd?race_id=546064","http://www.racingpost.com/horses/result_home.sd?race_id=547059","http://www.racingpost.com/horses/result_home.sd?race_id=547902","http://www.racingpost.com/horses/result_home.sd?race_id=549699","http://www.racingpost.com/horses/result_home.sd?race_id=552691","http://www.racingpost.com/horses/result_home.sd?race_id=554668","http://www.racingpost.com/horses/result_home.sd?race_id=560723","http://www.racingpost.com/horses/result_home.sd?race_id=561458");

var horseLinks707375 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=707375","http://www.racingpost.com/horses/result_home.sd?race_id=458360","http://www.racingpost.com/horses/result_home.sd?race_id=460281","http://www.racingpost.com/horses/result_home.sd?race_id=462013","http://www.racingpost.com/horses/result_home.sd?race_id=463221","http://www.racingpost.com/horses/result_home.sd?race_id=463973","http://www.racingpost.com/horses/result_home.sd?race_id=464888","http://www.racingpost.com/horses/result_home.sd?race_id=465467","http://www.racingpost.com/horses/result_home.sd?race_id=465581","http://www.racingpost.com/horses/result_home.sd?race_id=468056","http://www.racingpost.com/horses/result_home.sd?race_id=479190","http://www.racingpost.com/horses/result_home.sd?race_id=4802782","http://www.racingpost.com/horses/result_home.sd?race_id=485221","http://www.racingpost.com/horses/result_home.sd?race_id=485886","http://www.racingpost.com/horses/result_home.sd?race_id=486352","http://www.racingpost.com/horses/result_home.sd?race_id=487075","http://www.racingpost.com/horses/result_home.sd?race_id=489369","http://www.racingpost.com/horses/result_home.sd?race_id=490457","http://www.racingpost.com/horses/result_home.sd?race_id=490804","http://www.racingpost.com/horses/result_home.sd?race_id=491517","http://www.racingpost.com/horses/result_home.sd?race_id=493082","http://www.racingpost.com/horses/result_home.sd?race_id=493278","http://www.racingpost.com/horses/result_home.sd?race_id=494534","http://www.racingpost.com/horses/result_home.sd?race_id=494967","http://www.racingpost.com/horses/result_home.sd?race_id=503786","http://www.racingpost.com/horses/result_home.sd?race_id=509442","http://www.racingpost.com/horses/result_home.sd?race_id=509843","http://www.racingpost.com/horses/result_home.sd?race_id=509962","http://www.racingpost.com/horses/result_home.sd?race_id=510347","http://www.racingpost.com/horses/result_home.sd?race_id=511119","http://www.racingpost.com/horses/result_home.sd?race_id=511366","http://www.racingpost.com/horses/result_home.sd?race_id=512519","http://www.racingpost.com/horses/result_home.sd?race_id=513597","http://www.racingpost.com/horses/result_home.sd?race_id=514797","http://www.racingpost.com/horses/result_home.sd?race_id=515141","http://www.racingpost.com/horses/result_home.sd?race_id=515962","http://www.racingpost.com/horses/result_home.sd?race_id=518889","http://www.racingpost.com/horses/result_home.sd?race_id=519234","http://www.racingpost.com/horses/result_home.sd?race_id=519589","http://www.racingpost.com/horses/result_home.sd?race_id=519996","http://www.racingpost.com/horses/result_home.sd?race_id=535465","http://www.racingpost.com/horses/result_home.sd?race_id=535879","http://www.racingpost.com/horses/result_home.sd?race_id=536239","http://www.racingpost.com/horses/result_home.sd?race_id=537399","http://www.racingpost.com/horses/result_home.sd?race_id=539252","http://www.racingpost.com/horses/result_home.sd?race_id=539662","http://www.racingpost.com/horses/result_home.sd?race_id=541487","http://www.racingpost.com/horses/result_home.sd?race_id=541609","http://www.racingpost.com/horses/result_home.sd?race_id=542700","http://www.racingpost.com/horses/result_home.sd?race_id=544125","http://www.racingpost.com/horses/result_home.sd?race_id=544934","http://www.racingpost.com/horses/result_home.sd?race_id=545310","http://www.racingpost.com/horses/result_home.sd?race_id=547060","http://www.racingpost.com/horses/result_home.sd?race_id=548314","http://www.racingpost.com/horses/result_home.sd?race_id=560258","http://www.racingpost.com/horses/result_home.sd?race_id=560723","http://www.racingpost.com/horses/result_home.sd?race_id=561180");

var horseLinks799654 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=799654","http://www.racingpost.com/horses/result_home.sd?race_id=544523","http://www.racingpost.com/horses/result_home.sd?race_id=546062","http://www.racingpost.com/horses/result_home.sd?race_id=558279","http://www.racingpost.com/horses/result_home.sd?race_id=560723","http://www.racingpost.com/horses/result_home.sd?race_id=561444");

var horseLinks782951 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=782951","http://www.racingpost.com/horses/result_home.sd?race_id=532092","http://www.racingpost.com/horses/result_home.sd?race_id=535488","http://www.racingpost.com/horses/result_home.sd?race_id=535868","http://www.racingpost.com/horses/result_home.sd?race_id=536674","http://www.racingpost.com/horses/result_home.sd?race_id=537498","http://www.racingpost.com/horses/result_home.sd?race_id=540118","http://www.racingpost.com/horses/result_home.sd?race_id=546378","http://www.racingpost.com/horses/result_home.sd?race_id=547535","http://www.racingpost.com/horses/result_home.sd?race_id=548922","http://www.racingpost.com/horses/result_home.sd?race_id=557855","http://www.racingpost.com/horses/result_home.sd?race_id=558438","http://www.racingpost.com/horses/result_home.sd?race_id=560723");

var horseLinks779055 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=779055","http://www.racingpost.com/horses/result_home.sd?race_id=538213","http://www.racingpost.com/horses/result_home.sd?race_id=541236","http://www.racingpost.com/horses/result_home.sd?race_id=542097","http://www.racingpost.com/horses/result_home.sd?race_id=547901","http://www.racingpost.com/horses/result_home.sd?race_id=553322","http://www.racingpost.com/horses/result_home.sd?race_id=560785","http://www.racingpost.com/horses/result_home.sd?race_id=561101","http://www.racingpost.com/horses/result_home.sd?race_id=561444");

var horseLinks790698 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790698","http://www.racingpost.com/horses/result_home.sd?race_id=537400","http://www.racingpost.com/horses/result_home.sd?race_id=538916","http://www.racingpost.com/horses/result_home.sd?race_id=551393","http://www.racingpost.com/horses/result_home.sd?race_id=552574","http://www.racingpost.com/horses/result_home.sd?race_id=555931","http://www.racingpost.com/horses/result_home.sd?race_id=558873","http://www.racingpost.com/horses/result_home.sd?race_id=560723");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562397" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562397" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Back+Burner&id=763920&rnumber=562397" <?php $thisId=763920; include("markHorse.php");?>>Back Burner</a></li>

<ol> 
<li><a href="horse.php?name=Back+Burner&id=763920&rnumber=562397&url=/horses/result_home.sd?race_id=540367" id='h2hFormLink'>Super Say </a></li> 
<li><a href="horse.php?name=Back+Burner&id=763920&rnumber=562397&url=/horses/result_home.sd?race_id=560678" id='h2hFormLink'>Akasaka </a></li> 
<li><a href="horse.php?name=Back+Burner&id=763920&rnumber=562397&url=/horses/result_home.sd?race_id=558287" id='h2hFormLink'>Barrow Island </a></li> 
</ol> 
<li> <a href="horse.php?name=Super+Say&id=759218&rnumber=562397" <?php $thisId=759218; include("markHorse.php");?>>Super Say</a></li>

<ol> 
<li><a href="horse.php?name=Super+Say&id=759218&rnumber=562397&url=/horses/result_home.sd?race_id=559533" id='h2hFormLink'>Akasaka </a></li> 
<li><a href="horse.php?name=Super+Say&id=759218&rnumber=562397&url=/horses/result_home.sd?race_id=532762" id='h2hFormLink'>Barrow Island </a></li> 
</ol> 
<li> <a href="horse.php?name=Certerach&id=783915&rnumber=562397" <?php $thisId=783915; include("markHorse.php");?>>Certerach</a></li>

<ol> 
<li><a href="horse.php?name=Certerach&id=783915&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Akasaka </a></li> 
<li><a href="horse.php?name=Certerach&id=783915&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Barrow Island </a></li> 
<li><a href="horse.php?name=Certerach&id=783915&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Iron Major </a></li> 
</ol> 
<li> <a href="horse.php?name=Akasaka&id=755984&rnumber=562397" <?php $thisId=755984; include("markHorse.php");?>>Akasaka</a></li>

<ol> 
<li><a href="horse.php?name=Akasaka&id=755984&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Barrow Island </a></li> 
<li><a href="horse.php?name=Akasaka&id=755984&rnumber=562397&url=/horses/result_home.sd?race_id=547059" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Akasaka&id=755984&rnumber=562397&url=/horses/result_home.sd?race_id=547902" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Akasaka&id=755984&rnumber=562397&url=/horses/result_home.sd?race_id=549699" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Akasaka&id=755984&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Iron Major </a></li> 
</ol> 
<li> <a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397" <?php $thisId=745570; include("markHorse.php");?>>Barrow Island</a></li>

<ol> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=533976" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=554668" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Iron Major </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Solo Performer </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Muck 'N' Brass </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Strait Of Zanzibar </a></li> 
<li><a href="horse.php?name=Barrow+Island&id=745570&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Suehail </a></li> 
</ol> 
<li> <a href="horse.php?name=Sindjara&id=790549&rnumber=562397" <?php $thisId=790549; include("markHorse.php");?>>Sindjara</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Brendan+Brackan&id=813286&rnumber=562397" <?php $thisId=813286; include("markHorse.php");?>>Brendan Brackan</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Colour+Guard&id=756930&rnumber=562397" <?php $thisId=756930; include("markHorse.php");?>>Colour Guard</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Iron+Major&id=740556&rnumber=562397" <?php $thisId=740556; include("markHorse.php");?>>Iron Major</a></li>

<ol> 
<li><a href="horse.php?name=Iron+Major&id=740556&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Solo Performer </a></li> 
<li><a href="horse.php?name=Iron+Major&id=740556&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Muck 'N' Brass </a></li> 
<li><a href="horse.php?name=Iron+Major&id=740556&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Strait Of Zanzibar </a></li> 
<li><a href="horse.php?name=Iron+Major&id=740556&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Suehail </a></li> 
</ol> 
<li> <a href="horse.php?name=Solo+Performer&id=707375&rnumber=562397" <?php $thisId=707375; include("markHorse.php");?>>Solo Performer</a></li>

<ol> 
<li><a href="horse.php?name=Solo+Performer&id=707375&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Muck 'N' Brass </a></li> 
<li><a href="horse.php?name=Solo+Performer&id=707375&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Strait Of Zanzibar </a></li> 
<li><a href="horse.php?name=Solo+Performer&id=707375&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Suehail </a></li> 
</ol> 
<li> <a href="horse.php?name=Muck+'N'+Brass&id=799654&rnumber=562397" <?php $thisId=799654; include("markHorse.php");?>>Muck 'N' Brass</a></li>

<ol> 
<li><a href="horse.php?name=Muck+'N'+Brass&id=799654&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Strait Of Zanzibar </a></li> 
<li><a href="horse.php?name=Muck+'N'+Brass&id=799654&rnumber=562397&url=/horses/result_home.sd?race_id=561444" id='h2hFormLink'>Miracle Cure </a></li> 
<li><a href="horse.php?name=Muck+'N'+Brass&id=799654&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Suehail </a></li> 
</ol> 
<li> <a href="horse.php?name=Strait+Of+Zanzibar&id=782951&rnumber=562397" <?php $thisId=782951; include("markHorse.php");?>>Strait Of Zanzibar</a></li>

<ol> 
<li><a href="horse.php?name=Strait+Of+Zanzibar&id=782951&rnumber=562397&url=/horses/result_home.sd?race_id=560723" id='h2hFormLink'>Suehail </a></li> 
</ol> 
<li> <a href="horse.php?name=Miracle+Cure&id=779055&rnumber=562397" <?php $thisId=779055; include("markHorse.php");?>>Miracle Cure</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Suehail&id=790698&rnumber=562397" <?php $thisId=790698; include("markHorse.php");?>>Suehail</a></li>

<ol> 
</ol> 
</ol>