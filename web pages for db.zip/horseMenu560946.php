
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks817419 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817419","http://www.racingpost.com/horses/result_home.sd?race_id=560116");

var horseLinks810453 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810453","http://www.racingpost.com/horses/result_home.sd?race_id=553766","http://www.racingpost.com/horses/result_home.sd?race_id=558093","http://www.racingpost.com/horses/result_home.sd?race_id=560098");

var horseLinks818215 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818215");

var horseLinks816653 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816653","http://www.racingpost.com/horses/result_home.sd?race_id=559239");

var horseLinks816124 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816124","http://www.racingpost.com/horses/result_home.sd?race_id=559239","http://www.racingpost.com/horses/result_home.sd?race_id=560058");

var horseLinks818216 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818216");

var horseLinks818217 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818217");

var horseLinks817676 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817676","http://www.racingpost.com/horses/result_home.sd?race_id=560477");

var horseLinks815506 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815506","http://www.racingpost.com/horses/result_home.sd?race_id=560061");

var horseLinks818218 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818218");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560946" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560946" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Barefoot+Sandy&id=817419&rnumber=560946" <?php $thisId=817419; include("markHorse.php");?>>Barefoot Sandy</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Blue+Nova&id=810453&rnumber=560946" <?php $thisId=810453; include("markHorse.php");?>>Blue Nova</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Centred&id=818215&rnumber=560946" <?php $thisId=818215; include("markHorse.php");?>>Centred</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Duchess+Of+Gazeley&id=816653&rnumber=560946" <?php $thisId=816653; include("markHorse.php");?>>Duchess Of Gazeley</a></li>

<ol> 
<li><a href="horse.php?name=Duchess+Of+Gazeley&id=816653&rnumber=560946&url=/horses/result_home.sd?race_id=559239" id='h2hFormLink'>Heading North </a></li> 
</ol> 
<li> <a href="horse.php?name=Heading+North&id=816124&rnumber=560946" <?php $thisId=816124; include("markHorse.php");?>>Heading North</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Kiwani+Bay&id=818216&rnumber=560946" <?php $thisId=818216; include("markHorse.php");?>>Kiwani Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Love+Magic&id=818217&rnumber=560946" <?php $thisId=818217; include("markHorse.php");?>>Love Magic</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Privacy+Order&id=817676&rnumber=560946" <?php $thisId=817676; include("markHorse.php");?>>Privacy Order</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sand+Grouse&id=815506&rnumber=560946" <?php $thisId=815506; include("markHorse.php");?>>Sand Grouse</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Snow+Rose&id=818218&rnumber=560946" <?php $thisId=818218; include("markHorse.php");?>>Snow Rose</a></li>

<ol> 
</ol> 
</ol>