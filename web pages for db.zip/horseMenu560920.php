
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks760928 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=760928","http://www.racingpost.com/horses/result_home.sd?race_id=509500","http://www.racingpost.com/horses/result_home.sd?race_id=510348","http://www.racingpost.com/horses/result_home.sd?race_id=510953","http://www.racingpost.com/horses/result_home.sd?race_id=522889","http://www.racingpost.com/horses/result_home.sd?race_id=531901","http://www.racingpost.com/horses/result_home.sd?race_id=541410","http://www.racingpost.com/horses/result_home.sd?race_id=543184","http://www.racingpost.com/horses/result_home.sd?race_id=547328","http://www.racingpost.com/horses/result_home.sd?race_id=549114","http://www.racingpost.com/horses/result_home.sd?race_id=551246","http://www.racingpost.com/horses/result_home.sd?race_id=557043");

var horseLinks709806 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=709806","http://www.racingpost.com/horses/result_home.sd?race_id=460828","http://www.racingpost.com/horses/result_home.sd?race_id=464533","http://www.racingpost.com/horses/result_home.sd?race_id=465490","http://www.racingpost.com/horses/result_home.sd?race_id=466027","http://www.racingpost.com/horses/result_home.sd?race_id=466034","http://www.racingpost.com/horses/result_home.sd?race_id=466035","http://www.racingpost.com/horses/result_home.sd?race_id=467841","http://www.racingpost.com/horses/result_home.sd?race_id=470731","http://www.racingpost.com/horses/result_home.sd?race_id=473961","http://www.racingpost.com/horses/result_home.sd?race_id=474813","http://www.racingpost.com/horses/result_home.sd?race_id=479764","http://www.racingpost.com/horses/result_home.sd?race_id=481846","http://www.racingpost.com/horses/result_home.sd?race_id=492930","http://www.racingpost.com/horses/result_home.sd?race_id=493846","http://www.racingpost.com/horses/result_home.sd?race_id=497539","http://www.racingpost.com/horses/result_home.sd?race_id=500649","http://www.racingpost.com/horses/result_home.sd?race_id=500732","http://www.racingpost.com/horses/result_home.sd?race_id=536902","http://www.racingpost.com/horses/result_home.sd?race_id=538064","http://www.racingpost.com/horses/result_home.sd?race_id=540953","http://www.racingpost.com/horses/result_home.sd?race_id=543276","http://www.racingpost.com/horses/result_home.sd?race_id=545131","http://www.racingpost.com/horses/result_home.sd?race_id=547327","http://www.racingpost.com/horses/result_home.sd?race_id=550057","http://www.racingpost.com/horses/result_home.sd?race_id=553836","http://www.racingpost.com/horses/result_home.sd?race_id=557043","http://www.racingpost.com/horses/result_home.sd?race_id=558763","http://www.racingpost.com/horses/result_home.sd?race_id=559304");

var horseLinks701305 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=701305","http://www.racingpost.com/horses/result_home.sd?race_id=461394","http://www.racingpost.com/horses/result_home.sd?race_id=461818","http://www.racingpost.com/horses/result_home.sd?race_id=462297","http://www.racingpost.com/horses/result_home.sd?race_id=463841","http://www.racingpost.com/horses/result_home.sd?race_id=464677","http://www.racingpost.com/horses/result_home.sd?race_id=465674","http://www.racingpost.com/horses/result_home.sd?race_id=466157","http://www.racingpost.com/horses/result_home.sd?race_id=473132","http://www.racingpost.com/horses/result_home.sd?race_id=475194","http://www.racingpost.com/horses/result_home.sd?race_id=476583","http://www.racingpost.com/horses/result_home.sd?race_id=478932","http://www.racingpost.com/horses/result_home.sd?race_id=481020","http://www.racingpost.com/horses/result_home.sd?race_id=482445","http://www.racingpost.com/horses/result_home.sd?race_id=485591","http://www.racingpost.com/horses/result_home.sd?race_id=487745","http://www.racingpost.com/horses/result_home.sd?race_id=488675","http://www.racingpost.com/horses/result_home.sd?race_id=489793","http://www.racingpost.com/horses/result_home.sd?race_id=492122","http://www.racingpost.com/horses/result_home.sd?race_id=492795","http://www.racingpost.com/horses/result_home.sd?race_id=510194","http://www.racingpost.com/horses/result_home.sd?race_id=510356","http://www.racingpost.com/horses/result_home.sd?race_id=512053","http://www.racingpost.com/horses/result_home.sd?race_id=513003","http://www.racingpost.com/horses/result_home.sd?race_id=515309","http://www.racingpost.com/horses/result_home.sd?race_id=517503","http://www.racingpost.com/horses/result_home.sd?race_id=526613","http://www.racingpost.com/horses/result_home.sd?race_id=529769","http://www.racingpost.com/horses/result_home.sd?race_id=531359","http://www.racingpost.com/horses/result_home.sd?race_id=532588","http://www.racingpost.com/horses/result_home.sd?race_id=534170","http://www.racingpost.com/horses/result_home.sd?race_id=534594","http://www.racingpost.com/horses/result_home.sd?race_id=535795","http://www.racingpost.com/horses/result_home.sd?race_id=536968","http://www.racingpost.com/horses/result_home.sd?race_id=537333","http://www.racingpost.com/horses/result_home.sd?race_id=538418","http://www.racingpost.com/horses/result_home.sd?race_id=539090","http://www.racingpost.com/horses/result_home.sd?race_id=553721","http://www.racingpost.com/horses/result_home.sd?race_id=554997","http://www.racingpost.com/horses/result_home.sd?race_id=558632","http://www.racingpost.com/horses/result_home.sd?race_id=560000");

var horseLinks790998 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790998","http://www.racingpost.com/horses/result_home.sd?race_id=536422","http://www.racingpost.com/horses/result_home.sd?race_id=537251","http://www.racingpost.com/horses/result_home.sd?race_id=537944","http://www.racingpost.com/horses/result_home.sd?race_id=539388","http://www.racingpost.com/horses/result_home.sd?race_id=541310","http://www.racingpost.com/horses/result_home.sd?race_id=554441","http://www.racingpost.com/horses/result_home.sd?race_id=555801","http://www.racingpost.com/horses/result_home.sd?race_id=558605","http://www.racingpost.com/horses/result_home.sd?race_id=560000","http://www.racingpost.com/horses/result_home.sd?race_id=560866");

var horseLinks793091 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793091","http://www.racingpost.com/horses/result_home.sd?race_id=538047","http://www.racingpost.com/horses/result_home.sd?race_id=538699","http://www.racingpost.com/horses/result_home.sd?race_id=539364","http://www.racingpost.com/horses/result_home.sd?race_id=543561","http://www.racingpost.com/horses/result_home.sd?race_id=546487","http://www.racingpost.com/horses/result_home.sd?race_id=547396","http://www.racingpost.com/horses/result_home.sd?race_id=548106","http://www.racingpost.com/horses/result_home.sd?race_id=549021","http://www.racingpost.com/horses/result_home.sd?race_id=551672","http://www.racingpost.com/horses/result_home.sd?race_id=554371","http://www.racingpost.com/horses/result_home.sd?race_id=556368","http://www.racingpost.com/horses/result_home.sd?race_id=557005","http://www.racingpost.com/horses/result_home.sd?race_id=559320","http://www.racingpost.com/horses/result_home.sd?race_id=560189","http://www.racingpost.com/horses/result_home.sd?race_id=560458");

var horseLinks789822 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=789822","http://www.racingpost.com/horses/result_home.sd?race_id=535005","http://www.racingpost.com/horses/result_home.sd?race_id=537192","http://www.racingpost.com/horses/result_home.sd?race_id=543676","http://www.racingpost.com/horses/result_home.sd?race_id=556408","http://www.racingpost.com/horses/result_home.sd?race_id=557183","http://www.racingpost.com/horses/result_home.sd?race_id=557440");

var horseLinks794671 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=794671","http://www.racingpost.com/horses/result_home.sd?race_id=540075","http://www.racingpost.com/horses/result_home.sd?race_id=541726","http://www.racingpost.com/horses/result_home.sd?race_id=556445","http://www.racingpost.com/horses/result_home.sd?race_id=560063","http://www.racingpost.com/horses/result_home.sd?race_id=560544","http://www.racingpost.com/horses/result_home.sd?race_id=560730");

var horseLinks792486 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792486","http://www.racingpost.com/horses/result_home.sd?race_id=537654","http://www.racingpost.com/horses/result_home.sd?race_id=538355","http://www.racingpost.com/horses/result_home.sd?race_id=541284","http://www.racingpost.com/horses/result_home.sd?race_id=553184","http://www.racingpost.com/horses/result_home.sd?race_id=555704","http://www.racingpost.com/horses/result_home.sd?race_id=559183");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560920" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560920" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Bold+Identity&id=760928&rnumber=560920" <?php $thisId=760928; include("markHorse.php");?>>Bold Identity</a></li>

<ol> 
<li><a href="horse.php?name=Bold+Identity&id=760928&rnumber=560920&url=/horses/result_home.sd?race_id=557043" id='h2hFormLink'>Kahsabelle </a></li> 
</ol> 
<li> <a href="horse.php?name=Kahsabelle&id=709806&rnumber=560920" <?php $thisId=709806; include("markHorse.php");?>>Kahsabelle</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tae+Kwon+Do&id=701305&rnumber=560920" <?php $thisId=701305; include("markHorse.php");?>>Tae Kwon Do</a></li>

<ol> 
<li><a href="horse.php?name=Tae+Kwon+Do&id=701305&rnumber=560920&url=/horses/result_home.sd?race_id=560000" id='h2hFormLink'>Cookieshake </a></li> 
</ol> 
<li> <a href="horse.php?name=Cookieshake&id=790998&rnumber=560920" <?php $thisId=790998; include("markHorse.php");?>>Cookieshake</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ctappers&id=793091&rnumber=560920" <?php $thisId=793091; include("markHorse.php");?>>Ctappers</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cash+Injection&id=789822&rnumber=560920" <?php $thisId=789822; include("markHorse.php");?>>Cash Injection</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Zarosa&id=794671&rnumber=560920" <?php $thisId=794671; include("markHorse.php");?>>Zarosa</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Stickleback&id=792486&rnumber=560920" <?php $thisId=792486; include("markHorse.php");?>>Stickleback</a></li>

<ol> 
</ol> 
</ol>