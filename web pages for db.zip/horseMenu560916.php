
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks812725 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812725","http://www.racingpost.com/horses/result_home.sd?race_id=554993","http://www.racingpost.com/horses/result_home.sd?race_id=556405");

var horseLinks805363 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805363","http://www.racingpost.com/horses/result_home.sd?race_id=559193","http://www.racingpost.com/horses/result_home.sd?race_id=560049");

var horseLinks805635 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805635","http://www.racingpost.com/horses/result_home.sd?race_id=553711","http://www.racingpost.com/horses/result_home.sd?race_id=555123","http://www.racingpost.com/horses/result_home.sd?race_id=556268","http://www.racingpost.com/horses/result_home.sd?race_id=559585");

var horseLinks440748 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=440748","http://www.racingpost.com/horses/result_home.sd?race_id=559725");

var horseLinks816762 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816762","http://www.racingpost.com/horses/result_home.sd?race_id=559585","http://www.racingpost.com/horses/result_home.sd?race_id=560049");

var horseLinks805661 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805661","http://www.racingpost.com/horses/result_home.sd?race_id=556405","http://www.racingpost.com/horses/result_home.sd?race_id=559522","http://www.racingpost.com/horses/result_home.sd?race_id=559703");

var horseLinks816185 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816185","http://www.racingpost.com/horses/result_home.sd?race_id=559633","http://www.racingpost.com/horses/result_home.sd?race_id=560143");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560916" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560916" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Bamurru&id=812725&rnumber=560916" <?php $thisId=812725; include("markHorse.php");?>>Bamurru</a></li>

<ol> 
<li><a href="horse.php?name=Bamurru&id=812725&rnumber=560916&url=/horses/result_home.sd?race_id=556405" id='h2hFormLink'>Silverrica </a></li> 
</ol> 
<li> <a href="horse.php?name=Dream+Cast&id=805363&rnumber=560916" <?php $thisId=805363; include("markHorse.php");?>>Dream Cast</a></li>

<ol> 
<li><a href="horse.php?name=Dream+Cast&id=805363&rnumber=560916&url=/horses/result_home.sd?race_id=560049" id='h2hFormLink'>Vincentti </a></li> 
</ol> 
<li> <a href="horse.php?name=Hardy+Red&id=805635&rnumber=560916" <?php $thisId=805635; include("markHorse.php");?>>Hardy Red</a></li>

<ol> 
<li><a href="horse.php?name=Hardy+Red&id=805635&rnumber=560916&url=/horses/result_home.sd?race_id=559585" id='h2hFormLink'>Vincentti </a></li> 
</ol> 
<li> <a href="horse.php?name=Vectis&id=440748&rnumber=560916" <?php $thisId=440748; include("markHorse.php");?>>Vectis</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Vincentti&id=816762&rnumber=560916" <?php $thisId=816762; include("markHorse.php");?>>Vincentti</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Silverrica&id=805661&rnumber=560916" <?php $thisId=805661; include("markHorse.php");?>>Silverrica</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Stormy+Times&id=816185&rnumber=560916" <?php $thisId=816185; include("markHorse.php");?>>Stormy Times</a></li>

<ol> 
</ol> 
</ol>