<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
  <head>
    <title></title>
  </head>
  <body>
  <?php





session_start();


/*get functions*/
include ("database.library.php");

/*get variables*/
$horse = $_GET['horse'];
$note = $_GET['horseNote'];
$userID = $_COOKIE['userId'];
/*$userID = 1;*/
$database = "a1270291_racing";

echo print_r($_COOKIE);

$var = $HTTP_COOKIE_VARS['userId'];

echo "0. Cookie Id:".$var."-i-".isset($_COOKIE['userId']);

echo "1. Horse-" . $horse . "-Note-" . $note . " <br>";

$getHorseIDQuery = "	SELECT id
  		FROM runners
  		WHERE name = '" . $horse . "';";

$horseID = getHorseID($horse, $getHorseIDQuery);

echo "2. HorseID " . $horseID . " <br>";

$insertHorseQuery = "	INSERT INTO runners
  	VALUES (null, '" . $horse . "')";


$getHorseNotes = " SELECT *
  	FROM notes
  	WHERE Horse_ID='" . $horseID . "' AND User_ID = '" . $userID . "';";

$insertNoteQuery = "	INSERT INTO notes 
  	VALUES ('" . $horseID . "' , '" . $userID . "', '" . $note . "')";

echo "3. Insert Note-" . $insertNoteQuery. " <BR>";

$updateNoteQuery = "	UPDATE notes SET notes = '" . $note . "' WHERE Horse_ID='" .
    $horseID . "' AND User_ID = '" . $userID . "';";


/*connect database*/
$connection = getConnection() or die("Could not connect: " . mysql_error());
mysql_select_db($database, $connection) or die("Error in selecting the database:" .
    mysql_error());


/*check if horse is in database*/
if (queryIsNull($getHorseIDQuery)) {

    echo "3. ghId -" . $getHorseIDQuery . " <br>";

    /*if horse is not indb then add it*/
    echo "4. IHS-" . $insertHorseQuery . " <br>";
    mysql_query($insertHorseQuery);

    /*get the horse's ID*/
    $horseID = getHorseID($horse, $getHorseIDQuery);

    /*rewrite insertNoteQuery*/
    $insertNoteQuery = "	INSERT INTO notes 
  		VALUES ('" . $horseID . "' , '" . $userID . "', '" . $note . "')";
    echo "5. INQ-" . $insertNoteQuery . " <br>";

    /*insert the note*/
    mysql_query($insertNoteQuery);


} else {

    /*if horse is in db check for notes from this user*/
    if (queryIsNull($getHorseNotes)) {

        /*if no notes from this user insert one*/
        echo "AAA-" . $insertNoteQuery;
        mysql_query($insertNoteQuery);
    } else {

        /*if there is anote by this user update it*/
        echo "BBB-" . $updateNoteQuery;
        mysql_query($updateNoteQuery);
    }
}

mysql_close($connection);





?>
  
  <?php


?>
  </body>
</html>