
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks793669 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793669","http://www.racingpost.com/horses/result_home.sd?race_id=549055","http://www.racingpost.com/horses/result_home.sd?race_id=549698","http://www.racingpost.com/horses/result_home.sd?race_id=559541","http://www.racingpost.com/horses/result_home.sd?race_id=560723","http://www.racingpost.com/horses/result_home.sd?race_id=561447");

var horseLinks794285 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=794285","http://www.racingpost.com/horses/result_home.sd?race_id=540283","http://www.racingpost.com/horses/result_home.sd?race_id=541479","http://www.racingpost.com/horses/result_home.sd?race_id=543053","http://www.racingpost.com/horses/result_home.sd?race_id=557050","http://www.racingpost.com/horses/result_home.sd?race_id=560724");

var horseLinks783924 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783924","http://www.racingpost.com/horses/result_home.sd?race_id=536673","http://www.racingpost.com/horses/result_home.sd?race_id=541195","http://www.racingpost.com/horses/result_home.sd?race_id=543053","http://www.racingpost.com/horses/result_home.sd?race_id=560724");

var horseLinks807962 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807962","http://www.racingpost.com/horses/result_home.sd?race_id=551963","http://www.racingpost.com/horses/result_home.sd?race_id=555941","http://www.racingpost.com/horses/result_home.sd?race_id=557212","http://www.racingpost.com/horses/result_home.sd?race_id=558544","http://www.racingpost.com/horses/result_home.sd?race_id=560250","http://www.racingpost.com/horses/result_home.sd?race_id=562044");

var horseLinks816489 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816489","http://www.racingpost.com/horses/result_home.sd?race_id=560675","http://www.racingpost.com/horses/result_home.sd?race_id=562044");

var horseLinks778854 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778854","http://www.racingpost.com/horses/result_home.sd?race_id=557973","http://www.racingpost.com/horses/result_home.sd?race_id=559536","http://www.racingpost.com/horses/result_home.sd?race_id=560246","http://www.racingpost.com/horses/result_home.sd?race_id=561176");

var horseLinks818005 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818005");

var horseLinks817466 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817466");

var horseLinks818006 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818006");

var horseLinks816684 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816684");

var horseLinks783938 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783938","http://www.racingpost.com/horses/result_home.sd?race_id=534203","http://www.racingpost.com/horses/result_home.sd?race_id=535185","http://www.racingpost.com/horses/result_home.sd?race_id=539255","http://www.racingpost.com/horses/result_home.sd?race_id=539979","http://www.racingpost.com/horses/result_home.sd?race_id=540364","http://www.racingpost.com/horses/result_home.sd?race_id=542094","http://www.racingpost.com/horses/result_home.sd?race_id=550979","http://www.racingpost.com/horses/result_home.sd?race_id=553427","http://www.racingpost.com/horses/result_home.sd?race_id=561899");

var horseLinks795427 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795427","http://www.racingpost.com/horses/result_home.sd?race_id=540849");

var horseLinks817190 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817190");

var horseLinks816041 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816041","http://www.racingpost.com/horses/result_home.sd?race_id=560246");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562398" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562398" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Arbitrageur&id=793669&rnumber=562398" <?php $thisId=793669; include("markHorse.php");?>>Arbitrageur</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Curia+Regis&id=794285&rnumber=562398" <?php $thisId=794285; include("markHorse.php");?>>Curia Regis</a></li>

<ol> 
<li><a href="horse.php?name=Curia+Regis&id=794285&rnumber=562398&url=/horses/result_home.sd?race_id=543053" id='h2hFormLink'>Free Spin </a></li> 
<li><a href="horse.php?name=Curia+Regis&id=794285&rnumber=562398&url=/horses/result_home.sd?race_id=560724" id='h2hFormLink'>Free Spin </a></li> 
</ol> 
<li> <a href="horse.php?name=Free+Spin&id=783924&rnumber=562398" <?php $thisId=783924; include("markHorse.php");?>>Free Spin</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Jumbo+Prado&id=807962&rnumber=562398" <?php $thisId=807962; include("markHorse.php");?>>Jumbo Prado</a></li>

<ol> 
<li><a href="horse.php?name=Jumbo+Prado&id=807962&rnumber=562398&url=/horses/result_home.sd?race_id=562044" id='h2hFormLink'>Massini's Trap </a></li> 
</ol> 
<li> <a href="horse.php?name=Massini's+Trap&id=816489&rnumber=562398" <?php $thisId=816489; include("markHorse.php");?>>Massini's Trap</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Spirituality&id=778854&rnumber=562398" <?php $thisId=778854; include("markHorse.php");?>>Spirituality</a></li>

<ol> 
<li><a href="horse.php?name=Spirituality&id=778854&rnumber=562398&url=/horses/result_home.sd?race_id=560246" id='h2hFormLink'>Whosaidimdignified </a></li> 
</ol> 
<li> <a href="horse.php?name=Akuna+Magic&id=818005&rnumber=562398" <?php $thisId=818005; include("markHorse.php");?>>Akuna Magic</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Amy+Farah+Fowler&id=817466&rnumber=562398" <?php $thisId=817466; include("markHorse.php");?>>Amy Farah Fowler</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Coco+Bella&id=818006&rnumber=562398" <?php $thisId=818006; include("markHorse.php");?>>Coco Bella</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Iveta&id=816684&rnumber=562398" <?php $thisId=816684; include("markHorse.php");?>>Iveta</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Rigoletta&id=783938&rnumber=562398" <?php $thisId=783938; include("markHorse.php");?>>Rigoletta</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sister+Rocks&id=795427&rnumber=562398" <?php $thisId=795427; include("markHorse.php");?>>Sister Rocks</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Whispering+Down&id=817190&rnumber=562398" <?php $thisId=817190; include("markHorse.php");?>>Whispering Down</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Whosaidimdignified&id=816041&rnumber=562398" <?php $thisId=816041; include("markHorse.php");?>>Whosaidimdignified</a></li>

<ol> 
</ol> 
</ol>