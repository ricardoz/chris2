<?php

/**
 * @author 
 * @copyright 2011
 */
$filename = "races" . date("Y-m-d") . ".php";
include ($filename);

?>