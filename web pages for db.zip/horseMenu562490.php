
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks808380 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=808380","http://www.racingpost.com/horses/result_home.sd?race_id=545426","http://www.racingpost.com/horses/result_home.sd?race_id=551111","http://www.racingpost.com/horses/result_home.sd?race_id=553114","http://www.racingpost.com/horses/result_home.sd?race_id=554713","http://www.racingpost.com/horses/result_home.sd?race_id=556864","http://www.racingpost.com/horses/result_home.sd?race_id=560088","http://www.racingpost.com/horses/result_home.sd?race_id=562171");

var horseLinks818238 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818238","http://www.racingpost.com/horses/result_home.sd?race_id=560969","http://www.racingpost.com/horses/result_home.sd?race_id=561664");

var horseLinks805509 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805509","http://www.racingpost.com/horses/result_home.sd?race_id=548477","http://www.racingpost.com/horses/result_home.sd?race_id=552402","http://www.racingpost.com/horses/result_home.sd?race_id=553418","http://www.racingpost.com/horses/result_home.sd?race_id=557480","http://www.racingpost.com/horses/result_home.sd?race_id=561629");

var horseLinks807830 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807830","http://www.racingpost.com/horses/result_home.sd?race_id=549992","http://www.racingpost.com/horses/result_home.sd?race_id=550578","http://www.racingpost.com/horses/result_home.sd?race_id=553759","http://www.racingpost.com/horses/result_home.sd?race_id=558171","http://www.racingpost.com/horses/result_home.sd?race_id=558738","http://www.racingpost.com/horses/result_home.sd?race_id=559678","http://www.racingpost.com/horses/result_home.sd?race_id=560144","http://www.racingpost.com/horses/result_home.sd?race_id=560482","http://www.racingpost.com/horses/result_home.sd?race_id=560572","http://www.racingpost.com/horses/result_home.sd?race_id=561659");

var horseLinks814301 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814301","http://www.racingpost.com/horses/result_home.sd?race_id=557034","http://www.racingpost.com/horses/result_home.sd?race_id=558078","http://www.racingpost.com/horses/result_home.sd?race_id=559736","http://www.racingpost.com/horses/result_home.sd?race_id=560421","http://www.racingpost.com/horses/result_home.sd?race_id=560751","http://www.racingpost.com/horses/result_home.sd?race_id=561758");

var horseLinks813907 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813907","http://www.racingpost.com/horses/result_home.sd?race_id=558264","http://www.racingpost.com/horses/result_home.sd?race_id=559566","http://www.racingpost.com/horses/result_home.sd?race_id=560136");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562490" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562490" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Baddilini&id=808380&rnumber=562490" <?php $thisId=808380; include("markHorse.php");?>>Baddilini</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Double+Your+Money&id=818238&rnumber=562490" <?php $thisId=818238; include("markHorse.php");?>>Double Your Money</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Jubilee+Games&id=805509&rnumber=562490" <?php $thisId=805509; include("markHorse.php");?>>Jubilee Games</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Rated&id=807830&rnumber=562490" <?php $thisId=807830; include("markHorse.php");?>>Rated</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Red+Cobra&id=814301&rnumber=562490" <?php $thisId=814301; include("markHorse.php");?>>Red Cobra</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sennockian+Star&id=813907&rnumber=562490" <?php $thisId=813907; include("markHorse.php");?>>Sennockian Star</a></li>

<ol> 
</ol> 
</ol>