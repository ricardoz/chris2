
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks743820 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=743820","http://www.racingpost.com/horses/result_home.sd?race_id=490908","http://www.racingpost.com/horses/result_home.sd?race_id=491278","http://www.racingpost.com/horses/result_home.sd?race_id=502848","http://www.racingpost.com/horses/result_home.sd?race_id=504258","http://www.racingpost.com/horses/result_home.sd?race_id=505013","http://www.racingpost.com/horses/result_home.sd?race_id=507568","http://www.racingpost.com/horses/result_home.sd?race_id=510749","http://www.racingpost.com/horses/result_home.sd?race_id=510765","http://www.racingpost.com/horses/result_home.sd?race_id=539051","http://www.racingpost.com/horses/result_home.sd?race_id=541513","http://www.racingpost.com/horses/result_home.sd?race_id=549521","http://www.racingpost.com/horses/result_home.sd?race_id=550527","http://www.racingpost.com/horses/result_home.sd?race_id=551181");

var horseLinks733715 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=733715","http://www.racingpost.com/horses/result_home.sd?race_id=486116","http://www.racingpost.com/horses/result_home.sd?race_id=487203","http://www.racingpost.com/horses/result_home.sd?race_id=488424","http://www.racingpost.com/horses/result_home.sd?race_id=503642","http://www.racingpost.com/horses/result_home.sd?race_id=509246","http://www.racingpost.com/horses/result_home.sd?race_id=512144","http://www.racingpost.com/horses/result_home.sd?race_id=513097","http://www.racingpost.com/horses/result_home.sd?race_id=513295","http://www.racingpost.com/horses/result_home.sd?race_id=515013","http://www.racingpost.com/horses/result_home.sd?race_id=527788","http://www.racingpost.com/horses/result_home.sd?race_id=531222","http://www.racingpost.com/horses/result_home.sd?race_id=534101","http://www.racingpost.com/horses/result_home.sd?race_id=535012","http://www.racingpost.com/horses/result_home.sd?race_id=537961","http://www.racingpost.com/horses/result_home.sd?race_id=538389","http://www.racingpost.com/horses/result_home.sd?race_id=547656","http://www.racingpost.com/horses/result_home.sd?race_id=551154","http://www.racingpost.com/horses/result_home.sd?race_id=555069","http://www.racingpost.com/horses/result_home.sd?race_id=556905","http://www.racingpost.com/horses/result_home.sd?race_id=562475");

var horseLinks765567 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=765567","http://www.racingpost.com/horses/result_home.sd?race_id=514056","http://www.racingpost.com/horses/result_home.sd?race_id=535019","http://www.racingpost.com/horses/result_home.sd?race_id=535760","http://www.racingpost.com/horses/result_home.sd?race_id=536935","http://www.racingpost.com/horses/result_home.sd?race_id=538311","http://www.racingpost.com/horses/result_home.sd?race_id=553094","http://www.racingpost.com/horses/result_home.sd?race_id=555068","http://www.racingpost.com/horses/result_home.sd?race_id=557419","http://www.racingpost.com/horses/result_home.sd?race_id=559139","http://www.racingpost.com/horses/result_home.sd?race_id=561357");

var horseLinks790350 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790350","http://www.racingpost.com/horses/result_home.sd?race_id=540489","http://www.racingpost.com/horses/result_home.sd?race_id=546987","http://www.racingpost.com/horses/result_home.sd?race_id=550508","http://www.racingpost.com/horses/result_home.sd?race_id=551682","http://www.racingpost.com/horses/result_home.sd?race_id=560044","http://www.racingpost.com/horses/result_home.sd?race_id=561356");

var horseLinks775292 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=775292","http://www.racingpost.com/horses/result_home.sd?race_id=538262","http://www.racingpost.com/horses/result_home.sd?race_id=539401","http://www.racingpost.com/horses/result_home.sd?race_id=540529","http://www.racingpost.com/horses/result_home.sd?race_id=549011","http://www.racingpost.com/horses/result_home.sd?race_id=554358","http://www.racingpost.com/horses/result_home.sd?race_id=558054");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562912" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562912" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Arctic+Cosmos&id=743820&rnumber=562912" <?php $thisId=743820; include("markHorse.php");?>>Arctic Cosmos</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Black+Spirit&id=733715&rnumber=562912" <?php $thisId=733715; include("markHorse.php");?>>Black Spirit</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lay+Time&id=765567&rnumber=562912" <?php $thisId=765567; include("markHorse.php");?>>Lay Time</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cameron+Highland&id=790350&rnumber=562912" <?php $thisId=790350; include("markHorse.php");?>>Cameron Highland</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Coquet&id=775292&rnumber=562912" <?php $thisId=775292; include("markHorse.php");?>>Coquet</a></li>

<ol> 
</ol> 
</ol>