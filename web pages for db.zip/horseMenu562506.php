
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks791187 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791187","http://www.racingpost.com/horses/result_home.sd?race_id=536526","http://www.racingpost.com/horses/result_home.sd?race_id=537985","http://www.racingpost.com/horses/result_home.sd?race_id=539048","http://www.racingpost.com/horses/result_home.sd?race_id=548100","http://www.racingpost.com/horses/result_home.sd?race_id=551646","http://www.racingpost.com/horses/result_home.sd?race_id=553156","http://www.racingpost.com/horses/result_home.sd?race_id=557408","http://www.racingpost.com/horses/result_home.sd?race_id=558707","http://www.racingpost.com/horses/result_home.sd?race_id=560480","http://www.racingpost.com/horses/result_home.sd?race_id=560999");

var horseLinks812142 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812142","http://www.racingpost.com/horses/result_home.sd?race_id=553731","http://www.racingpost.com/horses/result_home.sd?race_id=560456","http://www.racingpost.com/horses/result_home.sd?race_id=561722");

var horseLinks785858 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=785858","http://www.racingpost.com/horses/result_home.sd?race_id=532883","http://www.racingpost.com/horses/result_home.sd?race_id=538213","http://www.racingpost.com/horses/result_home.sd?race_id=538627","http://www.racingpost.com/horses/result_home.sd?race_id=539511","http://www.racingpost.com/horses/result_home.sd?race_id=543402","http://www.racingpost.com/horses/result_home.sd?race_id=544121","http://www.racingpost.com/horses/result_home.sd?race_id=545306","http://www.racingpost.com/horses/result_home.sd?race_id=552689","http://www.racingpost.com/horses/result_home.sd?race_id=554550","http://www.racingpost.com/horses/result_home.sd?race_id=556641","http://www.racingpost.com/horses/result_home.sd?race_id=559721","http://www.racingpost.com/horses/result_home.sd?race_id=560924","http://www.racingpost.com/horses/result_home.sd?race_id=561625");

var horseLinks800581 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800581","http://www.racingpost.com/horses/result_home.sd?race_id=543947","http://www.racingpost.com/horses/result_home.sd?race_id=545098","http://www.racingpost.com/horses/result_home.sd?race_id=545492");

var horseLinks795959 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795959","http://www.racingpost.com/horses/result_home.sd?race_id=544454","http://www.racingpost.com/horses/result_home.sd?race_id=546518","http://www.racingpost.com/horses/result_home.sd?race_id=549518","http://www.racingpost.com/horses/result_home.sd?race_id=554358","http://www.racingpost.com/horses/result_home.sd?race_id=558664","http://www.racingpost.com/horses/result_home.sd?race_id=559729","http://www.racingpost.com/horses/result_home.sd?race_id=561272");

var horseLinks783452 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783452","http://www.racingpost.com/horses/result_home.sd?race_id=535477","http://www.racingpost.com/horses/result_home.sd?race_id=535782","http://www.racingpost.com/horses/result_home.sd?race_id=536400","http://www.racingpost.com/horses/result_home.sd?race_id=538065","http://www.racingpost.com/horses/result_home.sd?race_id=554986","http://www.racingpost.com/horses/result_home.sd?race_id=556923","http://www.racingpost.com/horses/result_home.sd?race_id=559656","http://www.racingpost.com/horses/result_home.sd?race_id=560549");

var horseLinks783334 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783334","http://www.racingpost.com/horses/result_home.sd?race_id=533091","http://www.racingpost.com/horses/result_home.sd?race_id=534258","http://www.racingpost.com/horses/result_home.sd?race_id=535627","http://www.racingpost.com/horses/result_home.sd?race_id=543576","http://www.racingpost.com/horses/result_home.sd?race_id=545716","http://www.racingpost.com/horses/result_home.sd?race_id=546822","http://www.racingpost.com/horses/result_home.sd?race_id=552470","http://www.racingpost.com/horses/result_home.sd?race_id=559203","http://www.racingpost.com/horses/result_home.sd?race_id=561225");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562506" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562506" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Presburg&id=791187&rnumber=562506" <?php $thisId=791187; include("markHorse.php");?>>Presburg</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Emerald+Invader&id=812142&rnumber=562506" <?php $thisId=812142; include("markHorse.php");?>>Emerald Invader</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Aquilonius&id=785858&rnumber=562506" <?php $thisId=785858; include("markHorse.php");?>>Aquilonius</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ashdown+Lad&id=800581&rnumber=562506" <?php $thisId=800581; include("markHorse.php");?>>Ashdown Lad</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Zaina&id=795959&rnumber=562506" <?php $thisId=795959; include("markHorse.php");?>>Zaina</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Gold+Sceptre&id=783452&rnumber=562506" <?php $thisId=783452; include("markHorse.php");?>>Gold Sceptre</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Island+Melody&id=783334&rnumber=562506" <?php $thisId=783334; include("markHorse.php");?>>Island Melody</a></li>

<ol> 
</ol> 
</ol>