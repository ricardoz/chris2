
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks817126 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817126","http://www.racingpost.com/horses/result_home.sd?race_id=560019");

var horseLinks805358 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805358","http://www.racingpost.com/horses/result_home.sd?race_id=558696","http://www.racingpost.com/horses/result_home.sd?race_id=559628","http://www.racingpost.com/horses/result_home.sd?race_id=560106");

var horseLinks805182 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805182","http://www.racingpost.com/horses/result_home.sd?race_id=560019");

var horseLinks802532 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802532");

var horseLinks814869 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814869","http://www.racingpost.com/horses/result_home.sd?race_id=557406");

var horseLinks817682 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817682");

var horseLinks813929 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813929","http://www.racingpost.com/horses/result_home.sd?race_id=556281","http://www.racingpost.com/horses/result_home.sd?race_id=560143");

var horseLinks811133 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=811133","http://www.racingpost.com/horses/result_home.sd?race_id=559288","http://www.racingpost.com/horses/result_home.sd?race_id=560143");

var horseLinks818297 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818297");

var horseLinks816928 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816928","http://www.racingpost.com/horses/result_home.sd?race_id=560416","http://www.racingpost.com/horses/result_home.sd?race_id=560545");

var horseLinks817971 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817971");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561238" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561238" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=African+Oil&id=817126&rnumber=561238" <?php $thisId=817126; include("markHorse.php");?>>African Oil</a></li>

<ol> 
<li><a href="horse.php?name=African+Oil&id=817126&rnumber=561238&url=/horses/result_home.sd?race_id=560019" id='h2hFormLink'>Extrasolar </a></li> 
</ol> 
<li> <a href="horse.php?name=Colmar+Kid&id=805358&rnumber=561238" <?php $thisId=805358; include("markHorse.php");?>>Colmar Kid</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Extrasolar&id=805182&rnumber=561238" <?php $thisId=805182; include("markHorse.php");?>>Extrasolar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Global+Icon&id=802532&rnumber=561238" <?php $thisId=802532; include("markHorse.php");?>>Global Icon</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Imperial+Oak&id=814869&rnumber=561238" <?php $thisId=814869; include("markHorse.php");?>>Imperial Oak</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Marju+Prince&id=817682&rnumber=561238" <?php $thisId=817682; include("markHorse.php");?>>Marju Prince</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Overrider&id=813929&rnumber=561238" <?php $thisId=813929; include("markHorse.php");?>>Overrider</a></li>

<ol> 
<li><a href="horse.php?name=Overrider&id=813929&rnumber=561238&url=/horses/result_home.sd?race_id=560143" id='h2hFormLink'>Purcell </a></li> 
</ol> 
<li> <a href="horse.php?name=Purcell&id=811133&rnumber=561238" <?php $thisId=811133; include("markHorse.php");?>>Purcell</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Wayfoong+Express&id=818297&rnumber=561238" <?php $thisId=818297; include("markHorse.php");?>>Wayfoong Express</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Whiskey+N+Stout&id=816928&rnumber=561238" <?php $thisId=816928; include("markHorse.php");?>>Whiskey N Stout</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Birdlover&id=817971&rnumber=561238" <?php $thisId=817971; include("markHorse.php");?>>Birdlover</a></li>

<ol> 
</ol> 
</ol>