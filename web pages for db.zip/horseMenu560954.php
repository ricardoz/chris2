
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks799948 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=799948","http://www.racingpost.com/horses/result_home.sd?race_id=552533","http://www.racingpost.com/horses/result_home.sd?race_id=554320");

var horseLinks813416 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813416","http://www.racingpost.com/horses/result_home.sd?race_id=559358","http://www.racingpost.com/horses/result_home.sd?race_id=559661");

var horseLinks792147 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792147","http://www.racingpost.com/horses/result_home.sd?race_id=538393","http://www.racingpost.com/horses/result_home.sd?race_id=538646","http://www.racingpost.com/horses/result_home.sd?race_id=539396","http://www.racingpost.com/horses/result_home.sd?race_id=549988","http://www.racingpost.com/horses/result_home.sd?race_id=558192");

var horseLinks809224 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809224","http://www.racingpost.com/horses/result_home.sd?race_id=552472","http://www.racingpost.com/horses/result_home.sd?race_id=553908");

var horseLinks793654 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793654","http://www.racingpost.com/horses/result_home.sd?race_id=558589","http://www.racingpost.com/horses/result_home.sd?race_id=559292");

var horseLinks813319 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813319");

var horseLinks793796 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793796","http://www.racingpost.com/horses/result_home.sd?race_id=540117","http://www.racingpost.com/horses/result_home.sd?race_id=552465","http://www.racingpost.com/horses/result_home.sd?race_id=557511");

var horseLinks818227 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818227");

var horseLinks818228 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818228");

var horseLinks784811 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=784811","http://www.racingpost.com/horses/result_home.sd?race_id=540056","http://www.racingpost.com/horses/result_home.sd?race_id=551204");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560954" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560954" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Orla&id=799948&rnumber=560954" <?php $thisId=799948; include("markHorse.php");?>>Orla</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Afraah&id=813416&rnumber=560954" <?php $thisId=813416; include("markHorse.php");?>>Afraah</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Bana+Wu&id=792147&rnumber=560954" <?php $thisId=792147; include("markHorse.php");?>>Bana Wu</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Caphene&id=809224&rnumber=560954" <?php $thisId=809224; include("markHorse.php");?>>Caphene</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Divea&id=793654&rnumber=560954" <?php $thisId=793654; include("markHorse.php");?>>Divea</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Entitlement&id=813319&rnumber=560954" <?php $thisId=813319; include("markHorse.php");?>>Entitlement</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Miracle+Maid&id=793796&rnumber=560954" <?php $thisId=793796; include("markHorse.php");?>>Miracle Maid</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Miss+Fortywinks&id=818227&rnumber=560954" <?php $thisId=818227; include("markHorse.php");?>>Miss Fortywinks</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mystic+Melody&id=818228&rnumber=560954" <?php $thisId=818228; include("markHorse.php");?>>Mystic Melody</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Still+I'm+A+Star&id=784811&rnumber=560954" <?php $thisId=784811; include("markHorse.php");?>>Still I'm A Star</a></li>

<ol> 
</ol> 
</ol>