
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks795399 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795399","http://www.racingpost.com/horses/result_home.sd?race_id=541127","http://www.racingpost.com/horses/result_home.sd?race_id=541856","http://www.racingpost.com/horses/result_home.sd?race_id=549468","http://www.racingpost.com/horses/result_home.sd?race_id=553690","http://www.racingpost.com/horses/result_home.sd?race_id=554986","http://www.racingpost.com/horses/result_home.sd?race_id=559669");

var horseLinks786934 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=786934","http://www.racingpost.com/horses/result_home.sd?race_id=535697","http://www.racingpost.com/horses/result_home.sd?race_id=542333","http://www.racingpost.com/horses/result_home.sd?race_id=553796","http://www.racingpost.com/horses/result_home.sd?race_id=555766","http://www.racingpost.com/horses/result_home.sd?race_id=556916");

var horseLinks761484 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=761484","http://www.racingpost.com/horses/result_home.sd?race_id=512761","http://www.racingpost.com/horses/result_home.sd?race_id=513488","http://www.racingpost.com/horses/result_home.sd?race_id=513747","http://www.racingpost.com/horses/result_home.sd?race_id=533068","http://www.racingpost.com/horses/result_home.sd?race_id=534531","http://www.racingpost.com/horses/result_home.sd?race_id=535277","http://www.racingpost.com/horses/result_home.sd?race_id=535786","http://www.racingpost.com/horses/result_home.sd?race_id=550568","http://www.racingpost.com/horses/result_home.sd?race_id=551689","http://www.racingpost.com/horses/result_home.sd?race_id=552383","http://www.racingpost.com/horses/result_home.sd?race_id=555697","http://www.racingpost.com/horses/result_home.sd?race_id=557576","http://www.racingpost.com/horses/result_home.sd?race_id=559625");

var horseLinks793570 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793570","http://www.racingpost.com/horses/result_home.sd?race_id=540528","http://www.racingpost.com/horses/result_home.sd?race_id=555128","http://www.racingpost.com/horses/result_home.sd?race_id=556445","http://www.racingpost.com/horses/result_home.sd?race_id=559676");

var horseLinks797418 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=797418","http://www.racingpost.com/horses/result_home.sd?race_id=542885","http://www.racingpost.com/horses/result_home.sd?race_id=552361","http://www.racingpost.com/horses/result_home.sd?race_id=554336","http://www.racingpost.com/horses/result_home.sd?race_id=556449","http://www.racingpost.com/horses/result_home.sd?race_id=560454");

var horseLinks783777 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783777","http://www.racingpost.com/horses/result_home.sd?race_id=528902","http://www.racingpost.com/horses/result_home.sd?race_id=530399","http://www.racingpost.com/horses/result_home.sd?race_id=533594","http://www.racingpost.com/horses/result_home.sd?race_id=533978","http://www.racingpost.com/horses/result_home.sd?race_id=536107","http://www.racingpost.com/horses/result_home.sd?race_id=536900","http://www.racingpost.com/horses/result_home.sd?race_id=537076","http://www.racingpost.com/horses/result_home.sd?race_id=538727","http://www.racingpost.com/horses/result_home.sd?race_id=539743","http://www.racingpost.com/horses/result_home.sd?race_id=540918","http://www.racingpost.com/horses/result_home.sd?race_id=549990","http://www.racingpost.com/horses/result_home.sd?race_id=551723","http://www.racingpost.com/horses/result_home.sd?race_id=555723","http://www.racingpost.com/horses/result_home.sd?race_id=556876","http://www.racingpost.com/horses/result_home.sd?race_id=558606");

var horseLinks718065 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=718065","http://www.racingpost.com/horses/result_home.sd?race_id=505635","http://www.racingpost.com/horses/result_home.sd?race_id=508131","http://www.racingpost.com/horses/result_home.sd?race_id=510025","http://www.racingpost.com/horses/result_home.sd?race_id=529639","http://www.racingpost.com/horses/result_home.sd?race_id=535330","http://www.racingpost.com/horses/result_home.sd?race_id=536506","http://www.racingpost.com/horses/result_home.sd?race_id=537175","http://www.racingpost.com/horses/result_home.sd?race_id=538965","http://www.racingpost.com/horses/result_home.sd?race_id=539586","http://www.racingpost.com/horses/result_home.sd?race_id=540060","http://www.racingpost.com/horses/result_home.sd?race_id=554335","http://www.racingpost.com/horses/result_home.sd?race_id=556370","http://www.racingpost.com/horses/result_home.sd?race_id=560827");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560918" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560918" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Supaheart&id=795399&rnumber=560918" <?php $thisId=795399; include("markHorse.php");?>>Supaheart</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Santarini&id=786934&rnumber=560918" <?php $thisId=786934; include("markHorse.php");?>>Santarini</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Zing+Wing&id=761484&rnumber=560918" <?php $thisId=761484; include("markHorse.php");?>>Zing Wing</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Valley+Queen&id=793570&rnumber=560918" <?php $thisId=793570; include("markHorse.php");?>>Valley Queen</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Autumn+Fire&id=797418&rnumber=560918" <?php $thisId=797418; include("markHorse.php");?>>Autumn Fire</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Basantee&id=783777&rnumber=560918" <?php $thisId=783777; include("markHorse.php");?>>Basantee</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Croeso+Mawr&id=718065&rnumber=560918" <?php $thisId=718065; include("markHorse.php");?>>Croeso Mawr</a></li>

<ol> 
</ol> 
</ol>