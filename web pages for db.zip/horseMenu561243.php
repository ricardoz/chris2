
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks813248 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813248","http://www.racingpost.com/horses/result_home.sd?race_id=555075","http://www.racingpost.com/horses/result_home.sd?race_id=556844","http://www.racingpost.com/horses/result_home.sd?race_id=557448");

var horseLinks816413 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816413","http://www.racingpost.com/horses/result_home.sd?race_id=559743","http://www.racingpost.com/horses/result_home.sd?race_id=560565","http://www.racingpost.com/horses/result_home.sd?race_id=560751");

var horseLinks817062 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817062","http://www.racingpost.com/horses/result_home.sd?race_id=559736");

var horseLinks815003 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815003","http://www.racingpost.com/horses/result_home.sd?race_id=558071","http://www.racingpost.com/horses/result_home.sd?race_id=559987");

var horseLinks813827 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813827","http://www.racingpost.com/horses/result_home.sd?race_id=556383","http://www.racingpost.com/horses/result_home.sd?race_id=557447","http://www.racingpost.com/horses/result_home.sd?race_id=558581","http://www.racingpost.com/horses/result_home.sd?race_id=559606","http://www.racingpost.com/horses/result_home.sd?race_id=560483");

var horseLinks809377 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809377","http://www.racingpost.com/horses/result_home.sd?race_id=553555","http://www.racingpost.com/horses/result_home.sd?race_id=555934","http://www.racingpost.com/horses/result_home.sd?race_id=557856");

var horseLinks809367 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809367","http://www.racingpost.com/horses/result_home.sd?race_id=551637","http://www.racingpost.com/horses/result_home.sd?race_id=553065","http://www.racingpost.com/horses/result_home.sd?race_id=554380","http://www.racingpost.com/horses/result_home.sd?race_id=559262","http://www.racingpost.com/horses/result_home.sd?race_id=560109","http://www.racingpost.com/horses/result_home.sd?race_id=560554");

var horseLinks816185 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816185","http://www.racingpost.com/horses/result_home.sd?race_id=559633","http://www.racingpost.com/horses/result_home.sd?race_id=560143");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561243" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561243" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Baltic+Prince&id=813248&rnumber=561243" <?php $thisId=813248; include("markHorse.php");?>>Baltic Prince</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Multisure&id=816413&rnumber=561243" <?php $thisId=816413; include("markHorse.php");?>>Multisure</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Welliesinthewater&id=817062&rnumber=561243" <?php $thisId=817062; include("markHorse.php");?>>Welliesinthewater</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dashing+Storm&id=815003&rnumber=561243" <?php $thisId=815003; include("markHorse.php");?>>Dashing Storm</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Grievous+Angel&id=813827&rnumber=561243" <?php $thisId=813827; include("markHorse.php");?>>Grievous Angel</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Last+Minute+Lisa&id=809377&rnumber=561243" <?php $thisId=809377; include("markHorse.php");?>>Last Minute Lisa</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mace+The+Ace&id=809367&rnumber=561243" <?php $thisId=809367; include("markHorse.php");?>>Mace The Ace</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Stormy+Times&id=816185&rnumber=561243" <?php $thisId=816185; include("markHorse.php");?>>Stormy Times</a></li>

<ol> 
</ol> 
</ol>