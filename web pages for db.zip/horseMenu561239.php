
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks718732 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=718732","http://www.racingpost.com/horses/result_home.sd?race_id=478266","http://www.racingpost.com/horses/result_home.sd?race_id=482770","http://www.racingpost.com/horses/result_home.sd?race_id=483334","http://www.racingpost.com/horses/result_home.sd?race_id=485083","http://www.racingpost.com/horses/result_home.sd?race_id=486857","http://www.racingpost.com/horses/result_home.sd?race_id=487670","http://www.racingpost.com/horses/result_home.sd?race_id=490515","http://www.racingpost.com/horses/result_home.sd?race_id=493203","http://www.racingpost.com/horses/result_home.sd?race_id=500168","http://www.racingpost.com/horses/result_home.sd?race_id=500590","http://www.racingpost.com/horses/result_home.sd?race_id=501740","http://www.racingpost.com/horses/result_home.sd?race_id=504300","http://www.racingpost.com/horses/result_home.sd?race_id=506272","http://www.racingpost.com/horses/result_home.sd?race_id=507610","http://www.racingpost.com/horses/result_home.sd?race_id=508540","http://www.racingpost.com/horses/result_home.sd?race_id=509718","http://www.racingpost.com/horses/result_home.sd?race_id=510544","http://www.racingpost.com/horses/result_home.sd?race_id=511321","http://www.racingpost.com/horses/result_home.sd?race_id=512654","http://www.racingpost.com/horses/result_home.sd?race_id=556282","http://www.racingpost.com/horses/result_home.sd?race_id=558630","http://www.racingpost.com/horses/result_home.sd?race_id=559580","http://www.racingpost.com/horses/result_home.sd?race_id=560543");

var horseLinks725528 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=725528","http://www.racingpost.com/horses/result_home.sd?race_id=480558","http://www.racingpost.com/horses/result_home.sd?race_id=491340","http://www.racingpost.com/horses/result_home.sd?race_id=492969","http://www.racingpost.com/horses/result_home.sd?race_id=505112","http://www.racingpost.com/horses/result_home.sd?race_id=507111","http://www.racingpost.com/horses/result_home.sd?race_id=515742","http://www.racingpost.com/horses/result_home.sd?race_id=516587","http://www.racingpost.com/horses/result_home.sd?race_id=521523","http://www.racingpost.com/horses/result_home.sd?race_id=525510","http://www.racingpost.com/horses/result_home.sd?race_id=527193","http://www.racingpost.com/horses/result_home.sd?race_id=529782","http://www.racingpost.com/horses/result_home.sd?race_id=532021","http://www.racingpost.com/horses/result_home.sd?race_id=532606","http://www.racingpost.com/horses/result_home.sd?race_id=537744","http://www.racingpost.com/horses/result_home.sd?race_id=538807","http://www.racingpost.com/horses/result_home.sd?race_id=539085","http://www.racingpost.com/horses/result_home.sd?race_id=540199","http://www.racingpost.com/horses/result_home.sd?race_id=541336","http://www.racingpost.com/horses/result_home.sd?race_id=542814","http://www.racingpost.com/horses/result_home.sd?race_id=544007","http://www.racingpost.com/horses/result_home.sd?race_id=544354","http://www.racingpost.com/horses/result_home.sd?race_id=545563","http://www.racingpost.com/horses/result_home.sd?race_id=547315","http://www.racingpost.com/horses/result_home.sd?race_id=549557","http://www.racingpost.com/horses/result_home.sd?race_id=560515");

var horseLinks784693 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=784693","http://www.racingpost.com/horses/result_home.sd?race_id=529635","http://www.racingpost.com/horses/result_home.sd?race_id=532490","http://www.racingpost.com/horses/result_home.sd?race_id=533660","http://www.racingpost.com/horses/result_home.sd?race_id=535303","http://www.racingpost.com/horses/result_home.sd?race_id=553754","http://www.racingpost.com/horses/result_home.sd?race_id=557580","http://www.racingpost.com/horses/result_home.sd?race_id=559582");

var horseLinks761491 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=761491","http://www.racingpost.com/horses/result_home.sd?race_id=508600","http://www.racingpost.com/horses/result_home.sd?race_id=509594","http://www.racingpost.com/horses/result_home.sd?race_id=510511","http://www.racingpost.com/horses/result_home.sd?race_id=512736","http://www.racingpost.com/horses/result_home.sd?race_id=533558","http://www.racingpost.com/horses/result_home.sd?race_id=535004","http://www.racingpost.com/horses/result_home.sd?race_id=536190","http://www.racingpost.com/horses/result_home.sd?race_id=536819","http://www.racingpost.com/horses/result_home.sd?race_id=537175","http://www.racingpost.com/horses/result_home.sd?race_id=537927","http://www.racingpost.com/horses/result_home.sd?race_id=539029","http://www.racingpost.com/horses/result_home.sd?race_id=541506","http://www.racingpost.com/horses/result_home.sd?race_id=551206","http://www.racingpost.com/horses/result_home.sd?race_id=554340","http://www.racingpost.com/horses/result_home.sd?race_id=556403","http://www.racingpost.com/horses/result_home.sd?race_id=559580");

var horseLinks762482 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=762482","http://www.racingpost.com/horses/result_home.sd?race_id=510729","http://www.racingpost.com/horses/result_home.sd?race_id=512381","http://www.racingpost.com/horses/result_home.sd?race_id=515256","http://www.racingpost.com/horses/result_home.sd?race_id=521477","http://www.racingpost.com/horses/result_home.sd?race_id=523211","http://www.racingpost.com/horses/result_home.sd?race_id=528367","http://www.racingpost.com/horses/result_home.sd?race_id=529599","http://www.racingpost.com/horses/result_home.sd?race_id=532462","http://www.racingpost.com/horses/result_home.sd?race_id=534143","http://www.racingpost.com/horses/result_home.sd?race_id=553758","http://www.racingpost.com/horses/result_home.sd?race_id=556375","http://www.racingpost.com/horses/result_home.sd?race_id=557391","http://www.racingpost.com/horses/result_home.sd?race_id=559152","http://www.racingpost.com/horses/result_home.sd?race_id=560052");

var horseLinks714377 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=714377","http://www.racingpost.com/horses/result_home.sd?race_id=464974","http://www.racingpost.com/horses/result_home.sd?race_id=465319","http://www.racingpost.com/horses/result_home.sd?race_id=465498","http://www.racingpost.com/horses/result_home.sd?race_id=474356","http://www.racingpost.com/horses/result_home.sd?race_id=476074","http://www.racingpost.com/horses/result_home.sd?race_id=478259","http://www.racingpost.com/horses/result_home.sd?race_id=479639","http://www.racingpost.com/horses/result_home.sd?race_id=480994","http://www.racingpost.com/horses/result_home.sd?race_id=483205","http://www.racingpost.com/horses/result_home.sd?race_id=483826","http://www.racingpost.com/horses/result_home.sd?race_id=484995","http://www.racingpost.com/horses/result_home.sd?race_id=485634","http://www.racingpost.com/horses/result_home.sd?race_id=486974","http://www.racingpost.com/horses/result_home.sd?race_id=488294","http://www.racingpost.com/horses/result_home.sd?race_id=489922","http://www.racingpost.com/horses/result_home.sd?race_id=509138","http://www.racingpost.com/horses/result_home.sd?race_id=509679","http://www.racingpost.com/horses/result_home.sd?race_id=510383","http://www.racingpost.com/horses/result_home.sd?race_id=510734","http://www.racingpost.com/horses/result_home.sd?race_id=511334","http://www.racingpost.com/horses/result_home.sd?race_id=512272","http://www.racingpost.com/horses/result_home.sd?race_id=513103","http://www.racingpost.com/horses/result_home.sd?race_id=514471","http://www.racingpost.com/horses/result_home.sd?race_id=516958","http://www.racingpost.com/horses/result_home.sd?race_id=517428","http://www.racingpost.com/horses/result_home.sd?race_id=518976","http://www.racingpost.com/horses/result_home.sd?race_id=519669","http://www.racingpost.com/horses/result_home.sd?race_id=519707","http://www.racingpost.com/horses/result_home.sd?race_id=525956","http://www.racingpost.com/horses/result_home.sd?race_id=529628","http://www.racingpost.com/horses/result_home.sd?race_id=530330","http://www.racingpost.com/horses/result_home.sd?race_id=531232","http://www.racingpost.com/horses/result_home.sd?race_id=532422","http://www.racingpost.com/horses/result_home.sd?race_id=533664","http://www.racingpost.com/horses/result_home.sd?race_id=536435","http://www.racingpost.com/horses/result_home.sd?race_id=536817","http://www.racingpost.com/horses/result_home.sd?race_id=537718","http://www.racingpost.com/horses/result_home.sd?race_id=554338","http://www.racingpost.com/horses/result_home.sd?race_id=556283","http://www.racingpost.com/horses/result_home.sd?race_id=556849","http://www.racingpost.com/horses/result_home.sd?race_id=558043","http://www.racingpost.com/horses/result_home.sd?race_id=560475");

var horseLinks787619 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=787619","http://www.racingpost.com/horses/result_home.sd?race_id=533048","http://www.racingpost.com/horses/result_home.sd?race_id=535234","http://www.racingpost.com/horses/result_home.sd?race_id=537614","http://www.racingpost.com/horses/result_home.sd?race_id=538263","http://www.racingpost.com/horses/result_home.sd?race_id=538991","http://www.racingpost.com/horses/result_home.sd?race_id=539728","http://www.racingpost.com/horses/result_home.sd?race_id=541040","http://www.racingpost.com/horses/result_home.sd?race_id=542719","http://www.racingpost.com/horses/result_home.sd?race_id=542729","http://www.racingpost.com/horses/result_home.sd?race_id=545423","http://www.racingpost.com/horses/result_home.sd?race_id=546112","http://www.racingpost.com/horses/result_home.sd?race_id=546822","http://www.racingpost.com/horses/result_home.sd?race_id=547658","http://www.racingpost.com/horses/result_home.sd?race_id=556870","http://www.racingpost.com/horses/result_home.sd?race_id=557431","http://www.racingpost.com/horses/result_home.sd?race_id=559127","http://www.racingpost.com/horses/result_home.sd?race_id=560831");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561239" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561239" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=King's+Masque&id=718732&rnumber=561239" <?php $thisId=718732; include("markHorse.php");?>>King's Masque</a></li>

<ol> 
<li><a href="horse.php?name=King's+Masque&id=718732&rnumber=561239&url=/horses/result_home.sd?race_id=559580" id='h2hFormLink'>Into The Wind </a></li> 
</ol> 
<li> <a href="horse.php?name=Cityar&id=725528&rnumber=561239" <?php $thisId=725528; include("markHorse.php");?>>Cityar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hawridge+Song&id=784693&rnumber=561239" <?php $thisId=784693; include("markHorse.php");?>>Hawridge Song</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Into+The+Wind&id=761491&rnumber=561239" <?php $thisId=761491; include("markHorse.php");?>>Into The Wind</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tijori&id=762482&rnumber=561239" <?php $thisId=762482; include("markHorse.php");?>>Tijori</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Urban+Space&id=714377&rnumber=561239" <?php $thisId=714377; include("markHorse.php");?>>Urban Space</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Anginola&id=787619&rnumber=561239" <?php $thisId=787619; include("markHorse.php");?>>Anginola</a></li>

<ol> 
</ol> 
</ol>