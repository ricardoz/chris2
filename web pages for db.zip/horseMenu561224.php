
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks812900 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812900","http://www.racingpost.com/horses/result_home.sd?race_id=558073","http://www.racingpost.com/horses/result_home.sd?race_id=560771");

var horseLinks815414 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815414","http://www.racingpost.com/horses/result_home.sd?race_id=558638");

var horseLinks810782 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810782","http://www.racingpost.com/horses/result_home.sd?race_id=555005","http://www.racingpost.com/horses/result_home.sd?race_id=555303","http://www.racingpost.com/horses/result_home.sd?race_id=557409","http://www.racingpost.com/horses/result_home.sd?race_id=559661");

var horseLinks778875 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778875","http://www.racingpost.com/horses/result_home.sd?race_id=536561","http://www.racingpost.com/horses/result_home.sd?race_id=537569","http://www.racingpost.com/horses/result_home.sd?race_id=537982","http://www.racingpost.com/horses/result_home.sd?race_id=538673","http://www.racingpost.com/horses/result_home.sd?race_id=553701","http://www.racingpost.com/horses/result_home.sd?race_id=554376","http://www.racingpost.com/horses/result_home.sd?race_id=555805","http://www.racingpost.com/horses/result_home.sd?race_id=559630","http://www.racingpost.com/horses/result_home.sd?race_id=560065","http://www.racingpost.com/horses/result_home.sd?race_id=560943");

var horseLinks817291 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817291");

var horseLinks791289 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791289","http://www.racingpost.com/horses/result_home.sd?race_id=536559");

var horseLinks816937 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816937","http://www.racingpost.com/horses/result_home.sd?race_id=560479");

var horseLinks816701 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816701","http://www.racingpost.com/horses/result_home.sd?race_id=559292");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561224" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561224" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Iz+She&id=812900&rnumber=561224" <?php $thisId=812900; include("markHorse.php");?>>Iz She</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Balcary+Bay&id=815414&rnumber=561224" <?php $thisId=815414; include("markHorse.php");?>>Balcary Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cool+Sky&id=810782&rnumber=561224" <?php $thisId=810782; include("markHorse.php");?>>Cool Sky</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dynamic+Duo&id=778875&rnumber=561224" <?php $thisId=778875; include("markHorse.php");?>>Dynamic Duo</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Refute&id=817291&rnumber=561224" <?php $thisId=817291; include("markHorse.php");?>>Refute</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Revered+Citizen&id=791289&rnumber=561224" <?php $thisId=791289; include("markHorse.php");?>>Revered Citizen</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tribal+I+D&id=816937&rnumber=561224" <?php $thisId=816937; include("markHorse.php");?>>Tribal I D</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Rokcella&id=816701&rnumber=561224" <?php $thisId=816701; include("markHorse.php");?>>Rokcella</a></li>

<ol> 
</ol> 
</ol>