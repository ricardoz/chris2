
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks819363 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819363","http://www.racingpost.com/horses/result_home.sd?race_id=563413");

var horseLinks819364 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819364","http://www.racingpost.com/horses/result_home.sd?race_id=563412");

var horseLinks819365 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819365","http://www.racingpost.com/horses/result_home.sd?race_id=563414");

var horseLinks816783 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816783","http://www.racingpost.com/horses/result_home.sd?race_id=561144");

var horseLinks816768 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816768","http://www.racingpost.com/horses/result_home.sd?race_id=561144");

var horseLinks816770 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816770","http://www.racingpost.com/horses/result_home.sd?race_id=561144");

var horseLinks819366 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819366","http://www.racingpost.com/horses/result_home.sd?race_id=563415");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=563402" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=563402" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Dreaming+Of+Julia&id=819363&rnumber=563402" <?php $thisId=819363; include("markHorse.php");?>>Dreaming Of Julia</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Teen+Pauline&id=819364&rnumber=563402" <?php $thisId=819364; include("markHorse.php");?>>Teen Pauline</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Corail&id=819365&rnumber=563402" <?php $thisId=819365; include("markHorse.php");?>>Corail</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=So+Many+Ways&id=816783&rnumber=563402" <?php $thisId=816783; include("markHorse.php");?>>So Many Ways</a></li>

<ol> 
<li><a href="horse.php?name=So+Many+Ways&id=816783&rnumber=563402&url=/horses/result_home.sd?race_id=561144" id='h2hFormLink'>Sweet Shirley Mae </a></li> 
<li><a href="horse.php?name=So+Many+Ways&id=816783&rnumber=563402&url=/horses/result_home.sd?race_id=561144" id='h2hFormLink'>Baby J </a></li> 
</ol> 
<li> <a href="horse.php?name=Sweet+Shirley+Mae&id=816768&rnumber=563402" <?php $thisId=816768; include("markHorse.php");?>>Sweet Shirley Mae</a></li>

<ol> 
<li><a href="horse.php?name=Sweet+Shirley+Mae&id=816768&rnumber=563402&url=/horses/result_home.sd?race_id=561144" id='h2hFormLink'>Baby J </a></li> 
</ol> 
<li> <a href="horse.php?name=Baby+J&id=816770&rnumber=563402" <?php $thisId=816770; include("markHorse.php");?>>Baby J</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Seasoned+Warrior&id=819366&rnumber=563402" <?php $thisId=819366; include("markHorse.php");?>>Seasoned Warrior</a></li>

<ol> 
</ol> 
</ol>