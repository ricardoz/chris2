
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks814152 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814152","http://www.racingpost.com/horses/result_home.sd?race_id=559652","http://www.racingpost.com/horses/result_home.sd?race_id=560930");

var horseLinks816298 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816298","http://www.racingpost.com/horses/result_home.sd?race_id=559129","http://www.racingpost.com/horses/result_home.sd?race_id=560505");

var horseLinks805248 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805248","http://www.racingpost.com/horses/result_home.sd?race_id=562384");

var horseLinks814016 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814016","http://www.racingpost.com/horses/result_home.sd?race_id=556447","http://www.racingpost.com/horses/result_home.sd?race_id=559647");

var horseLinks810995 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810995");

var horseLinks818950 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818950");

var horseLinks814868 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814868","http://www.racingpost.com/horses/result_home.sd?race_id=560098");

var horseLinks802221 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802221","http://www.racingpost.com/horses/result_home.sd?race_id=560525");

var horseLinks818962 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818962");

var horseLinks816998 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816998","http://www.racingpost.com/horses/result_home.sd?race_id=559670","http://www.racingpost.com/horses/result_home.sd?race_id=560825");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561719" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561719" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Captain+McCaw&id=814152&rnumber=561719" <?php $thisId=814152; include("markHorse.php");?>>Captain McCaw</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Emell&id=816298&rnumber=561719" <?php $thisId=816298; include("markHorse.php");?>>Emell</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lucky+Black+Star&id=805248&rnumber=561719" <?php $thisId=805248; include("markHorse.php");?>>Lucky Black Star</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Clement&id=814016&rnumber=561719" <?php $thisId=814016; include("markHorse.php");?>>Clement</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Perfect+Calm&id=810995&rnumber=561719" <?php $thisId=810995; include("markHorse.php");?>>Perfect Calm</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Unison&id=818950&rnumber=561719" <?php $thisId=818950; include("markHorse.php");?>>Unison</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Everreadyneddy&id=814868&rnumber=561719" <?php $thisId=814868; include("markHorse.php");?>>Everreadyneddy</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Elusive+Gold&id=802221&rnumber=561719" <?php $thisId=802221; include("markHorse.php");?>>Elusive Gold</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Jubilante&id=818962&rnumber=561719" <?php $thisId=818962; include("markHorse.php");?>>Jubilante</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Almalekiah&id=816998&rnumber=561719" <?php $thisId=816998; include("markHorse.php");?>>Almalekiah</a></li>

<ol> 
</ol> 
</ol>