
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks816836 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816836","http://www.racingpost.com/horses/result_home.sd?race_id=559628");

var horseLinks818220 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818220");

var horseLinks814801 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814801");

var horseLinks818235 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818235");

var horseLinks815262 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815262","http://www.racingpost.com/horses/result_home.sd?race_id=557570","http://www.racingpost.com/horses/result_home.sd?race_id=559278");

var horseLinks818232 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818232");

var horseLinks810665 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810665","http://www.racingpost.com/horses/result_home.sd?race_id=552464","http://www.racingpost.com/horses/result_home.sd?race_id=555056","http://www.racingpost.com/horses/result_home.sd?race_id=556904","http://www.racingpost.com/horses/result_home.sd?race_id=558116","http://www.racingpost.com/horses/result_home.sd?race_id=558734","http://www.racingpost.com/horses/result_home.sd?race_id=560894");

var horseLinks814705 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814705","http://www.racingpost.com/horses/result_home.sd?race_id=557570","http://www.racingpost.com/horses/result_home.sd?race_id=558705","http://www.racingpost.com/horses/result_home.sd?race_id=560087");

var horseLinks814695 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814695","http://www.racingpost.com/horses/result_home.sd?race_id=556922","http://www.racingpost.com/horses/result_home.sd?race_id=560034");

var horseLinks817172 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817172");

var horseLinks818226 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818226");

var horseLinks813522 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813522","http://www.racingpost.com/horses/result_home.sd?race_id=555694","http://www.racingpost.com/horses/result_home.sd?race_id=556336","http://www.racingpost.com/horses/result_home.sd?race_id=557535","http://www.racingpost.com/horses/result_home.sd?race_id=560825");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560965" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560965" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Altruism&id=816836&rnumber=560965" <?php $thisId=816836; include("markHorse.php");?>>Altruism</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cat+O'Mountain&id=818220&rnumber=560965" <?php $thisId=818220; include("markHorse.php");?>>Cat O'Mountain</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=East+Texas+Red&id=814801&rnumber=560965" <?php $thisId=814801; include("markHorse.php");?>>East Texas Red</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ennistown&id=818235&rnumber=560965" <?php $thisId=818235; include("markHorse.php");?>>Ennistown</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Glory+City&id=815262&rnumber=560965" <?php $thisId=815262; include("markHorse.php");?>>Glory City</a></li>

<ol> 
<li><a href="horse.php?name=Glory+City&id=815262&rnumber=560965&url=/horses/result_home.sd?race_id=557570" id='h2hFormLink'>Royal Caper </a></li> 
</ol> 
<li> <a href="horse.php?name=Misleading+Promise&id=818232&rnumber=560965" <?php $thisId=818232; include("markHorse.php");?>>Misleading Promise</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ocean+Applause&id=810665&rnumber=560965" <?php $thisId=810665; include("markHorse.php");?>>Ocean Applause</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Royal+Caper&id=814705&rnumber=560965" <?php $thisId=814705; include("markHorse.php");?>>Royal Caper</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sharjah&id=814695&rnumber=560965" <?php $thisId=814695; include("markHorse.php");?>>Sharjah</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Squire+Osbaldeston&id=817172&rnumber=560965" <?php $thisId=817172; include("markHorse.php");?>>Squire Osbaldeston</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tarikhi&id=818226&rnumber=560965" <?php $thisId=818226; include("markHorse.php");?>>Tarikhi</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lilly+May&id=813522&rnumber=560965" <?php $thisId=813522; include("markHorse.php");?>>Lilly May</a></li>

<ol> 
</ol> 
</ol>