
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks767592 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=767592","http://www.racingpost.com/horses/result_home.sd?race_id=514132","http://www.racingpost.com/horses/result_home.sd?race_id=515260","http://www.racingpost.com/horses/result_home.sd?race_id=534532","http://www.racingpost.com/horses/result_home.sd?race_id=535698","http://www.racingpost.com/horses/result_home.sd?race_id=536564","http://www.racingpost.com/horses/result_home.sd?race_id=537257","http://www.racingpost.com/horses/result_home.sd?race_id=539037","http://www.racingpost.com/horses/result_home.sd?race_id=540532","http://www.racingpost.com/horses/result_home.sd?race_id=557572","http://www.racingpost.com/horses/result_home.sd?race_id=558646","http://www.racingpost.com/horses/result_home.sd?race_id=560108","http://www.racingpost.com/horses/result_home.sd?race_id=560556");

var horseLinks796297 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=796297","http://www.racingpost.com/horses/result_home.sd?race_id=545713","http://www.racingpost.com/horses/result_home.sd?race_id=546510","http://www.racingpost.com/horses/result_home.sd?race_id=553729","http://www.racingpost.com/horses/result_home.sd?race_id=555668","http://www.racingpost.com/horses/result_home.sd?race_id=559630","http://www.racingpost.com/horses/result_home.sd?race_id=560556");

var horseLinks794202 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=794202","http://www.racingpost.com/horses/result_home.sd?race_id=539341","http://www.racingpost.com/horses/result_home.sd?race_id=540500","http://www.racingpost.com/horses/result_home.sd?race_id=542743","http://www.racingpost.com/horses/result_home.sd?race_id=553729","http://www.racingpost.com/horses/result_home.sd?race_id=555004","http://www.racingpost.com/horses/result_home.sd?race_id=556951","http://www.racingpost.com/horses/result_home.sd?race_id=560026");

var horseLinks790367 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790367","http://www.racingpost.com/horses/result_home.sd?race_id=535697","http://www.racingpost.com/horses/result_home.sd?race_id=537573","http://www.racingpost.com/horses/result_home.sd?race_id=538989","http://www.racingpost.com/horses/result_home.sd?race_id=554391","http://www.racingpost.com/horses/result_home.sd?race_id=557438","http://www.racingpost.com/horses/result_home.sd?race_id=560026");

var horseLinks787851 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=787851","http://www.racingpost.com/horses/result_home.sd?race_id=536001","http://www.racingpost.com/horses/result_home.sd?race_id=538757","http://www.racingpost.com/horses/result_home.sd?race_id=539219","http://www.racingpost.com/horses/result_home.sd?race_id=541178","http://www.racingpost.com/horses/result_home.sd?race_id=552140","http://www.racingpost.com/horses/result_home.sd?race_id=553734","http://www.racingpost.com/horses/result_home.sd?race_id=555107","http://www.racingpost.com/horses/result_home.sd?race_id=558697");

var horseLinks784636 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=784636","http://www.racingpost.com/horses/result_home.sd?race_id=529608","http://www.racingpost.com/horses/result_home.sd?race_id=530438","http://www.racingpost.com/horses/result_home.sd?race_id=531903","http://www.racingpost.com/horses/result_home.sd?race_id=533585","http://www.racingpost.com/horses/result_home.sd?race_id=534524","http://www.racingpost.com/horses/result_home.sd?race_id=535775","http://www.racingpost.com/horses/result_home.sd?race_id=536094","http://www.racingpost.com/horses/result_home.sd?race_id=536875","http://www.racingpost.com/horses/result_home.sd?race_id=537561","http://www.racingpost.com/horses/result_home.sd?race_id=537971","http://www.racingpost.com/horses/result_home.sd?race_id=538742","http://www.racingpost.com/horses/result_home.sd?race_id=539369","http://www.racingpost.com/horses/result_home.sd?race_id=540932","http://www.racingpost.com/horses/result_home.sd?race_id=550624","http://www.racingpost.com/horses/result_home.sd?race_id=553690","http://www.racingpost.com/horses/result_home.sd?race_id=555084","http://www.racingpost.com/horses/result_home.sd?race_id=556393","http://www.racingpost.com/horses/result_home.sd?race_id=557504","http://www.racingpost.com/horses/result_home.sd?race_id=559267","http://www.racingpost.com/horses/result_home.sd?race_id=560512");

var horseLinks790231 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790231","http://www.racingpost.com/horses/result_home.sd?race_id=535621","http://www.racingpost.com/horses/result_home.sd?race_id=536804","http://www.racingpost.com/horses/result_home.sd?race_id=537675","http://www.racingpost.com/horses/result_home.sd?race_id=558588","http://www.racingpost.com/horses/result_home.sd?race_id=559630");

var horseLinks784770 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=784770","http://www.racingpost.com/horses/result_home.sd?race_id=537642","http://www.racingpost.com/horses/result_home.sd?race_id=538764","http://www.racingpost.com/horses/result_home.sd?race_id=541564","http://www.racingpost.com/horses/result_home.sd?race_id=554391","http://www.racingpost.com/horses/result_home.sd?race_id=556361","http://www.racingpost.com/horses/result_home.sd?race_id=557576","http://www.racingpost.com/horses/result_home.sd?race_id=559701","http://www.racingpost.com/horses/result_home.sd?race_id=560507");

var horseLinks753153 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=753153","http://www.racingpost.com/horses/result_home.sd?race_id=514132","http://www.racingpost.com/horses/result_home.sd?race_id=515615","http://www.racingpost.com/horses/result_home.sd?race_id=526993","http://www.racingpost.com/horses/result_home.sd?race_id=529647","http://www.racingpost.com/horses/result_home.sd?race_id=532990","http://www.racingpost.com/horses/result_home.sd?race_id=534440","http://www.racingpost.com/horses/result_home.sd?race_id=535261","http://www.racingpost.com/horses/result_home.sd?race_id=536835","http://www.racingpost.com/horses/result_home.sd?race_id=537309","http://www.racingpost.com/horses/result_home.sd?race_id=537873","http://www.racingpost.com/horses/result_home.sd?race_id=538341","http://www.racingpost.com/horses/result_home.sd?race_id=538998","http://www.racingpost.com/horses/result_home.sd?race_id=539693","http://www.racingpost.com/horses/result_home.sd?race_id=550519","http://www.racingpost.com/horses/result_home.sd?race_id=552366","http://www.racingpost.com/horses/result_home.sd?race_id=554407","http://www.racingpost.com/horses/result_home.sd?race_id=555662","http://www.racingpost.com/horses/result_home.sd?race_id=557497","http://www.racingpost.com/horses/result_home.sd?race_id=560473","http://www.racingpost.com/horses/result_home.sd?race_id=561152");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561240" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561240" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Tuscania&id=767592&rnumber=561240" <?php $thisId=767592; include("markHorse.php");?>>Tuscania</a></li>

<ol> 
<li><a href="horse.php?name=Tuscania&id=767592&rnumber=561240&url=/horses/result_home.sd?race_id=560556" id='h2hFormLink'>Burke's Rock </a></li> 
<li><a href="horse.php?name=Tuscania&id=767592&rnumber=561240&url=/horses/result_home.sd?race_id=514132" id='h2hFormLink'>Viking Rose </a></li> 
</ol> 
<li> <a href="horse.php?name=Burke's+Rock&id=796297&rnumber=561240" <?php $thisId=796297; include("markHorse.php");?>>Burke's Rock</a></li>

<ol> 
<li><a href="horse.php?name=Burke's+Rock&id=796297&rnumber=561240&url=/horses/result_home.sd?race_id=553729" id='h2hFormLink'>Strathnaver </a></li> 
<li><a href="horse.php?name=Burke's+Rock&id=796297&rnumber=561240&url=/horses/result_home.sd?race_id=559630" id='h2hFormLink'>Sugarformyhoney </a></li> 
</ol> 
<li> <a href="horse.php?name=Strathnaver&id=794202&rnumber=561240" <?php $thisId=794202; include("markHorse.php");?>>Strathnaver</a></li>

<ol> 
<li><a href="horse.php?name=Strathnaver&id=794202&rnumber=561240&url=/horses/result_home.sd?race_id=560026" id='h2hFormLink'>Amber Silk </a></li> 
</ol> 
<li> <a href="horse.php?name=Amber+Silk&id=790367&rnumber=561240" <?php $thisId=790367; include("markHorse.php");?>>Amber Silk</a></li>

<ol> 
<li><a href="horse.php?name=Amber+Silk&id=790367&rnumber=561240&url=/horses/result_home.sd?race_id=554391" id='h2hFormLink'>Forgive </a></li> 
</ol> 
<li> <a href="horse.php?name=The+Giving+Tree&id=787851&rnumber=561240" <?php $thisId=787851; include("markHorse.php");?>>The Giving Tree</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Silvas+Romana&id=784636&rnumber=561240" <?php $thisId=784636; include("markHorse.php");?>>Silvas Romana</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sugarformyhoney&id=790231&rnumber=561240" <?php $thisId=790231; include("markHorse.php");?>>Sugarformyhoney</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Forgive&id=784770&rnumber=561240" <?php $thisId=784770; include("markHorse.php");?>>Forgive</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Viking+Rose&id=753153&rnumber=561240" <?php $thisId=753153; include("markHorse.php");?>>Viking Rose</a></li>

<ol> 
</ol> 
</ol>