
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks802523 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802523");

var horseLinks818219 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818219");

var horseLinks802526 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802526");

var horseLinks810191 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810191");

var horseLinks818221 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818221");

var horseLinks813793 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813793");

var horseLinks818223 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818223");

var horseLinks805577 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805577","http://www.racingpost.com/horses/result_home.sd?race_id=554979");

var horseLinks817886 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817886");

var horseLinks818225 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818225");

var horseLinks816190 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816190","http://www.racingpost.com/horses/result_home.sd?race_id=559725");

var horseLinks800308 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800308","http://www.racingpost.com/horses/result_home.sd?race_id=559725");

var horseLinks818248 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818248");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560949" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560949" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=A+Ladies+Man&id=802523&rnumber=560949" <?php $thisId=802523; include("markHorse.php");?>>A Ladies Man</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Altharoos&id=818219&rnumber=560949" <?php $thisId=818219; include("markHorse.php");?>>Altharoos</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Another+Cocktail&id=802526&rnumber=560949" <?php $thisId=802526; include("markHorse.php");?>>Another Cocktail</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Code+Of+Honor&id=810191&rnumber=560949" <?php $thisId=810191; include("markHorse.php");?>>Code Of Honor</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Damian+One&id=818221&rnumber=560949" <?php $thisId=818221; include("markHorse.php");?>>Damian One</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Glean&id=813793&rnumber=560949" <?php $thisId=813793; include("markHorse.php");?>>Glean</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Imperial+Glance&id=818223&rnumber=560949" <?php $thisId=818223; include("markHorse.php");?>>Imperial Glance</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Intimidate&id=805577&rnumber=560949" <?php $thisId=805577; include("markHorse.php");?>>Intimidate</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mizyen&id=817886&rnumber=560949" <?php $thisId=817886; include("markHorse.php");?>>Mizyen</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Muthafar&id=818225&rnumber=560949" <?php $thisId=818225; include("markHorse.php");?>>Muthafar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Newtown+Cross&id=816190&rnumber=560949" <?php $thisId=816190; include("markHorse.php");?>>Newtown Cross</a></li>

<ol> 
<li><a href="horse.php?name=Newtown+Cross&id=816190&rnumber=560949&url=/horses/result_home.sd?race_id=559725" id='h2hFormLink'>Rutherglen </a></li> 
</ol> 
<li> <a href="horse.php?name=Rutherglen&id=800308&rnumber=560949" <?php $thisId=800308; include("markHorse.php");?>>Rutherglen</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=So+Beloved&id=818248&rnumber=560949" <?php $thisId=818248; include("markHorse.php");?>>So Beloved</a></li>

<ol> 
</ol> 
</ol>