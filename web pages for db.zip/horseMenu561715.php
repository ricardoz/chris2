
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks817107 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817107","http://www.racingpost.com/horses/result_home.sd?race_id=561132");

var horseLinks817755 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817755","http://www.racingpost.com/horses/result_home.sd?race_id=560525");

var horseLinks815394 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815394");

var horseLinks808529 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=808529","http://www.racingpost.com/horses/result_home.sd?race_id=554301","http://www.racingpost.com/horses/result_home.sd?race_id=555000","http://www.racingpost.com/horses/result_home.sd?race_id=556416");

var horseLinks805661 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805661","http://www.racingpost.com/horses/result_home.sd?race_id=556405","http://www.racingpost.com/horses/result_home.sd?race_id=559522","http://www.racingpost.com/horses/result_home.sd?race_id=559703","http://www.racingpost.com/horses/result_home.sd?race_id=560916");

var horseLinks816109 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816109","http://www.racingpost.com/horses/result_home.sd?race_id=558657","http://www.racingpost.com/horses/result_home.sd?race_id=560067","http://www.racingpost.com/horses/result_home.sd?race_id=560439");

var horseLinks815828 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815828","http://www.racingpost.com/horses/result_home.sd?race_id=560430");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561715" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561715" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Jubilini&id=817107&rnumber=561715" <?php $thisId=817107; include("markHorse.php");?>>Jubilini</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Melbourne+Memories&id=817755&rnumber=561715" <?php $thisId=817755; include("markHorse.php");?>>Melbourne Memories</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Princess+Sheila&id=815394&rnumber=561715" <?php $thisId=815394; include("markHorse.php");?>>Princess Sheila</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Puteri+Nur+Laila&id=808529&rnumber=561715" <?php $thisId=808529; include("markHorse.php");?>>Puteri Nur Laila</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Silverrica&id=805661&rnumber=561715" <?php $thisId=805661; include("markHorse.php");?>>Silverrica</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tregereth&id=816109&rnumber=561715" <?php $thisId=816109; include("markHorse.php");?>>Tregereth</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tristessa&id=815828&rnumber=561715" <?php $thisId=815828; include("markHorse.php");?>>Tristessa</a></li>

<ol> 
</ol> 
</ol>