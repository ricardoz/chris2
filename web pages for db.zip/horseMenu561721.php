
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks802536 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802536","http://www.racingpost.com/horses/result_home.sd?race_id=558264","http://www.racingpost.com/horses/result_home.sd?race_id=559226","http://www.racingpost.com/horses/result_home.sd?race_id=562329");

var horseLinks814231 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814231","http://www.racingpost.com/horses/result_home.sd?race_id=556392","http://www.racingpost.com/horses/result_home.sd?race_id=558734","http://www.racingpost.com/horses/result_home.sd?race_id=560023");

var horseLinks817054 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817054","http://www.racingpost.com/horses/result_home.sd?race_id=559716","http://www.racingpost.com/horses/result_home.sd?race_id=560926");

var horseLinks814317 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814317","http://www.racingpost.com/horses/result_home.sd?race_id=556438","http://www.racingpost.com/horses/result_home.sd?race_id=557436","http://www.racingpost.com/horses/result_home.sd?race_id=559579","http://www.racingpost.com/horses/result_home.sd?race_id=560123","http://www.racingpost.com/horses/result_home.sd?race_id=562593");

var horseLinks813820 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813820","http://www.racingpost.com/horses/result_home.sd?race_id=555782","http://www.racingpost.com/horses/result_home.sd?race_id=559659");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561721" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561721" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Havana+Gold&id=802536&rnumber=561721" <?php $thisId=802536; include("markHorse.php");?>>Havana Gold</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Operation+Chariot&id=814231&rnumber=561721" <?php $thisId=814231; include("markHorse.php");?>>Operation Chariot</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Timoneer&id=817054&rnumber=561721" <?php $thisId=817054; include("markHorse.php");?>>Timoneer</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Califante&id=814317&rnumber=561721" <?php $thisId=814317; include("markHorse.php");?>>Califante</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Go+Angellica&id=813820&rnumber=561721" <?php $thisId=813820; include("markHorse.php");?>>Go Angellica</a></li>

<ol> 
</ol> 
</ol>