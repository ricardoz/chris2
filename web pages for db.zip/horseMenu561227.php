
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks810109 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810109","http://www.racingpost.com/horses/result_home.sd?race_id=560116");

var horseLinks817752 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817752");

var horseLinks817069 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817069","http://www.racingpost.com/horses/result_home.sd?race_id=559716");

var horseLinks815610 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815610","http://www.racingpost.com/horses/result_home.sd?race_id=558705","http://www.racingpost.com/horses/result_home.sd?race_id=560457");

var horseLinks805461 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805461","http://www.racingpost.com/horses/result_home.sd?race_id=559652","http://www.racingpost.com/horses/result_home.sd?race_id=560106");

var horseLinks800145 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800145","http://www.racingpost.com/horses/result_home.sd?race_id=560601");

var horseLinks817748 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817748");

var horseLinks812940 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812940","http://www.racingpost.com/horses/result_home.sd?race_id=554979","http://www.racingpost.com/horses/result_home.sd?race_id=559278");

var horseLinks818331 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818331");

var horseLinks818332 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818332");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561227" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561227" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Arctic+Admiral&id=810109&rnumber=561227" <?php $thisId=810109; include("markHorse.php");?>>Arctic Admiral</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cap+O'Rushes&id=817752&rnumber=561227" <?php $thisId=817752; include("markHorse.php");?>>Cap O'Rushes</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dark+Templar&id=817069&rnumber=561227" <?php $thisId=817069; include("markHorse.php");?>>Dark Templar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Grilletto&id=815610&rnumber=561227" <?php $thisId=815610; include("markHorse.php");?>>Grilletto</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Knight's+Parade&id=805461&rnumber=561227" <?php $thisId=805461; include("markHorse.php");?>>Knight's Parade</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Man+From+Seville&id=800145&rnumber=561227" <?php $thisId=800145; include("markHorse.php");?>>Man From Seville</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Raven's+Tower&id=817748&rnumber=561227" <?php $thisId=817748; include("markHorse.php");?>>Raven's Tower</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Shooting+Jacket&id=812940&rnumber=561227" <?php $thisId=812940; include("markHorse.php");?>>Shooting Jacket</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Bountiful+Bess&id=818331&rnumber=561227" <?php $thisId=818331; include("markHorse.php");?>>Bountiful Bess</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Positive+Parenting&id=818332&rnumber=561227" <?php $thisId=818332; include("markHorse.php");?>>Positive Parenting</a></li>

<ol> 
</ol> 
</ol>