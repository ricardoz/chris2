
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks786658 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=786658","http://www.racingpost.com/horses/result_home.sd?race_id=533817","http://www.racingpost.com/horses/result_home.sd?race_id=537867","http://www.racingpost.com/horses/result_home.sd?race_id=541495","http://www.racingpost.com/horses/result_home.sd?race_id=542955","http://www.racingpost.com/horses/result_home.sd?race_id=546678","http://www.racingpost.com/horses/result_home.sd?race_id=548305","http://www.racingpost.com/horses/result_home.sd?race_id=550211","http://www.racingpost.com/horses/result_home.sd?race_id=556621");

var horseLinks716550 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=716550","http://www.racingpost.com/horses/result_home.sd?race_id=466699","http://www.racingpost.com/horses/result_home.sd?race_id=468548","http://www.racingpost.com/horses/result_home.sd?race_id=483496","http://www.racingpost.com/horses/result_home.sd?race_id=506550","http://www.racingpost.com/horses/result_home.sd?race_id=508307","http://www.racingpost.com/horses/result_home.sd?race_id=508313","http://www.racingpost.com/horses/result_home.sd?race_id=514688","http://www.racingpost.com/horses/result_home.sd?race_id=517150","http://www.racingpost.com/horses/result_home.sd?race_id=542890","http://www.racingpost.com/horses/result_home.sd?race_id=561978");

var horseLinks763644 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=763644","http://www.racingpost.com/horses/result_home.sd?race_id=512197","http://www.racingpost.com/horses/result_home.sd?race_id=513648","http://www.racingpost.com/horses/result_home.sd?race_id=515790","http://www.racingpost.com/horses/result_home.sd?race_id=515805","http://www.racingpost.com/horses/result_home.sd?race_id=517184","http://www.racingpost.com/horses/result_home.sd?race_id=529242","http://www.racingpost.com/horses/result_home.sd?race_id=532073","http://www.racingpost.com/horses/result_home.sd?race_id=533766","http://www.racingpost.com/horses/result_home.sd?race_id=535479","http://www.racingpost.com/horses/result_home.sd?race_id=537043","http://www.racingpost.com/horses/result_home.sd?race_id=539162","http://www.racingpost.com/horses/result_home.sd?race_id=540406","http://www.racingpost.com/horses/result_home.sd?race_id=544074","http://www.racingpost.com/horses/result_home.sd?race_id=556287","http://www.racingpost.com/horses/result_home.sd?race_id=556528","http://www.racingpost.com/horses/result_home.sd?race_id=559395");

var horseLinks760292 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=760292","http://www.racingpost.com/horses/result_home.sd?race_id=509337","http://www.racingpost.com/horses/result_home.sd?race_id=511423","http://www.racingpost.com/horses/result_home.sd?race_id=513628","http://www.racingpost.com/horses/result_home.sd?race_id=516321","http://www.racingpost.com/horses/result_home.sd?race_id=518745","http://www.racingpost.com/horses/result_home.sd?race_id=530756","http://www.racingpost.com/horses/result_home.sd?race_id=532729","http://www.racingpost.com/horses/result_home.sd?race_id=535212","http://www.racingpost.com/horses/result_home.sd?race_id=537860","http://www.racingpost.com/horses/result_home.sd?race_id=540282","http://www.racingpost.com/horses/result_home.sd?race_id=542939","http://www.racingpost.com/horses/result_home.sd?race_id=556528","http://www.racingpost.com/horses/result_home.sd?race_id=559920","http://www.racingpost.com/horses/result_home.sd?race_id=561130");

var horseLinks769749 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=769749","http://www.racingpost.com/horses/result_home.sd?race_id=517184","http://www.racingpost.com/horses/result_home.sd?race_id=535124","http://www.racingpost.com/horses/result_home.sd?race_id=536755","http://www.racingpost.com/horses/result_home.sd?race_id=538237","http://www.racingpost.com/horses/result_home.sd?race_id=540282","http://www.racingpost.com/horses/result_home.sd?race_id=541160","http://www.racingpost.com/horses/result_home.sd?race_id=556502","http://www.racingpost.com/horses/result_home.sd?race_id=559889","http://www.racingpost.com/horses/result_home.sd?race_id=562273");

var horseLinks809595 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809595","http://www.racingpost.com/horses/result_home.sd?race_id=553956","http://www.racingpost.com/horses/result_home.sd?race_id=556579","http://www.racingpost.com/horses/result_home.sd?race_id=558313","http://www.racingpost.com/horses/result_home.sd?race_id=559865","http://www.racingpost.com/horses/result_home.sd?race_id=560016","http://www.racingpost.com/horses/result_home.sd?race_id=561521");

var horseLinks793350 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=793350","http://www.racingpost.com/horses/result_home.sd?race_id=541548","http://www.racingpost.com/horses/result_home.sd?race_id=555287","http://www.racingpost.com/horses/result_home.sd?race_id=558313","http://www.racingpost.com/horses/result_home.sd?race_id=559865");

var horseLinks794491 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=794491","http://www.racingpost.com/horses/result_home.sd?race_id=540342","http://www.racingpost.com/horses/result_home.sd?race_id=542913","http://www.racingpost.com/horses/result_home.sd?race_id=553956","http://www.racingpost.com/horses/result_home.sd?race_id=557147","http://www.racingpost.com/horses/result_home.sd?race_id=559865","http://www.racingpost.com/horses/result_home.sd?race_id=561474","http://www.racingpost.com/horses/result_home.sd?race_id=563117","http://www.racingpost.com/horses/result_home.sd?race_id=563118");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=563398" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=563398" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Energia+Davos&id=786658&rnumber=563398" <?php $thisId=786658; include("markHorse.php");?>>Energia Davos</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Next+Vision&id=716550&rnumber=563398" <?php $thisId=716550; include("markHorse.php");?>>Next Vision</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Danedream&id=763644&rnumber=563398" <?php $thisId=763644; include("markHorse.php");?>>Danedream</a></li>

<ol> 
<li><a href="horse.php?name=Danedream&id=763644&rnumber=563398&url=/horses/result_home.sd?race_id=556528" id='h2hFormLink'>Ovambo Queen </a></li> 
<li><a href="horse.php?name=Danedream&id=763644&rnumber=563398&url=/horses/result_home.sd?race_id=517184" id='h2hFormLink'>Temida </a></li> 
</ol> 
<li> <a href="horse.php?name=Ovambo+Queen&id=760292&rnumber=563398" <?php $thisId=760292; include("markHorse.php");?>>Ovambo Queen</a></li>

<ol> 
<li><a href="horse.php?name=Ovambo+Queen&id=760292&rnumber=563398&url=/horses/result_home.sd?race_id=540282" id='h2hFormLink'>Temida </a></li> 
</ol> 
<li> <a href="horse.php?name=Temida&id=769749&rnumber=563398" <?php $thisId=769749; include("markHorse.php");?>>Temida</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Girolamo&id=809595&rnumber=563398" <?php $thisId=809595; include("markHorse.php");?>>Girolamo</a></li>

<ol> 
<li><a href="horse.php?name=Girolamo&id=809595&rnumber=563398&url=/horses/result_home.sd?race_id=558313" id='h2hFormLink'>Novellist </a></li> 
<li><a href="horse.php?name=Girolamo&id=809595&rnumber=563398&url=/horses/result_home.sd?race_id=559865" id='h2hFormLink'>Novellist </a></li> 
<li><a href="horse.php?name=Girolamo&id=809595&rnumber=563398&url=/horses/result_home.sd?race_id=553956" id='h2hFormLink'>Pastorius </a></li> 
<li><a href="horse.php?name=Girolamo&id=809595&rnumber=563398&url=/horses/result_home.sd?race_id=559865" id='h2hFormLink'>Pastorius </a></li> 
</ol> 
<li> <a href="horse.php?name=Novellist&id=793350&rnumber=563398" <?php $thisId=793350; include("markHorse.php");?>>Novellist</a></li>

<ol> 
<li><a href="horse.php?name=Novellist&id=793350&rnumber=563398&url=/horses/result_home.sd?race_id=559865" id='h2hFormLink'>Pastorius </a></li> 
</ol> 
<li> <a href="horse.php?name=Pastorius&id=794491&rnumber=563398" <?php $thisId=794491; include("markHorse.php");?>>Pastorius</a></li>

<ol> 
</ol> 
</ol>