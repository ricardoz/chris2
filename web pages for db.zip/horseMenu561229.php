
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks789855 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=789855","http://www.racingpost.com/horses/result_home.sd?race_id=535234","http://www.racingpost.com/horses/result_home.sd?race_id=535637","http://www.racingpost.com/horses/result_home.sd?race_id=537252","http://www.racingpost.com/horses/result_home.sd?race_id=538007","http://www.racingpost.com/horses/result_home.sd?race_id=539409","http://www.racingpost.com/horses/result_home.sd?race_id=540120","http://www.racingpost.com/horses/result_home.sd?race_id=549988","http://www.racingpost.com/horses/result_home.sd?race_id=552433","http://www.racingpost.com/horses/result_home.sd?race_id=556883","http://www.racingpost.com/horses/result_home.sd?race_id=558703","http://www.racingpost.com/horses/result_home.sd?race_id=560122");

var horseLinks787859 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=787859","http://www.racingpost.com/horses/result_home.sd?race_id=533528","http://www.racingpost.com/horses/result_home.sd?race_id=536059","http://www.racingpost.com/horses/result_home.sd?race_id=540120","http://www.racingpost.com/horses/result_home.sd?race_id=549988","http://www.racingpost.com/horses/result_home.sd?race_id=553775","http://www.racingpost.com/horses/result_home.sd?race_id=556883","http://www.racingpost.com/horses/result_home.sd?race_id=558192","http://www.racingpost.com/horses/result_home.sd?race_id=560026");

var horseLinks778966 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778966","http://www.racingpost.com/horses/result_home.sd?race_id=531245","http://www.racingpost.com/horses/result_home.sd?race_id=533091","http://www.racingpost.com/horses/result_home.sd?race_id=535344","http://www.racingpost.com/horses/result_home.sd?race_id=536001","http://www.racingpost.com/horses/result_home.sd?race_id=536944","http://www.racingpost.com/horses/result_home.sd?race_id=538757","http://www.racingpost.com/horses/result_home.sd?race_id=540120","http://www.racingpost.com/horses/result_home.sd?race_id=551174","http://www.racingpost.com/horses/result_home.sd?race_id=559718");

var horseLinks789733 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=789733","http://www.racingpost.com/horses/result_home.sd?race_id=535234","http://www.racingpost.com/horses/result_home.sd?race_id=537698","http://www.racingpost.com/horses/result_home.sd?race_id=539416","http://www.racingpost.com/horses/result_home.sd?race_id=560035");

var horseLinks792647 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792647","http://www.racingpost.com/horses/result_home.sd?race_id=539349","http://www.racingpost.com/horses/result_home.sd?race_id=540509","http://www.racingpost.com/horses/result_home.sd?race_id=549977","http://www.racingpost.com/horses/result_home.sd?race_id=552326","http://www.racingpost.com/horses/result_home.sd?race_id=554343","http://www.racingpost.com/horses/result_home.sd?race_id=556334","http://www.racingpost.com/horses/result_home.sd?race_id=558057","http://www.racingpost.com/horses/result_home.sd?race_id=561134");

var horseLinks775155 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=775155","http://www.racingpost.com/horses/result_home.sd?race_id=529828","http://www.racingpost.com/horses/result_home.sd?race_id=557513","http://www.racingpost.com/horses/result_home.sd?race_id=558645","http://www.racingpost.com/horses/result_home.sd?race_id=560117");

var horseLinks783348 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783348","http://www.racingpost.com/horses/result_home.sd?race_id=539738","http://www.racingpost.com/horses/result_home.sd?race_id=541298","http://www.racingpost.com/horses/result_home.sd?race_id=551151","http://www.racingpost.com/horses/result_home.sd?race_id=554291","http://www.racingpost.com/horses/result_home.sd?race_id=556353","http://www.racingpost.com/horses/result_home.sd?race_id=557557");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561229" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561229" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Semayyel&id=789855&rnumber=561229" <?php $thisId=789855; include("markHorse.php");?>>Semayyel</a></li>

<ol> 
<li><a href="horse.php?name=Semayyel&id=789855&rnumber=561229&url=/horses/result_home.sd?race_id=540120" id='h2hFormLink'>Way Too Hot </a></li> 
<li><a href="horse.php?name=Semayyel&id=789855&rnumber=561229&url=/horses/result_home.sd?race_id=549988" id='h2hFormLink'>Way Too Hot </a></li> 
<li><a href="horse.php?name=Semayyel&id=789855&rnumber=561229&url=/horses/result_home.sd?race_id=556883" id='h2hFormLink'>Way Too Hot </a></li> 
<li><a href="horse.php?name=Semayyel&id=789855&rnumber=561229&url=/horses/result_home.sd?race_id=540120" id='h2hFormLink'>Self Centred </a></li> 
<li><a href="horse.php?name=Semayyel&id=789855&rnumber=561229&url=/horses/result_home.sd?race_id=535234" id='h2hFormLink'>Diamond Belle </a></li> 
</ol> 
<li> <a href="horse.php?name=Way+Too+Hot&id=787859&rnumber=561229" <?php $thisId=787859; include("markHorse.php");?>>Way Too Hot</a></li>

<ol> 
<li><a href="horse.php?name=Way+Too+Hot&id=787859&rnumber=561229&url=/horses/result_home.sd?race_id=540120" id='h2hFormLink'>Self Centred </a></li> 
</ol> 
<li> <a href="horse.php?name=Self+Centred&id=778966&rnumber=561229" <?php $thisId=778966; include("markHorse.php");?>>Self Centred</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Diamond+Belle&id=789733&rnumber=561229" <?php $thisId=789733; include("markHorse.php");?>>Diamond Belle</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Subtle+Knife&id=792647&rnumber=561229" <?php $thisId=792647; include("markHorse.php");?>>Subtle Knife</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Macchiara&id=775155&rnumber=561229" <?php $thisId=775155; include("markHorse.php");?>>Macchiara</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=More+Than+Words&id=783348&rnumber=561229" <?php $thisId=783348; include("markHorse.php");?>>More Than Words</a></li>

<ol> 
</ol> 
</ol>