
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks805300 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805300","http://www.racingpost.com/horses/result_home.sd?race_id=553752","http://www.racingpost.com/horses/result_home.sd?race_id=555029","http://www.racingpost.com/horses/result_home.sd?race_id=556950","http://www.racingpost.com/horses/result_home.sd?race_id=559335","http://www.racingpost.com/horses/result_home.sd?race_id=560834");

var horseLinks815014 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815014","http://www.racingpost.com/horses/result_home.sd?race_id=559522");

var horseLinks810048 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810048","http://www.racingpost.com/horses/result_home.sd?race_id=560087");

var horseLinks820018 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=820018");

var horseLinks818674 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818674","http://www.racingpost.com/horses/result_home.sd?race_id=562114");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562489" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562489" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Bix&id=805300&rnumber=562489" <?php $thisId=805300; include("markHorse.php");?>>Bix</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Crafty+Wonder&id=815014&rnumber=562489" <?php $thisId=815014; include("markHorse.php");?>>Crafty Wonder</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Daaree&id=810048&rnumber=562489" <?php $thisId=810048; include("markHorse.php");?>>Daaree</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Gabrial+The+Master&id=820018&rnumber=562489" <?php $thisId=820018; include("markHorse.php");?>>Gabrial The Master</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Scepticism&id=818674&rnumber=562489" <?php $thisId=818674; include("markHorse.php");?>>Scepticism</a></li>

<ol> 
</ol> 
</ol>