<html><head>
<?php

/*start the session*/

session_start();

/*redirect if not logged in*/

if (!isset($_COOKIE['userId']))

{

$_SESSION['startURL']="Cabimas";

echo "<META HTTP-EQUIV='Refresh' Content='0; URL=homepage.php'/> "; 

} else if (isset($_COOKIE['username'])){ 

$_SESSION['username'] = $_COOKIE['username'];

}

?>
<title>Cabimas</title><link rel="stylesheet" type="text/css" href="layout.php" >
<?php include("handleResponse.library.php");?>

<script type='text/javascript'>

function handleResponse(){

alert('this function is called from server.html');

}

var counter = 0;

 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=746342","http://www.racingpost.com/horses/result_home.sd?race_id=494607","http://www.racingpost.com/horses/result_home.sd?race_id=507817","http://www.racingpost.com/horses/result_home.sd?race_id=517265","http://www.racingpost.com/horses/result_home.sd?race_id=517378","http://www.racingpost.com/horses/result_home.sd?race_id=518740","http://www.racingpost.com/horses/result_home.sd?race_id=518823","http://www.racingpost.com/horses/result_home.sd?race_id=531485","http://www.racingpost.com/horses/result_home.sd?race_id=533753","http://www.racingpost.com/horses/result_home.sd?race_id=554065","http://www.racingpost.com/horses/result_home.sd?race_id=556978","http://www.racingpost.com/horses/result_home.sd?race_id=558336","http://www.racingpost.com/horses/result_home.sd?race_id=558354","http://www.racingpost.com/horses/result_home.sd?race_id=558355","http://www.racingpost.com/horses/result_home.sd?race_id=558357","http://www.racingpost.com/horses/result_home.sd?race_id=558759");

<?php include ("updateIframe.php");?>

</script>
</head><body>
<?php

/*get functions*/

include ("database.library.php");

/*set variables*/

$horse = "Cabimas";

$userID = $_COOKIE['userId'];

/*$userID = 5;*/

$database = "a1270291_racing";

$note ='';



$getHorseIDQuery=

" SELECT id

FROM runners

WHERE name = '" .$horse. "';";



$horseID = getHorseID($horse, $getHorseIDQuery);



$insertHorseQuery =

"INSERT INTO runners

VALUES (null, '" .$horse. "')";



$getHorseNotes =

"SELECT notes

FROM notes

WHERE Horse_ID='" .$horseID . "'AND User_ID = '" .$userID ."';";



$insertNoteQuery =

"INSERT INTO notes

VALUES ('" .$horseID . "','".$userID . "','".$note ."')";

$updateNoteQuery =

"UPDATE notes SET notes = '" .$note. "' WHERE Horse_ID='" .$horseID.

"'AND User_ID = '" .$userID . "';";





$connection = getConnection()

or die ('Could not connect: '.MYSQL_ERROR());



MYSQL_SELECT_DB($database,$connection)

or die('Could not connect: '.mysql_error());



mysql_select_db($database,$connection)

or die('Error in selecting the database:'.mysql_error());

?>

<div id = 'raceMenuDiv'>

<?php

include("horseMenu561022.php");

?>
</div>
<div id='raceMainDiv'>

<form method='get' action='hiddenFrame.php'target='hiddenFrame' id='saveHorseNoteForm'>
<textarea name='horseNote' id='horseNote' cols='70' rows='25'><?php
if (queryIsNull($getHorseNotes)){
} else {
$result = getResult($getHorseNotes);
$row=mysql_fetch_array($result);
echo $row[0];
}?></textarea>
<input type='hidden' name='horse' value='Cabimas'>

<br>

<input id = 'saveNote' type='submit' name='saveNote' value='Save'>

</form>

<?php

include("horseCarouselTable.php");

if (isset($_GET['url']))

{

$url = $_GET['url'];

} else {

$url ='http://www.racingpost.com/horses/horse_home.sd?horse_id=746342';

}

echo

"

<iframe name=horseFrame src =$url height = 100% width = 100% frameborder = 1 scrolling = yes>

</iframe>

";?>

</div>
</body> 
</html> 
