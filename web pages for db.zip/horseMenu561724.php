
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks810167 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810167","http://www.racingpost.com/horses/result_home.sd?race_id=553155","http://www.racingpost.com/horses/result_home.sd?race_id=557045","http://www.racingpost.com/horses/result_home.sd?race_id=558111","http://www.racingpost.com/horses/result_home.sd?race_id=559269","http://www.racingpost.com/horses/result_home.sd?race_id=560591");

var horseLinks807829 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807829","http://www.racingpost.com/horses/result_home.sd?race_id=550591","http://www.racingpost.com/horses/result_home.sd?race_id=551188","http://www.racingpost.com/horses/result_home.sd?race_id=552469","http://www.racingpost.com/horses/result_home.sd?race_id=553773","http://www.racingpost.com/horses/result_home.sd?race_id=555056","http://www.racingpost.com/horses/result_home.sd?race_id=556934","http://www.racingpost.com/horses/result_home.sd?race_id=560123","http://www.racingpost.com/horses/result_home.sd?race_id=560850","http://www.racingpost.com/horses/result_home.sd?race_id=561418");

var horseLinks440748 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=440748","http://www.racingpost.com/horses/result_home.sd?race_id=559725","http://www.racingpost.com/horses/result_home.sd?race_id=560916");

var horseLinks812338 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812338","http://www.racingpost.com/horses/result_home.sd?race_id=554307");

var horseLinks807717 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807717","http://www.racingpost.com/horses/result_home.sd?race_id=551644","http://www.racingpost.com/horses/result_home.sd?race_id=553182","http://www.racingpost.com/horses/result_home.sd?race_id=553755","http://www.racingpost.com/horses/result_home.sd?race_id=556371","http://www.racingpost.com/horses/result_home.sd?race_id=557583","http://www.racingpost.com/horses/result_home.sd?race_id=559262","http://www.racingpost.com/horses/result_home.sd?race_id=560123");

var horseLinks805506 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805506","http://www.racingpost.com/horses/result_home.sd?race_id=555674","http://www.racingpost.com/horses/result_home.sd?race_id=556844","http://www.racingpost.com/horses/result_home.sd?race_id=558040","http://www.racingpost.com/horses/result_home.sd?race_id=559225","http://www.racingpost.com/horses/result_home.sd?race_id=560047","http://www.racingpost.com/horses/result_home.sd?race_id=560467","http://www.racingpost.com/horses/result_home.sd?race_id=560976");

var horseLinks811795 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=811795","http://www.racingpost.com/horses/result_home.sd?race_id=554301","http://www.racingpost.com/horses/result_home.sd?race_id=555123","http://www.racingpost.com/horses/result_home.sd?race_id=558657","http://www.racingpost.com/horses/result_home.sd?race_id=559634","http://www.racingpost.com/horses/result_home.sd?race_id=561573");

var horseLinks805580 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805580","http://www.racingpost.com/horses/result_home.sd?race_id=552464","http://www.racingpost.com/horses/result_home.sd?race_id=553728","http://www.racingpost.com/horses/result_home.sd?race_id=555703","http://www.racingpost.com/horses/result_home.sd?race_id=559262","http://www.racingpost.com/horses/result_home.sd?race_id=560416");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561724" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561724" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Equitania&id=810167&rnumber=561724" <?php $thisId=810167; include("markHorse.php");?>>Equitania</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Effie+B&id=807829&rnumber=561724" <?php $thisId=807829; include("markHorse.php");?>>Effie B</a></li>

<ol> 
<li><a href="horse.php?name=Effie+B&id=807829&rnumber=561724&url=/horses/result_home.sd?race_id=560123" id='h2hFormLink'>Ishi Honest </a></li> 
</ol> 
<li> <a href="horse.php?name=Vectis&id=440748&rnumber=561724" <?php $thisId=440748; include("markHorse.php");?>>Vectis</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Time+For+Lambrini&id=812338&rnumber=561724" <?php $thisId=812338; include("markHorse.php");?>>Time For Lambrini</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ishi+Honest&id=807717&rnumber=561724" <?php $thisId=807717; include("markHorse.php");?>>Ishi Honest</a></li>

<ol> 
<li><a href="horse.php?name=Ishi+Honest&id=807717&rnumber=561724&url=/horses/result_home.sd?race_id=559262" id='h2hFormLink'>Bentleysoysterboy </a></li> 
</ol> 
<li> <a href="horse.php?name=Hot+Secret&id=805506&rnumber=561724" <?php $thisId=805506; include("markHorse.php");?>>Hot Secret</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Snow+Angel&id=811795&rnumber=561724" <?php $thisId=811795; include("markHorse.php");?>>Snow Angel</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Bentleysoysterboy&id=805580&rnumber=561724" <?php $thisId=805580; include("markHorse.php");?>>Bentleysoysterboy</a></li>

<ol> 
</ol> 
</ol>