
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks812880 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812880","http://www.racingpost.com/horses/result_home.sd?race_id=556638","http://www.racingpost.com/horses/result_home.sd?race_id=557626","http://www.racingpost.com/horses/result_home.sd?race_id=558964");

var horseLinks817860 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817860");

var horseLinks819083 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=819083");

var horseLinks816284 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816284");

var horseLinks800285 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800285");

var horseLinks814081 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814081","http://www.racingpost.com/horses/result_home.sd?race_id=558278","http://www.racingpost.com/horses/result_home.sd?race_id=561174");

var horseLinks818326 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818326","http://www.racingpost.com/horses/result_home.sd?race_id=562396");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=563131" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=563131" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Nandiga&id=812880&rnumber=563131" <?php $thisId=812880; include("markHorse.php");?>>Nandiga</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Agreement&id=817860&rnumber=563131" <?php $thisId=817860; include("markHorse.php");?>>Agreement</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dabadiyan&id=819083&rnumber=563131" <?php $thisId=819083; include("markHorse.php");?>>Dabadiyan</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lucky+Kitten&id=816284&rnumber=563131" <?php $thisId=816284; include("markHorse.php");?>>Lucky Kitten</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sir+Walter+Scott&id=800285&rnumber=563131" <?php $thisId=800285; include("markHorse.php");?>>Sir Walter Scott</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Washboard+Sam&id=814081&rnumber=563131" <?php $thisId=814081; include("markHorse.php");?>>Washboard Sam</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Seeking+Luck&id=818326&rnumber=563131" <?php $thisId=818326; include("markHorse.php");?>>Seeking Luck</a></li>

<ol> 
</ol> 
</ol>