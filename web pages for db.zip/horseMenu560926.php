
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks816689 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816689","http://www.racingpost.com/horses/result_home.sd?race_id=559278");

var horseLinks800110 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800110","http://www.racingpost.com/horses/result_home.sd?race_id=555794","http://www.racingpost.com/horses/result_home.sd?race_id=556866","http://www.racingpost.com/horses/result_home.sd?race_id=557461");

var horseLinks805208 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805208","http://www.racingpost.com/horses/result_home.sd?race_id=553303","http://www.racingpost.com/horses/result_home.sd?race_id=555089","http://www.racingpost.com/horses/result_home.sd?race_id=556344","http://www.racingpost.com/horses/result_home.sd?race_id=557570","http://www.racingpost.com/horses/result_home.sd?race_id=558734","http://www.racingpost.com/horses/result_home.sd?race_id=560023");

var horseLinks817054 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817054","http://www.racingpost.com/horses/result_home.sd?race_id=559716");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560926" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560926" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Al+Waab&id=816689&rnumber=560926" <?php $thisId=816689; include("markHorse.php");?>>Al Waab</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ask+Dad&id=800110&rnumber=560926" <?php $thisId=800110; include("markHorse.php");?>>Ask Dad</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Luhaif&id=805208&rnumber=560926" <?php $thisId=805208; include("markHorse.php");?>>Luhaif</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Timoneer&id=817054&rnumber=560926" <?php $thisId=817054; include("markHorse.php");?>>Timoneer</a></li>

<ol> 
</ol> 
</ol>