
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks743821 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=743821","http://www.racingpost.com/horses/result_home.sd?race_id=490908","http://www.racingpost.com/horses/result_home.sd?race_id=491634","http://www.racingpost.com/horses/result_home.sd?race_id=502261","http://www.racingpost.com/horses/result_home.sd?race_id=504916","http://www.racingpost.com/horses/result_home.sd?race_id=505611","http://www.racingpost.com/horses/result_home.sd?race_id=506958","http://www.racingpost.com/horses/result_home.sd?race_id=507577","http://www.racingpost.com/horses/result_home.sd?race_id=510391","http://www.racingpost.com/horses/result_home.sd?race_id=531831","http://www.racingpost.com/horses/result_home.sd?race_id=532575","http://www.racingpost.com/horses/result_home.sd?race_id=533115","http://www.racingpost.com/horses/result_home.sd?race_id=534550","http://www.racingpost.com/horses/result_home.sd?race_id=535375","http://www.racingpost.com/horses/result_home.sd?race_id=538772","http://www.racingpost.com/horses/result_home.sd?race_id=540094","http://www.racingpost.com/horses/result_home.sd?race_id=540933","http://www.racingpost.com/horses/result_home.sd?race_id=553195","http://www.racingpost.com/horses/result_home.sd?race_id=554357","http://www.racingpost.com/horses/result_home.sd?race_id=554991","http://www.racingpost.com/horses/result_home.sd?race_id=557420","http://www.racingpost.com/horses/result_home.sd?race_id=558735");

var horseLinks757009 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=757009","http://www.racingpost.com/horses/result_home.sd?race_id=515206","http://www.racingpost.com/horses/result_home.sd?race_id=530371","http://www.racingpost.com/horses/result_home.sd?race_id=531246","http://www.racingpost.com/horses/result_home.sd?race_id=534532","http://www.racingpost.com/horses/result_home.sd?race_id=535375","http://www.racingpost.com/horses/result_home.sd?race_id=553723","http://www.racingpost.com/horses/result_home.sd?race_id=559718","http://www.racingpost.com/horses/result_home.sd?race_id=561305");

var horseLinks791398 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791398","http://www.racingpost.com/horses/result_home.sd?race_id=536572","http://www.racingpost.com/horses/result_home.sd?race_id=537270","http://www.racingpost.com/horses/result_home.sd?race_id=538054","http://www.racingpost.com/horses/result_home.sd?race_id=538990","http://www.racingpost.com/horses/result_home.sd?race_id=540515","http://www.racingpost.com/horses/result_home.sd?race_id=541563","http://www.racingpost.com/horses/result_home.sd?race_id=542741","http://www.racingpost.com/horses/result_home.sd?race_id=543165","http://www.racingpost.com/horses/result_home.sd?race_id=546304","http://www.racingpost.com/horses/result_home.sd?race_id=547392","http://www.racingpost.com/horses/result_home.sd?race_id=548110","http://www.racingpost.com/horses/result_home.sd?race_id=550982","http://www.racingpost.com/horses/result_home.sd?race_id=555581");

var horseLinks790497 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790497","http://www.racingpost.com/horses/result_home.sd?race_id=536609","http://www.racingpost.com/horses/result_home.sd?race_id=537555","http://www.racingpost.com/horses/result_home.sd?race_id=538312","http://www.racingpost.com/horses/result_home.sd?race_id=538798","http://www.racingpost.com/horses/result_home.sd?race_id=541909","http://www.racingpost.com/horses/result_home.sd?race_id=550577","http://www.racingpost.com/horses/result_home.sd?race_id=552439","http://www.racingpost.com/horses/result_home.sd?race_id=553741","http://www.racingpost.com/horses/result_home.sd?race_id=560595");

var horseLinks759284 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=759284","http://www.racingpost.com/horses/result_home.sd?race_id=505635","http://www.racingpost.com/horses/result_home.sd?race_id=509633","http://www.racingpost.com/horses/result_home.sd?race_id=510532","http://www.racingpost.com/horses/result_home.sd?race_id=511645","http://www.racingpost.com/horses/result_home.sd?race_id=513136","http://www.racingpost.com/horses/result_home.sd?race_id=516490","http://www.racingpost.com/horses/result_home.sd?race_id=516865","http://www.racingpost.com/horses/result_home.sd?race_id=516977","http://www.racingpost.com/horses/result_home.sd?race_id=530467","http://www.racingpost.com/horses/result_home.sd?race_id=532508","http://www.racingpost.com/horses/result_home.sd?race_id=533068","http://www.racingpost.com/horses/result_home.sd?race_id=534550","http://www.racingpost.com/horses/result_home.sd?race_id=535660","http://www.racingpost.com/horses/result_home.sd?race_id=537679","http://www.racingpost.com/horses/result_home.sd?race_id=538068","http://www.racingpost.com/horses/result_home.sd?race_id=538794","http://www.racingpost.com/horses/result_home.sd?race_id=539763","http://www.racingpost.com/horses/result_home.sd?race_id=540122","http://www.racingpost.com/horses/result_home.sd?race_id=540933","http://www.racingpost.com/horses/result_home.sd?race_id=555068","http://www.racingpost.com/horses/result_home.sd?race_id=556907","http://www.racingpost.com/horses/result_home.sd?race_id=562129");

var horseLinks785464 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=785464","http://www.racingpost.com/horses/result_home.sd?race_id=531245","http://www.racingpost.com/horses/result_home.sd?race_id=535357","http://www.racingpost.com/horses/result_home.sd?race_id=537273","http://www.racingpost.com/horses/result_home.sd?race_id=538007","http://www.racingpost.com/horses/result_home.sd?race_id=539396","http://www.racingpost.com/horses/result_home.sd?race_id=551142","http://www.racingpost.com/horses/result_home.sd?race_id=560078","http://www.racingpost.com/horses/result_home.sd?race_id=561374");

var horseLinks792221 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792221","http://www.racingpost.com/horses/result_home.sd?race_id=537308","http://www.racingpost.com/horses/result_home.sd?race_id=538745","http://www.racingpost.com/horses/result_home.sd?race_id=539396","http://www.racingpost.com/horses/result_home.sd?race_id=546056","http://www.racingpost.com/horses/result_home.sd?race_id=547536","http://www.racingpost.com/horses/result_home.sd?race_id=548923","http://www.racingpost.com/horses/result_home.sd?race_id=554577");

var horseLinks791511 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=791511","http://www.racingpost.com/horses/result_home.sd?race_id=543532","http://www.racingpost.com/horses/result_home.sd?race_id=544646","http://www.racingpost.com/horses/result_home.sd?race_id=549988","http://www.racingpost.com/horses/result_home.sd?race_id=556366","http://www.racingpost.com/horses/result_home.sd?race_id=557490","http://www.racingpost.com/horses/result_home.sd?race_id=560078");

var horseLinks782492 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=782492","http://www.racingpost.com/horses/result_home.sd?race_id=529422","http://www.racingpost.com/horses/result_home.sd?race_id=532760","http://www.racingpost.com/horses/result_home.sd?race_id=534203","http://www.racingpost.com/horses/result_home.sd?race_id=535869","http://www.racingpost.com/horses/result_home.sd?race_id=537394","http://www.racingpost.com/horses/result_home.sd?race_id=537788","http://www.racingpost.com/horses/result_home.sd?race_id=542096","http://www.racingpost.com/horses/result_home.sd?race_id=542696","http://www.racingpost.com/horses/result_home.sd?race_id=550987","http://www.racingpost.com/horses/result_home.sd?race_id=553557","http://www.racingpost.com/horses/result_home.sd?race_id=555207","http://www.racingpost.com/horses/result_home.sd?race_id=559873");

var horseLinks786152 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=786152","http://www.racingpost.com/horses/result_home.sd?race_id=531245","http://www.racingpost.com/horses/result_home.sd?race_id=533611","http://www.racingpost.com/horses/result_home.sd?race_id=534534","http://www.racingpost.com/horses/result_home.sd?race_id=534876","http://www.racingpost.com/horses/result_home.sd?race_id=546056","http://www.racingpost.com/horses/result_home.sd?race_id=547536","http://www.racingpost.com/horses/result_home.sd?race_id=560078");

var horseLinks790071 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790071","http://www.racingpost.com/horses/result_home.sd?race_id=535323","http://www.racingpost.com/horses/result_home.sd?race_id=536197","http://www.racingpost.com/horses/result_home.sd?race_id=551174","http://www.racingpost.com/horses/result_home.sd?race_id=553789","http://www.racingpost.com/horses/result_home.sd?race_id=555768","http://www.racingpost.com/horses/result_home.sd?race_id=556285","http://www.racingpost.com/horses/result_home.sd?race_id=556901","http://www.racingpost.com/horses/result_home.sd?race_id=558036","http://www.racingpost.com/horses/result_home.sd?race_id=559718","http://www.racingpost.com/horses/result_home.sd?race_id=560927");

var horseLinks786495 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=786495","http://www.racingpost.com/horses/result_home.sd?race_id=531849","http://www.racingpost.com/horses/result_home.sd?race_id=533053","http://www.racingpost.com/horses/result_home.sd?race_id=534534","http://www.racingpost.com/horses/result_home.sd?race_id=534876","http://www.racingpost.com/horses/result_home.sd?race_id=537643","http://www.racingpost.com/horses/result_home.sd?race_id=553757","http://www.racingpost.com/horses/result_home.sd?race_id=553995","http://www.racingpost.com/horses/result_home.sd?race_id=555115","http://www.racingpost.com/horses/result_home.sd?race_id=558709","http://www.racingpost.com/horses/result_home.sd?race_id=560078");

var horseLinks779123 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=779123","http://www.racingpost.com/horses/result_home.sd?race_id=521430","http://www.racingpost.com/horses/result_home.sd?race_id=525937","http://www.racingpost.com/horses/result_home.sd?race_id=528274","http://www.racingpost.com/horses/result_home.sd?race_id=529703","http://www.racingpost.com/horses/result_home.sd?race_id=534534","http://www.racingpost.com/horses/result_home.sd?race_id=535639","http://www.racingpost.com/horses/result_home.sd?race_id=535651","http://www.racingpost.com/horses/result_home.sd?race_id=538376","http://www.racingpost.com/horses/result_home.sd?race_id=561017");

var horseLinks788980 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=788980","http://www.racingpost.com/horses/result_home.sd?race_id=536016","http://www.racingpost.com/horses/result_home.sd?race_id=551151","http://www.racingpost.com/horses/result_home.sd?race_id=553158","http://www.racingpost.com/horses/result_home.sd?race_id=559642");

var horseLinks792488 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792488","http://www.racingpost.com/horses/result_home.sd?race_id=537662","http://www.racingpost.com/horses/result_home.sd?race_id=539389","http://www.racingpost.com/horses/result_home.sd?race_id=540509","http://www.racingpost.com/horses/result_home.sd?race_id=548476","http://www.racingpost.com/horses/result_home.sd?race_id=551182","http://www.racingpost.com/horses/result_home.sd?race_id=557490","http://www.racingpost.com/horses/result_home.sd?race_id=558709","http://www.racingpost.com/horses/result_home.sd?race_id=559873");

var horseLinks809223 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809223","http://www.racingpost.com/horses/result_home.sd?race_id=551175","http://www.racingpost.com/horses/result_home.sd?race_id=552433","http://www.racingpost.com/horses/result_home.sd?race_id=556881","http://www.racingpost.com/horses/result_home.sd?race_id=558709");

var horseLinks788930 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=788930","http://www.racingpost.com/horses/result_home.sd?race_id=534876","http://www.racingpost.com/horses/result_home.sd?race_id=535639","http://www.racingpost.com/horses/result_home.sd?race_id=535658","http://www.racingpost.com/horses/result_home.sd?race_id=536512","http://www.racingpost.com/horses/result_home.sd?race_id=539396","http://www.racingpost.com/horses/result_home.sd?race_id=548476","http://www.racingpost.com/horses/result_home.sd?race_id=551142","http://www.racingpost.com/horses/result_home.sd?race_id=557490");

var horseLinks790316 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790316","http://www.racingpost.com/horses/result_home.sd?race_id=536452","http://www.racingpost.com/horses/result_home.sd?race_id=537230","http://www.racingpost.com/horses/result_home.sd?race_id=538745","http://www.racingpost.com/horses/result_home.sd?race_id=540509","http://www.racingpost.com/horses/result_home.sd?race_id=551182","http://www.racingpost.com/horses/result_home.sd?race_id=555115","http://www.racingpost.com/horses/result_home.sd?race_id=555581","http://www.racingpost.com/horses/result_home.sd?race_id=556883","http://www.racingpost.com/horses/result_home.sd?race_id=559665","http://www.racingpost.com/horses/result_home.sd?race_id=560595","http://www.racingpost.com/horses/result_home.sd?race_id=560644","http://www.racingpost.com/horses/result_home.sd?race_id=561767");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562471" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562471" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Bonnie+Brae&id=743821&rnumber=562471" <?php $thisId=743821; include("markHorse.php");?>>Bonnie Brae</a></li>

<ol> 
<li><a href="horse.php?name=Bonnie+Brae&id=743821&rnumber=562471&url=/horses/result_home.sd?race_id=535375" id='h2hFormLink'>Instance </a></li> 
<li><a href="horse.php?name=Bonnie+Brae&id=743821&rnumber=562471&url=/horses/result_home.sd?race_id=534550" id='h2hFormLink'>Valencha </a></li> 
<li><a href="horse.php?name=Bonnie+Brae&id=743821&rnumber=562471&url=/horses/result_home.sd?race_id=540933" id='h2hFormLink'>Valencha </a></li> 
</ol> 
<li> <a href="horse.php?name=Instance&id=757009&rnumber=562471" <?php $thisId=757009; include("markHorse.php");?>>Instance</a></li>

<ol> 
<li><a href="horse.php?name=Instance&id=757009&rnumber=562471&url=/horses/result_home.sd?race_id=559718" id='h2hFormLink'>I'm So Glad </a></li> 
</ol> 
<li> <a href="horse.php?name=Libys+Dream&id=791398&rnumber=562471" <?php $thisId=791398; include("markHorse.php");?>>Libys Dream</a></li>

<ol> 
<li><a href="horse.php?name=Libys+Dream&id=791398&rnumber=562471&url=/horses/result_home.sd?race_id=555581" id='h2hFormLink'>Villeneuve </a></li> 
</ol> 
<li> <a href="horse.php?name=Neutrafa&id=790497&rnumber=562471" <?php $thisId=790497; include("markHorse.php");?>>Neutrafa</a></li>

<ol> 
<li><a href="horse.php?name=Neutrafa&id=790497&rnumber=562471&url=/horses/result_home.sd?race_id=560595" id='h2hFormLink'>Villeneuve </a></li> 
</ol> 
<li> <a href="horse.php?name=Valencha&id=759284&rnumber=562471" <?php $thisId=759284; include("markHorse.php");?>>Valencha</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471" <?php $thisId=785464; include("markHorse.php");?>>Regal Realm</a></li>

<ol> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=539396" id='h2hFormLink'>Alsindi </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Appealing </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=531245" id='h2hFormLink'>Gamilati </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Gamilati </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Inetrobil </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=539396" id='h2hFormLink'>Sunday Times </a></li> 
<li><a href="horse.php?name=Regal+Realm&id=785464&rnumber=562471&url=/horses/result_home.sd?race_id=551142" id='h2hFormLink'>Sunday Times </a></li> 
</ol> 
<li> <a href="horse.php?name=Alsindi&id=792221&rnumber=562471" <?php $thisId=792221; include("markHorse.php");?>>Alsindi</a></li>

<ol> 
<li><a href="horse.php?name=Alsindi&id=792221&rnumber=562471&url=/horses/result_home.sd?race_id=546056" id='h2hFormLink'>Gamilati </a></li> 
<li><a href="horse.php?name=Alsindi&id=792221&rnumber=562471&url=/horses/result_home.sd?race_id=547536" id='h2hFormLink'>Gamilati </a></li> 
<li><a href="horse.php?name=Alsindi&id=792221&rnumber=562471&url=/horses/result_home.sd?race_id=539396" id='h2hFormLink'>Sunday Times </a></li> 
<li><a href="horse.php?name=Alsindi&id=792221&rnumber=562471&url=/horses/result_home.sd?race_id=538745" id='h2hFormLink'>Villeneuve </a></li> 
</ol> 
<li> <a href="horse.php?name=Appealing&id=791511&rnumber=562471" <?php $thisId=791511; include("markHorse.php");?>>Appealing</a></li>

<ol> 
<li><a href="horse.php?name=Appealing&id=791511&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Gamilati </a></li> 
<li><a href="horse.php?name=Appealing&id=791511&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Inetrobil </a></li> 
<li><a href="horse.php?name=Appealing&id=791511&rnumber=562471&url=/horses/result_home.sd?race_id=557490" id='h2hFormLink'>Radio Gaga </a></li> 
<li><a href="horse.php?name=Appealing&id=791511&rnumber=562471&url=/horses/result_home.sd?race_id=557490" id='h2hFormLink'>Sunday Times </a></li> 
</ol> 
<li> <a href="horse.php?name=Coolnagree&id=782492&rnumber=562471" <?php $thisId=782492; include("markHorse.php");?>>Coolnagree</a></li>

<ol> 
<li><a href="horse.php?name=Coolnagree&id=782492&rnumber=562471&url=/horses/result_home.sd?race_id=559873" id='h2hFormLink'>Radio Gaga </a></li> 
</ol> 
<li> <a href="horse.php?name=Gamilati&id=786152&rnumber=562471" <?php $thisId=786152; include("markHorse.php");?>>Gamilati</a></li>

<ol> 
<li><a href="horse.php?name=Gamilati&id=786152&rnumber=562471&url=/horses/result_home.sd?race_id=534534" id='h2hFormLink'>Inetrobil </a></li> 
<li><a href="horse.php?name=Gamilati&id=786152&rnumber=562471&url=/horses/result_home.sd?race_id=534876" id='h2hFormLink'>Inetrobil </a></li> 
<li><a href="horse.php?name=Gamilati&id=786152&rnumber=562471&url=/horses/result_home.sd?race_id=560078" id='h2hFormLink'>Inetrobil </a></li> 
<li><a href="horse.php?name=Gamilati&id=786152&rnumber=562471&url=/horses/result_home.sd?race_id=534534" id='h2hFormLink'>Miss Work Of Art </a></li> 
<li><a href="horse.php?name=Gamilati&id=786152&rnumber=562471&url=/horses/result_home.sd?race_id=534876" id='h2hFormLink'>Sunday Times </a></li> 
</ol> 
<li> <a href="horse.php?name=I'm+So+Glad&id=790071&rnumber=562471" <?php $thisId=790071; include("markHorse.php");?>>I'm So Glad</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Inetrobil&id=786495&rnumber=562471" <?php $thisId=786495; include("markHorse.php");?>>Inetrobil</a></li>

<ol> 
<li><a href="horse.php?name=Inetrobil&id=786495&rnumber=562471&url=/horses/result_home.sd?race_id=534534" id='h2hFormLink'>Miss Work Of Art </a></li> 
<li><a href="horse.php?name=Inetrobil&id=786495&rnumber=562471&url=/horses/result_home.sd?race_id=558709" id='h2hFormLink'>Radio Gaga </a></li> 
<li><a href="horse.php?name=Inetrobil&id=786495&rnumber=562471&url=/horses/result_home.sd?race_id=558709" id='h2hFormLink'>Sentaril </a></li> 
<li><a href="horse.php?name=Inetrobil&id=786495&rnumber=562471&url=/horses/result_home.sd?race_id=534876" id='h2hFormLink'>Sunday Times </a></li> 
<li><a href="horse.php?name=Inetrobil&id=786495&rnumber=562471&url=/horses/result_home.sd?race_id=555115" id='h2hFormLink'>Villeneuve </a></li> 
</ol> 
<li> <a href="horse.php?name=Miss+Work+Of+Art&id=779123&rnumber=562471" <?php $thisId=779123; include("markHorse.php");?>>Miss Work Of Art</a></li>

<ol> 
<li><a href="horse.php?name=Miss+Work+Of+Art&id=779123&rnumber=562471&url=/horses/result_home.sd?race_id=535639" id='h2hFormLink'>Sunday Times </a></li> 
</ol> 
<li> <a href="horse.php?name=Perfect+Step&id=788980&rnumber=562471" <?php $thisId=788980; include("markHorse.php");?>>Perfect Step</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471" <?php $thisId=792488; include("markHorse.php");?>>Radio Gaga</a></li>

<ol> 
<li><a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471&url=/horses/result_home.sd?race_id=558709" id='h2hFormLink'>Sentaril </a></li> 
<li><a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471&url=/horses/result_home.sd?race_id=548476" id='h2hFormLink'>Sunday Times </a></li> 
<li><a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471&url=/horses/result_home.sd?race_id=557490" id='h2hFormLink'>Sunday Times </a></li> 
<li><a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471&url=/horses/result_home.sd?race_id=540509" id='h2hFormLink'>Villeneuve </a></li> 
<li><a href="horse.php?name=Radio+Gaga&id=792488&rnumber=562471&url=/horses/result_home.sd?race_id=551182" id='h2hFormLink'>Villeneuve </a></li> 
</ol> 
<li> <a href="horse.php?name=Sentaril&id=809223&rnumber=562471" <?php $thisId=809223; include("markHorse.php");?>>Sentaril</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sunday+Times&id=788930&rnumber=562471" <?php $thisId=788930; include("markHorse.php");?>>Sunday Times</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Villeneuve&id=790316&rnumber=562471" <?php $thisId=790316; include("markHorse.php");?>>Villeneuve</a></li>

<ol> 
</ol> 
</ol>