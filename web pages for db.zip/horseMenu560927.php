
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks786635 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=786635","http://www.racingpost.com/horses/result_home.sd?race_id=532479","http://www.racingpost.com/horses/result_home.sd?race_id=536934","http://www.racingpost.com/horses/result_home.sd?race_id=549989","http://www.racingpost.com/horses/result_home.sd?race_id=551149","http://www.racingpost.com/horses/result_home.sd?race_id=555059","http://www.racingpost.com/horses/result_home.sd?race_id=556881","http://www.racingpost.com/horses/result_home.sd?race_id=558666");

var horseLinks778977 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778977","http://www.racingpost.com/horses/result_home.sd?race_id=521430","http://www.racingpost.com/horses/result_home.sd?race_id=527095","http://www.racingpost.com/horses/result_home.sd?race_id=529673","http://www.racingpost.com/horses/result_home.sd?race_id=530472","http://www.racingpost.com/horses/result_home.sd?race_id=534072","http://www.racingpost.com/horses/result_home.sd?race_id=535746","http://www.racingpost.com/horses/result_home.sd?race_id=552471","http://www.racingpost.com/horses/result_home.sd?race_id=554426","http://www.racingpost.com/horses/result_home.sd?race_id=555795","http://www.racingpost.com/horses/result_home.sd?race_id=557025","http://www.racingpost.com/horses/result_home.sd?race_id=559257","http://www.racingpost.com/horses/result_home.sd?race_id=560059");

var horseLinks790071 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790071","http://www.racingpost.com/horses/result_home.sd?race_id=535323","http://www.racingpost.com/horses/result_home.sd?race_id=536197","http://www.racingpost.com/horses/result_home.sd?race_id=551174","http://www.racingpost.com/horses/result_home.sd?race_id=553789","http://www.racingpost.com/horses/result_home.sd?race_id=555768","http://www.racingpost.com/horses/result_home.sd?race_id=556285","http://www.racingpost.com/horses/result_home.sd?race_id=556901","http://www.racingpost.com/horses/result_home.sd?race_id=558036","http://www.racingpost.com/horses/result_home.sd?race_id=559718");

var horseLinks789484 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=789484","http://www.racingpost.com/horses/result_home.sd?race_id=538646","http://www.racingpost.com/horses/result_home.sd?race_id=540070","http://www.racingpost.com/horses/result_home.sd?race_id=548476","http://www.racingpost.com/horses/result_home.sd?race_id=557490","http://www.racingpost.com/horses/result_home.sd?race_id=559701");

var horseLinks810452 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810452","http://www.racingpost.com/horses/result_home.sd?race_id=553703","http://www.racingpost.com/horses/result_home.sd?race_id=554960","http://www.racingpost.com/horses/result_home.sd?race_id=556894","http://www.racingpost.com/horses/result_home.sd?race_id=558189","http://www.racingpost.com/horses/result_home.sd?race_id=559629");

var horseLinks778848 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778848","http://www.racingpost.com/horses/result_home.sd?race_id=534507","http://www.racingpost.com/horses/result_home.sd?race_id=535745","http://www.racingpost.com/horses/result_home.sd?race_id=540118","http://www.racingpost.com/horses/result_home.sd?race_id=557025","http://www.racingpost.com/horses/result_home.sd?race_id=559721");

var horseLinks790365 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=790365","http://www.racingpost.com/horses/result_home.sd?race_id=536918","http://www.racingpost.com/horses/result_home.sd?race_id=537668","http://www.racingpost.com/horses/result_home.sd?race_id=538349","http://www.racingpost.com/horses/result_home.sd?race_id=538879","http://www.racingpost.com/horses/result_home.sd?race_id=540113");

var horseLinks796305 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=796305","http://www.racingpost.com/horses/result_home.sd?race_id=540099","http://www.racingpost.com/horses/result_home.sd?race_id=557393","http://www.racingpost.com/horses/result_home.sd?race_id=558707","http://www.racingpost.com/horses/result_home.sd?race_id=560054");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560927" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560927" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Eastern+Sun&id=786635&rnumber=560927" <?php $thisId=786635; include("markHorse.php");?>>Eastern Sun</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Apostle&id=778977&rnumber=560927" <?php $thisId=778977; include("markHorse.php");?>>Apostle</a></li>

<ol> 
<li><a href="horse.php?name=Apostle&id=778977&rnumber=560927&url=/horses/result_home.sd?race_id=557025" id='h2hFormLink'>Nawwaar </a></li> 
</ol> 
<li> <a href="horse.php?name=I'm+So+Glad&id=790071&rnumber=560927" <?php $thisId=790071; include("markHorse.php");?>>I'm So Glad</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Diala&id=789484&rnumber=560927" <?php $thisId=789484; include("markHorse.php");?>>Diala</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dutch+Supreme&id=810452&rnumber=560927" <?php $thisId=810452; include("markHorse.php");?>>Dutch Supreme</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Nawwaar&id=778848&rnumber=560927" <?php $thisId=778848; include("markHorse.php");?>>Nawwaar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Strictly+Silver&id=790365&rnumber=560927" <?php $thisId=790365; include("markHorse.php");?>>Strictly Silver</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hallings+Comet&id=796305&rnumber=560927" <?php $thisId=796305; include("markHorse.php");?>>Hallings Comet</a></li>

<ol> 
</ol> 
</ol>