
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks800225 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800225","http://www.racingpost.com/horses/result_home.sd?race_id=560574");

var horseLinks802213 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802213","http://www.racingpost.com/horses/result_home.sd?race_id=556349","http://www.racingpost.com/horses/result_home.sd?race_id=558696","http://www.racingpost.com/horses/result_home.sd?race_id=559566","http://www.racingpost.com/horses/result_home.sd?race_id=562329");

var horseLinks810773 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810773","http://www.racingpost.com/horses/result_home.sd?race_id=553065","http://www.racingpost.com/horses/result_home.sd?race_id=553694","http://www.racingpost.com/horses/result_home.sd?race_id=555095","http://www.racingpost.com/horses/result_home.sd?race_id=556866","http://www.racingpost.com/horses/result_home.sd?race_id=558035","http://www.racingpost.com/horses/result_home.sd?race_id=561364");

var horseLinks817102 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817102","http://www.racingpost.com/horses/result_home.sd?race_id=560892");

var horseLinks814177 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814177","http://www.racingpost.com/horses/result_home.sd?race_id=559670","http://www.racingpost.com/horses/result_home.sd?race_id=560996");

var horseLinks815827 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815827","http://www.racingpost.com/horses/result_home.sd?race_id=558705","http://www.racingpost.com/horses/result_home.sd?race_id=561133","http://www.racingpost.com/horses/result_home.sd?race_id=561350");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562500" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562500" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Ashdan&id=800225&rnumber=562500" <?php $thisId=800225; include("markHorse.php");?>>Ashdan</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=One+Word+More&id=802213&rnumber=562500" <?php $thisId=802213; include("markHorse.php");?>>One Word More</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Top+Notch+Tonto&id=810773&rnumber=562500" <?php $thisId=810773; include("markHorse.php");?>>Top Notch Tonto</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Georgian+Bay&id=817102&rnumber=562500" <?php $thisId=817102; include("markHorse.php");?>>Georgian Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ninjago&id=814177&rnumber=562500" <?php $thisId=814177; include("markHorse.php");?>>Ninjago</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=No+Jet+Lag&id=815827&rnumber=562500" <?php $thisId=815827; include("markHorse.php");?>>No Jet Lag</a></li>

<ol> 
</ol> 
</ol>