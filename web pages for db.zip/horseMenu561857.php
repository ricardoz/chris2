
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks818997 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818997");

var horseLinks816717 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816717","http://www.racingpost.com/horses/result_home.sd?race_id=560195","http://www.racingpost.com/horses/result_home.sd?race_id=561028");

var horseLinks795966 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795966","http://www.racingpost.com/horses/result_home.sd?race_id=540144","http://www.racingpost.com/horses/result_home.sd?race_id=542836");

var horseLinks813418 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813418","http://www.racingpost.com/horses/result_home.sd?race_id=555828","http://www.racingpost.com/horses/result_home.sd?race_id=558768");

var horseLinks813295 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813295","http://www.racingpost.com/horses/result_home.sd?race_id=555191");

var horseLinks818989 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818989");

var horseLinks814029 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814029","http://www.racingpost.com/horses/result_home.sd?race_id=557600");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561857" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561857" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Bluegrass+Bid&id=818997&rnumber=561857" <?php $thisId=818997; include("markHorse.php");?>>Bluegrass Bid</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Boxatrix&id=816717&rnumber=561857" <?php $thisId=816717; include("markHorse.php");?>>Boxatrix</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Buffalospringfield&id=795966&rnumber=561857" <?php $thisId=795966; include("markHorse.php");?>>Buffalospringfield</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mumbles+Bay&id=813418&rnumber=561857" <?php $thisId=813418; include("markHorse.php");?>>Mumbles Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Revelations&id=813295&rnumber=561857" <?php $thisId=813295; include("markHorse.php");?>>Revelations</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sparkling+Hero&id=818989&rnumber=561857" <?php $thisId=818989; include("markHorse.php");?>>Sparkling Hero</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Too+Generous&id=814029&rnumber=561857" <?php $thisId=814029; include("markHorse.php");?>>Too Generous</a></li>

<ol> 
</ol> 
</ol>