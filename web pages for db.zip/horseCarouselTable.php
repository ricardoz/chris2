<table width="600px" border="2" id="horseCarouselTable">

<tr>

<td rowspan="2" id="horseCarouselNavigation">
<img src="leftArrow.gif" onclick="updateIframe(counter+1); return false"/>
<br />
<a href="#" onclick="updateIframe(counter-1); return false"><img src="rightArrow.gif"/></a>
</td>
<td>Horse Form / Race Name</td>

<td>H2H Horses</td>
</tr>

<tr>

<td id= "horseCarouselInformation">Race name to appear here</td>

<td id= "horseCarouselH2H">Other horses from both races here</td>
</tr>

</table>

<br />

