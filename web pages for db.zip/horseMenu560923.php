
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks817476 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817476");

var horseLinks815593 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815593","http://www.racingpost.com/horses/result_home.sd?race_id=559175","http://www.racingpost.com/horses/result_home.sd?race_id=560028");

var horseLinks813251 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813251","http://www.racingpost.com/horses/result_home.sd?race_id=560525");

var horseLinks810667 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810667","http://www.racingpost.com/horses/result_home.sd?race_id=555674","http://www.racingpost.com/horses/result_home.sd?race_id=558111","http://www.racingpost.com/horses/result_home.sd?race_id=560025");

var horseLinks816017 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816017");

var horseLinks813660 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813660","http://www.racingpost.com/horses/result_home.sd?race_id=555721","http://www.racingpost.com/horses/result_home.sd?race_id=556934","http://www.racingpost.com/horses/result_home.sd?race_id=561133");

var horseLinks816180 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816180","http://www.racingpost.com/horses/result_home.sd?race_id=558695","http://www.racingpost.com/horses/result_home.sd?race_id=559633");

var horseLinks818137 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818137");

var horseLinks818138 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818138");

var horseLinks813294 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813294","http://www.racingpost.com/horses/result_home.sd?race_id=555123","http://www.racingpost.com/horses/result_home.sd?race_id=559677");

var horseLinks817943 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817943");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560923" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560923" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Amulet&id=817476&rnumber=560923" <?php $thisId=817476; include("markHorse.php");?>>Amulet</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Choral+Rhythm&id=815593&rnumber=560923" <?php $thisId=815593; include("markHorse.php");?>>Choral Rhythm</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Chorister+Choir&id=813251&rnumber=560923" <?php $thisId=813251; include("markHorse.php");?>>Chorister Choir</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Cut+No+Ice&id=810667&rnumber=560923" <?php $thisId=810667; include("markHorse.php");?>>Cut No Ice</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Fearless+Jacq&id=816017&rnumber=560923" <?php $thisId=816017; include("markHorse.php");?>>Fearless Jacq</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Frege&id=813660&rnumber=560923" <?php $thisId=813660; include("markHorse.php");?>>Frege</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Girl+Of+Cadiz&id=816180&rnumber=560923" <?php $thisId=816180; include("markHorse.php");?>>Girl Of Cadiz</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Jazz+On+The+Beach&id=818137&rnumber=560923" <?php $thisId=818137; include("markHorse.php");?>>Jazz On The Beach</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Lady+Of+The+Vine&id=818138&rnumber=560923" <?php $thisId=818138; include("markHorse.php");?>>Lady Of The Vine</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Rosie+Future&id=813294&rnumber=560923" <?php $thisId=813294; include("markHorse.php");?>>Rosie Future</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Sherinn&id=817943&rnumber=560923" <?php $thisId=817943; include("markHorse.php");?>>Sherinn</a></li>

<ol> 
</ol> 
</ol>