
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks783418 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=783418","http://www.racingpost.com/horses/result_home.sd?race_id=528253","http://www.racingpost.com/horses/result_home.sd?race_id=528294","http://www.racingpost.com/horses/result_home.sd?race_id=530424","http://www.racingpost.com/horses/result_home.sd?race_id=531258","http://www.racingpost.com/horses/result_home.sd?race_id=532532","http://www.racingpost.com/horses/result_home.sd?race_id=533640","http://www.racingpost.com/horses/result_home.sd?race_id=534582","http://www.racingpost.com/horses/result_home.sd?race_id=535386","http://www.racingpost.com/horses/result_home.sd?race_id=535768","http://www.racingpost.com/horses/result_home.sd?race_id=537582","http://www.racingpost.com/horses/result_home.sd?race_id=538352","http://www.racingpost.com/horses/result_home.sd?race_id=551197","http://www.racingpost.com/horses/result_home.sd?race_id=558683","http://www.racingpost.com/horses/result_home.sd?race_id=559695","http://www.racingpost.com/horses/result_home.sd?race_id=560583");

var horseLinks778893 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778893","http://www.racingpost.com/horses/result_home.sd?race_id=536140","http://www.racingpost.com/horses/result_home.sd?race_id=536281","http://www.racingpost.com/horses/result_home.sd?race_id=538008","http://www.racingpost.com/horses/result_home.sd?race_id=539010","http://www.racingpost.com/horses/result_home.sd?race_id=543540","http://www.racingpost.com/horses/result_home.sd?race_id=544268","http://www.racingpost.com/horses/result_home.sd?race_id=545480","http://www.racingpost.com/horses/result_home.sd?race_id=547380","http://www.racingpost.com/horses/result_home.sd?race_id=551197","http://www.racingpost.com/horses/result_home.sd?race_id=553074","http://www.racingpost.com/horses/result_home.sd?race_id=554394","http://www.racingpost.com/horses/result_home.sd?race_id=556277","http://www.racingpost.com/horses/result_home.sd?race_id=557554","http://www.racingpost.com/horses/result_home.sd?race_id=558683","http://www.racingpost.com/horses/result_home.sd?race_id=559695","http://www.racingpost.com/horses/result_home.sd?race_id=560079");

var horseLinks788886 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=788886","http://www.racingpost.com/horses/result_home.sd?race_id=534112","http://www.racingpost.com/horses/result_home.sd?race_id=535023","http://www.racingpost.com/horses/result_home.sd?race_id=536604","http://www.racingpost.com/horses/result_home.sd?race_id=537141","http://www.racingpost.com/horses/result_home.sd?race_id=537998","http://www.racingpost.com/horses/result_home.sd?race_id=538758","http://www.racingpost.com/horses/result_home.sd?race_id=538967","http://www.racingpost.com/horses/result_home.sd?race_id=553139","http://www.racingpost.com/horses/result_home.sd?race_id=553794","http://www.racingpost.com/horses/result_home.sd?race_id=557545","http://www.racingpost.com/horses/result_home.sd?race_id=559122");

var horseLinks781027 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=781027","http://www.racingpost.com/horses/result_home.sd?race_id=525979","http://www.racingpost.com/horses/result_home.sd?race_id=527112","http://www.racingpost.com/horses/result_home.sd?race_id=528959","http://www.racingpost.com/horses/result_home.sd?race_id=531286","http://www.racingpost.com/horses/result_home.sd?race_id=531872","http://www.racingpost.com/horses/result_home.sd?race_id=533506","http://www.racingpost.com/horses/result_home.sd?race_id=533618","http://www.racingpost.com/horses/result_home.sd?race_id=536162","http://www.racingpost.com/horses/result_home.sd?race_id=536864","http://www.racingpost.com/horses/result_home.sd?race_id=538034","http://www.racingpost.com/horses/result_home.sd?race_id=538742","http://www.racingpost.com/horses/result_home.sd?race_id=548500","http://www.racingpost.com/horses/result_home.sd?race_id=551728","http://www.racingpost.com/horses/result_home.sd?race_id=552140","http://www.racingpost.com/horses/result_home.sd?race_id=554348","http://www.racingpost.com/horses/result_home.sd?race_id=555295","http://www.racingpost.com/horses/result_home.sd?race_id=555779","http://www.racingpost.com/horses/result_home.sd?race_id=556860","http://www.racingpost.com/horses/result_home.sd?race_id=557546","http://www.racingpost.com/horses/result_home.sd?race_id=558683","http://www.racingpost.com/horses/result_home.sd?race_id=560079");

var horseLinks787739 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=787739","http://www.racingpost.com/horses/result_home.sd?race_id=534784","http://www.racingpost.com/horses/result_home.sd?race_id=535835","http://www.racingpost.com/horses/result_home.sd?race_id=536765","http://www.racingpost.com/horses/result_home.sd?race_id=542627","http://www.racingpost.com/horses/result_home.sd?race_id=544119","http://www.racingpost.com/horses/result_home.sd?race_id=545303","http://www.racingpost.com/horses/result_home.sd?race_id=546341","http://www.racingpost.com/horses/result_home.sd?race_id=553319","http://www.racingpost.com/horses/result_home.sd?race_id=555936","http://www.racingpost.com/horses/result_home.sd?race_id=556749","http://www.racingpost.com/horses/result_home.sd?race_id=557649","http://www.racingpost.com/horses/result_home.sd?race_id=560079");

var horseLinks789727 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=789727","http://www.racingpost.com/horses/result_home.sd?race_id=534966","http://www.racingpost.com/horses/result_home.sd?race_id=536460","http://www.racingpost.com/horses/result_home.sd?race_id=537684","http://www.racingpost.com/horses/result_home.sd?race_id=538350","http://www.racingpost.com/horses/result_home.sd?race_id=539744","http://www.racingpost.com/horses/result_home.sd?race_id=551728","http://www.racingpost.com/horses/result_home.sd?race_id=553776","http://www.racingpost.com/horses/result_home.sd?race_id=555710","http://www.racingpost.com/horses/result_home.sd?race_id=556277","http://www.racingpost.com/horses/result_home.sd?race_id=558583","http://www.racingpost.com/horses/result_home.sd?race_id=560425");

var horseLinks782390 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=782390","http://www.racingpost.com/horses/result_home.sd?race_id=527607","http://www.racingpost.com/horses/result_home.sd?race_id=529608","http://www.racingpost.com/horses/result_home.sd?race_id=530412","http://www.racingpost.com/horses/result_home.sd?race_id=531963","http://www.racingpost.com/horses/result_home.sd?race_id=532532","http://www.racingpost.com/horses/result_home.sd?race_id=534554","http://www.racingpost.com/horses/result_home.sd?race_id=535342","http://www.racingpost.com/horses/result_home.sd?race_id=535645","http://www.racingpost.com/horses/result_home.sd?race_id=536845","http://www.racingpost.com/horses/result_home.sd?race_id=537580","http://www.racingpost.com/horses/result_home.sd?race_id=537950","http://www.racingpost.com/horses/result_home.sd?race_id=538688","http://www.racingpost.com/horses/result_home.sd?race_id=548517","http://www.racingpost.com/horses/result_home.sd?race_id=550551","http://www.racingpost.com/horses/result_home.sd?race_id=551678","http://www.racingpost.com/horses/result_home.sd?race_id=553127","http://www.racingpost.com/horses/result_home.sd?race_id=554412","http://www.racingpost.com/horses/result_home.sd?race_id=556318","http://www.racingpost.com/horses/result_home.sd?race_id=556889","http://www.racingpost.com/horses/result_home.sd?race_id=557412","http://www.racingpost.com/horses/result_home.sd?race_id=558161","http://www.racingpost.com/horses/result_home.sd?race_id=558727","http://www.racingpost.com/horses/result_home.sd?race_id=559215");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560981" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560981" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981" <?php $thisId=783418; include("markHorse.php");?>>Kool Henry</a></li>

<ol> 
<li><a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981&url=/horses/result_home.sd?race_id=551197" id='h2hFormLink'>Waseem Faris </a></li> 
<li><a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981&url=/horses/result_home.sd?race_id=558683" id='h2hFormLink'>Waseem Faris </a></li> 
<li><a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981&url=/horses/result_home.sd?race_id=559695" id='h2hFormLink'>Waseem Faris </a></li> 
<li><a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981&url=/horses/result_home.sd?race_id=558683" id='h2hFormLink'>Beau Mistral </a></li> 
<li><a href="horse.php?name=Kool+Henry&id=783418&rnumber=560981&url=/horses/result_home.sd?race_id=532532" id='h2hFormLink'>Economic Crisis </a></li> 
</ol> 
<li> <a href="horse.php?name=Waseem+Faris&id=778893&rnumber=560981" <?php $thisId=778893; include("markHorse.php");?>>Waseem Faris</a></li>

<ol> 
<li><a href="horse.php?name=Waseem+Faris&id=778893&rnumber=560981&url=/horses/result_home.sd?race_id=558683" id='h2hFormLink'>Beau Mistral </a></li> 
<li><a href="horse.php?name=Waseem+Faris&id=778893&rnumber=560981&url=/horses/result_home.sd?race_id=560079" id='h2hFormLink'>Beau Mistral </a></li> 
<li><a href="horse.php?name=Waseem+Faris&id=778893&rnumber=560981&url=/horses/result_home.sd?race_id=560079" id='h2hFormLink'>Harry Trotter </a></li> 
<li><a href="horse.php?name=Waseem+Faris&id=778893&rnumber=560981&url=/horses/result_home.sd?race_id=556277" id='h2hFormLink'>Chooseday </a></li> 
</ol> 
<li> <a href="horse.php?name=Kimbali&id=788886&rnumber=560981" <?php $thisId=788886; include("markHorse.php");?>>Kimbali</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Beau+Mistral&id=781027&rnumber=560981" <?php $thisId=781027; include("markHorse.php");?>>Beau Mistral</a></li>

<ol> 
<li><a href="horse.php?name=Beau+Mistral&id=781027&rnumber=560981&url=/horses/result_home.sd?race_id=560079" id='h2hFormLink'>Harry Trotter </a></li> 
<li><a href="horse.php?name=Beau+Mistral&id=781027&rnumber=560981&url=/horses/result_home.sd?race_id=551728" id='h2hFormLink'>Chooseday </a></li> 
</ol> 
<li> <a href="horse.php?name=Harry+Trotter&id=787739&rnumber=560981" <?php $thisId=787739; include("markHorse.php");?>>Harry Trotter</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Chooseday&id=789727&rnumber=560981" <?php $thisId=789727; include("markHorse.php");?>>Chooseday</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Economic+Crisis&id=782390&rnumber=560981" <?php $thisId=782390; include("markHorse.php");?>>Economic Crisis</a></li>

<ol> 
</ol> 
</ol>