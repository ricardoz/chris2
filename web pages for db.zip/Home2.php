

<html lang="eng">
  <head>
    <title>Creative Horse Racing Information System - Providing data for your systems</title>
    <meta name="description"
    content="Information for Horse Racing Systems">
    <meta name="keywords"
    content="Information, Screenshot,  Links, Breeding, Pedigree, Races, Silks, Horse, Racing, Systems"/>
  </head>
  
  <body>
  <a href="screenshot.html" target="_blank">
  <img src="Screenshot.jpg" title="CHRIS screenshot" 
  alt="Screenshot of the Creative Horse Racing Information System" align ="right"
  width="400" height="400"/>
  </a>
  <p><big><big><big><big><big>Welcome!</big></big></big></big></big> This site is used for evaluating the output of the   <strong>Creative Horse Racing Information System</strong>. 
  For navigation you can follow a link below or you can use the links in the frame on the left.
  
  
  
  <br/>
  <br/>

  

  
  <p> Choose the image of a horse's silks from the horizontal image map below to see the breeding information of the horse's in an imagary race we have created. This will give you an idea of the self-contained website the <strong>Creative Horse Racing Information System</strong> creates. In the program you can create a self-contained website for every race on any given day!
  <br/>
  <br/>
  <img src="image_map_horizontal.png" alt="horse image map" usemap="#horsemap" border="0"/>
<map name="horsemap">
  <area shape="rect" coords="0,0,40,29" href="alfie_flits.html" alt="Alfie Flits" target="_self" title="link to Alfie Flits page on this site">
  <area shape="rect" coords="40,0,80,29" href="ashammar.html" alt="Ashammar" target="_self" title="link to Ashammar page on this site">
  <area shape="rect" coords="80,0,120,29" href="blackpool_billy.html" alt="Blackpool Billy" target="_self" title="link to Blackpool Billys page on this site">
  <area shape="rect" coords="120,0,160,29" href="more_shennanigans.html" alt="More Shennanigans" target="_self" 
  title="link to More Shennanigans page on this site">
  <area shape="rect" coords="160,0,200,29" href="prideus.html" alt="Prideus" target="_self" title="link to Prideus page on this site">
  <area shape="rect" coords="200,0,240,29" href="steel_man.html" alt="Steel Man" target="_self" title="link to Steel Man page on this site">
</map>

<br/>

  <p> The horses from left to right are:
  <ol>
  
  <li><a href="Alfie_flits.html" target='_self' title="link to Alfie Flits webpage">Alfie Flits</a></li>
  <li><a href="Ashammar.html" target='_self' title="link to Ashammar webpage">Ashammar</a></li>
  <li><a href="Blackpool Billy.html" target='_self' title="link to Blackpool Billy Racing Post webpage">Blackpool Billy</a></li>
  <li><a href="more_shennanigans.html" target='_self' title="link to More Shennanigans webpage">More Shennanigans</a></li>
  <li><a href="Prideus.html" target='_self' title="link to Prideus webpage">Prideus</a></li>
  <li><a href="steel_man.html" target='_self' title="link to Steel Man webpage">Steel Man</a></li>
  
 
  </ol>
  
<br>

<p> <strong>Do you have the recipe for the perfect system?</strong> Come view our <em>'ingredients'</em>
 page in the list below to see if we have what you need. This is where we make the information and links we capture about races and horses available to you, the user. If anything catches your eye, there are multiple links to our e-mail address on each page.
 <br>
 
 <ol>
 
 <li><a href="races/NHInfo.html" target='_self' title="link to National Hunt Information webpage">National Hunt Information</a></li>
 <li><a href="races/NHLinks.html" target='_self' title="link to National Hunt Links webpage">National Hunt Links</a></li>
 <li><a href="races/AWInfo.html" target='_self' title="link to All Weather Information webpage">All Weather Information</a></li>
 <li><a href="races/AWLinks.html" target='_self' title="link to All Weather Links webpage">All Weather Links</a></li>
 <li><a href="races/ForeignInfo.html" target='_self' title="link to Foreign Race Information webpage">Foreign Race Information</a></li>
 <li><a href="races/ForeignLinks.html" target='_self' title="link to Foreign Race Links webpage">Foreign Race Links</a></li>

 </ol>


  
  
  </body>
</html>