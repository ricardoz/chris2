
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks773195 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=773195","http://www.racingpost.com/horses/result_home.sd?race_id=549518","http://www.racingpost.com/horses/result_home.sd?race_id=551725","http://www.racingpost.com/horses/result_home.sd?race_id=553357");

var horseLinks792477 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792477","http://www.racingpost.com/horses/result_home.sd?race_id=538021","http://www.racingpost.com/horses/result_home.sd?race_id=538955");

var horseLinks779058 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=779058","http://www.racingpost.com/horses/result_home.sd?race_id=560603");

var horseLinks795221 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795221","http://www.racingpost.com/horses/result_home.sd?race_id=549975","http://www.racingpost.com/horses/result_home.sd?race_id=551125","http://www.racingpost.com/horses/result_home.sd?race_id=553130");

var horseLinks795956 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=795956","http://www.racingpost.com/horses/result_home.sd?race_id=540092","http://www.racingpost.com/horses/result_home.sd?race_id=553770");

var horseLinks792450 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=792450","http://www.racingpost.com/horses/result_home.sd?race_id=537642","http://www.racingpost.com/horses/result_home.sd?race_id=540070","http://www.racingpost.com/horses/result_home.sd?race_id=549027","http://www.racingpost.com/horses/result_home.sd?race_id=553115","http://www.racingpost.com/horses/result_home.sd?race_id=553908","http://www.racingpost.com/horses/result_home.sd?race_id=555032");

var horseLinks817518 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817518","http://www.racingpost.com/horses/result_home.sd?race_id=560833");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561708" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561708" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Falkland&id=773195&rnumber=561708" <?php $thisId=773195; include("markHorse.php");?>>Falkland</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Inqadh&id=792477&rnumber=561708" <?php $thisId=792477; include("markHorse.php");?>>Inqadh</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tiger+Cliff&id=779058&rnumber=561708" <?php $thisId=779058; include("markHorse.php");?>>Tiger Cliff</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Ty+Gwr&id=795221&rnumber=561708" <?php $thisId=795221; include("markHorse.php");?>>Ty Gwr</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Openly&id=795956&rnumber=561708" <?php $thisId=795956; include("markHorse.php");?>>Openly</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Safarjal&id=792450&rnumber=561708" <?php $thisId=792450; include("markHorse.php");?>>Safarjal</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Shea&id=817518&rnumber=561708" <?php $thisId=817518; include("markHorse.php");?>>Shea</a></li>

<ol> 
</ol> 
</ol>