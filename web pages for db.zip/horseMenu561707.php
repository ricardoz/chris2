
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks816115 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816115","http://www.racingpost.com/horses/result_home.sd?race_id=559725");

var horseLinks800490 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=800490","http://www.racingpost.com/horses/result_home.sd?race_id=560457","http://www.racingpost.com/horses/result_home.sd?race_id=561274");

var horseLinks816980 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816980","http://www.racingpost.com/horses/result_home.sd?race_id=560143");

var horseLinks815352 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815352","http://www.racingpost.com/horses/result_home.sd?race_id=559620","http://www.racingpost.com/horses/result_home.sd?race_id=560469");

var horseLinks815373 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815373","http://www.racingpost.com/horses/result_home.sd?race_id=559994","http://www.racingpost.com/horses/result_home.sd?race_id=560963");

var horseLinks805494 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805494","http://www.racingpost.com/horses/result_home.sd?race_id=561921");

var horseLinks805577 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805577","http://www.racingpost.com/horses/result_home.sd?race_id=554979","http://www.racingpost.com/horses/result_home.sd?race_id=560949");

var horseLinks818895 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818895");

var horseLinks818896 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818896");

var horseLinks810115 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810115","http://www.racingpost.com/horses/result_home.sd?race_id=561938");

var horseLinks818232 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818232");

var horseLinks817158 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817158","http://www.racingpost.com/horses/result_home.sd?race_id=560098");

var horseLinks818409 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818409","http://www.racingpost.com/horses/result_home.sd?race_id=561274");

var horseLinks818894 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818894");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561707" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561707" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Admirals+Walk&id=816115&rnumber=561707" <?php $thisId=816115; include("markHorse.php");?>>Admirals Walk</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Alcaeus&id=800490&rnumber=561707" <?php $thisId=800490; include("markHorse.php");?>>Alcaeus</a></li>

<ol> 
<li><a href="horse.php?name=Alcaeus&id=800490&rnumber=561707&url=/horses/result_home.sd?race_id=561274" id='h2hFormLink'>Aphrodite's Dream </a></li> 
</ol> 
<li> <a href="horse.php?name=Baltic+Knight&id=816980&rnumber=561707" <?php $thisId=816980; include("markHorse.php");?>>Baltic Knight</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Canadian+Run&id=815352&rnumber=561707" <?php $thisId=815352; include("markHorse.php");?>>Canadian Run</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Forceful+Flame&id=815373&rnumber=561707" <?php $thisId=815373; include("markHorse.php");?>>Forceful Flame</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Grand+Denial&id=805494&rnumber=561707" <?php $thisId=805494; include("markHorse.php");?>>Grand Denial</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Intimidate&id=805577&rnumber=561707" <?php $thisId=805577; include("markHorse.php");?>>Intimidate</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Kastini&id=818895&rnumber=561707" <?php $thisId=818895; include("markHorse.php");?>>Kastini</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Miguel+Grau&id=818896&rnumber=561707" <?php $thisId=818896; include("markHorse.php");?>>Miguel Grau</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mishaal&id=810115&rnumber=561707" <?php $thisId=810115; include("markHorse.php");?>>Mishaal</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Misleading+Promise&id=818232&rnumber=561707" <?php $thisId=818232; include("markHorse.php");?>>Misleading Promise</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Mumeyez&id=817158&rnumber=561707" <?php $thisId=817158; include("markHorse.php");?>>Mumeyez</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Aphrodite's+Dream&id=818409&rnumber=561707" <?php $thisId=818409; include("markHorse.php");?>>Aphrodite's Dream</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Eliza+Snow&id=818894&rnumber=561707" <?php $thisId=818894; include("markHorse.php");?>>Eliza Snow</a></li>

<ol> 
</ol> 
</ol>