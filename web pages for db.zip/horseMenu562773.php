
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks810109 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810109","http://www.racingpost.com/horses/result_home.sd?race_id=560116","http://www.racingpost.com/horses/result_home.sd?race_id=561227","http://www.racingpost.com/horses/result_home.sd?race_id=561615");

var horseLinks818222 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818222","http://www.racingpost.com/horses/result_home.sd?race_id=562136","http://www.racingpost.com/horses/result_home.sd?race_id=562402");

var horseLinks807290 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807290","http://www.racingpost.com/horses/result_home.sd?race_id=548477","http://www.racingpost.com/horses/result_home.sd?race_id=549517","http://www.racingpost.com/horses/result_home.sd?race_id=549984","http://www.racingpost.com/horses/result_home.sd?race_id=553196","http://www.racingpost.com/horses/result_home.sd?race_id=554322","http://www.racingpost.com/horses/result_home.sd?race_id=555728","http://www.racingpost.com/horses/result_home.sd?race_id=556866","http://www.racingpost.com/horses/result_home.sd?race_id=558587","http://www.racingpost.com/horses/result_home.sd?race_id=561280","http://www.racingpost.com/horses/result_home.sd?race_id=561776");

var horseLinks814923 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814923","http://www.racingpost.com/horses/result_home.sd?race_id=557583","http://www.racingpost.com/horses/result_home.sd?race_id=562161");

var horseLinks802079 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802079","http://www.racingpost.com/horses/result_home.sd?race_id=560416","http://www.racingpost.com/horses/result_home.sd?race_id=562081");

var horseLinks816927 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816927","http://www.racingpost.com/horses/result_home.sd?race_id=560876","http://www.racingpost.com/horses/result_home.sd?race_id=562108");

var horseLinks814161 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=814161","http://www.racingpost.com/horses/result_home.sd?race_id=556960","http://www.racingpost.com/horses/result_home.sd?race_id=558144","http://www.racingpost.com/horses/result_home.sd?race_id=559628","http://www.racingpost.com/horses/result_home.sd?race_id=560892");

var horseLinks817418 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817418","http://www.racingpost.com/horses/result_home.sd?race_id=560106","http://www.racingpost.com/horses/result_home.sd?race_id=562136");

var horseLinks805446 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805446");

var horseLinks817476 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817476");

var horseLinks818129 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818129","http://www.racingpost.com/horses/result_home.sd?race_id=561378");

var horseLinks810995 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810995");

var horseLinks818414 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=818414");

var horseLinks816495 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816495","http://www.racingpost.com/horses/result_home.sd?race_id=559620","http://www.racingpost.com/horses/result_home.sd?race_id=560930","http://www.racingpost.com/horses/result_home.sd?race_id=562093");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562773" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562773" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Arctic+Admiral&id=810109&rnumber=562773" <?php $thisId=810109; include("markHorse.php");?>>Arctic Admiral</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hanga+Roa&id=818222&rnumber=562773" <?php $thisId=818222; include("markHorse.php");?>>Hanga Roa</a></li>

<ol> 
<li><a href="horse.php?name=Hanga+Roa&id=818222&rnumber=562773&url=/horses/result_home.sd?race_id=562136" id='h2hFormLink'>Work Ethic </a></li> 
</ol> 
<li> <a href="horse.php?name=Marvelino&id=807290&rnumber=562773" <?php $thisId=807290; include("markHorse.php");?>>Marvelino</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Pinarius&id=814923&rnumber=562773" <?php $thisId=814923; include("markHorse.php");?>>Pinarius</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Spanish+Art&id=802079&rnumber=562773" <?php $thisId=802079; include("markHorse.php");?>>Spanish Art</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Speedfit+Boy&id=816927&rnumber=562773" <?php $thisId=816927; include("markHorse.php");?>>Speedfit Boy</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tropical+Song&id=814161&rnumber=562773" <?php $thisId=814161; include("markHorse.php");?>>Tropical Song</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Work+Ethic&id=817418&rnumber=562773" <?php $thisId=817418; include("markHorse.php");?>>Work Ethic</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Al+Manaal&id=805446&rnumber=562773" <?php $thisId=805446; include("markHorse.php");?>>Al Manaal</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Amulet&id=817476&rnumber=562773" <?php $thisId=817476; include("markHorse.php");?>>Amulet</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Midnight+Flower&id=818129&rnumber=562773" <?php $thisId=818129; include("markHorse.php");?>>Midnight Flower</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Perfect+Calm&id=810995&rnumber=562773" <?php $thisId=810995; include("markHorse.php");?>>Perfect Calm</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Shagwa&id=818414&rnumber=562773" <?php $thisId=818414; include("markHorse.php");?>>Shagwa</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Pink+Mischief&id=816495&rnumber=562773" <?php $thisId=816495; include("markHorse.php");?>>Pink Mischief</a></li>

<ol> 
</ol> 
</ol>