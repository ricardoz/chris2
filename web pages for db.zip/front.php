<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html lang="eng">
  <head>
    <title>Creative Horse Racing Information System - Providing data for your systems</title>
    <meta name="description"
    content="Information for Horse Racing Systems">
    <meta name="keywords"
    content="Information, Screenshot,  Links, Breeding, Pedigree, Races, Silks, Horse, Racing, Systems">
    <link rel="stylesheet" type="text/css" href="homeLayout.css" >
  </head>
  
  <?php
  if (!isset($_COOKIE['userId']))

{

$loggedIn = false; 

} else if (isset($_COOKIE['username'])){ 

$_SESSION['username'] = $_COOKIE['username'];

$loggedIn = true;


}
  ?>
  
   
  <div id="topDiv" title="Website banner, used as link to return to main page">
  <?php 
  	include('banner.html');
  ?>
  </div>

  
  	
  	<div  id="leftDiv" title="Website menu, holds links to all the pages available on the site, used for navigation">
  		<?php include('login.php'); ?>
  	</div>
    <div id="mainDiv" title="Main Window: when a link is pressed content will appear in this frame">
   	<?php 
  		include('Home2.php');
  	?>
 	</div>

  
</html>