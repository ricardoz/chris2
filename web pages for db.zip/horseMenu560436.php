
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks807327 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807327","http://www.racingpost.com/horses/result_home.sd?race_id=549517","http://www.racingpost.com/horses/result_home.sd?race_id=552381","http://www.racingpost.com/horses/result_home.sd?race_id=553768","http://www.racingpost.com/horses/result_home.sd?race_id=555108","http://www.racingpost.com/horses/result_home.sd?race_id=556864","http://www.racingpost.com/horses/result_home.sd?race_id=558663","http://www.racingpost.com/horses/result_home.sd?race_id=558794","http://www.racingpost.com/horses/result_home.sd?race_id=560055");

var horseLinks807983 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=807983","http://www.racingpost.com/horses/result_home.sd?race_id=551173","http://www.racingpost.com/horses/result_home.sd?race_id=553196","http://www.racingpost.com/horses/result_home.sd?race_id=556639","http://www.racingpost.com/horses/result_home.sd?race_id=556904","http://www.racingpost.com/horses/result_home.sd?race_id=558794","http://www.racingpost.com/horses/result_home.sd?race_id=560055","http://www.racingpost.com/horses/result_home.sd?race_id=563828");

var horseLinks805592 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805592","http://www.racingpost.com/horses/result_home.sd?race_id=555395","http://www.racingpost.com/horses/result_home.sd?race_id=563498");

var horseLinks802061 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802061","http://www.racingpost.com/horses/result_home.sd?race_id=553743","http://www.racingpost.com/horses/result_home.sd?race_id=556864");

var horseLinks805639 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805639","http://www.racingpost.com/horses/result_home.sd?race_id=551140","http://www.racingpost.com/horses/result_home.sd?race_id=553710","http://www.racingpost.com/horses/result_home.sd?race_id=556941","http://www.racingpost.com/horses/result_home.sd?race_id=559128","http://www.racingpost.com/horses/result_home.sd?race_id=559634","http://www.racingpost.com/horses/result_home.sd?race_id=560131","http://www.racingpost.com/horses/result_home.sd?race_id=561363");

var horseLinks812712 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812712","http://www.racingpost.com/horses/result_home.sd?race_id=554362","http://www.racingpost.com/horses/result_home.sd?race_id=555075","http://www.racingpost.com/horses/result_home.sd?race_id=556864","http://www.racingpost.com/horses/result_home.sd?race_id=558698","http://www.racingpost.com/horses/result_home.sd?race_id=560055","http://www.racingpost.com/horses/result_home.sd?race_id=561766");

var horseLinks816416 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=816416","http://www.racingpost.com/horses/result_home.sd?race_id=559288","http://www.racingpost.com/horses/result_home.sd?race_id=562662");

var horseLinks815854 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815854","http://www.racingpost.com/horses/result_home.sd?race_id=560538");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560436" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560436" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436" <?php $thisId=807327; include("markHorse.php");?>>Heavy Metal</a></li>

<ol> 
<li><a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436&url=/horses/result_home.sd?race_id=558794" id='h2hFormLink'>Cay Verde </a></li> 
<li><a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436&url=/horses/result_home.sd?race_id=560055" id='h2hFormLink'>Cay Verde </a></li> 
<li><a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436&url=/horses/result_home.sd?race_id=556864" id='h2hFormLink'>Funk Soul Brother </a></li> 
<li><a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436&url=/horses/result_home.sd?race_id=556864" id='h2hFormLink'>Master Of War </a></li> 
<li><a href="horse.php?name=Heavy+Metal&id=807327&rnumber=560436&url=/horses/result_home.sd?race_id=560055" id='h2hFormLink'>Master Of War </a></li> 
</ol> 
<li> <a href="horse.php?name=Cay+Verde&id=807983&rnumber=560436" <?php $thisId=807983; include("markHorse.php");?>>Cay Verde</a></li>

<ol> 
<li><a href="horse.php?name=Cay+Verde&id=807983&rnumber=560436&url=/horses/result_home.sd?race_id=560055" id='h2hFormLink'>Master Of War </a></li> 
</ol> 
<li> <a href="horse.php?name=Cougar+Ridge&id=805592&rnumber=560436" <?php $thisId=805592; include("markHorse.php");?>>Cougar Ridge</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Funk+Soul+Brother&id=802061&rnumber=560436" <?php $thisId=802061; include("markHorse.php");?>>Funk Soul Brother</a></li>

<ol> 
<li><a href="horse.php?name=Funk+Soul+Brother&id=802061&rnumber=560436&url=/horses/result_home.sd?race_id=556864" id='h2hFormLink'>Master Of War </a></li> 
</ol> 
<li> <a href="horse.php?name=Lucky+Beggar&id=805639&rnumber=560436" <?php $thisId=805639; include("markHorse.php");?>>Lucky Beggar</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Master+Of+War&id=812712&rnumber=560436" <?php $thisId=812712; include("markHorse.php");?>>Master Of War</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Moohaajim&id=816416&rnumber=560436" <?php $thisId=816416; include("markHorse.php");?>>Moohaajim</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Taayel&id=815854&rnumber=560436" <?php $thisId=815854; include("markHorse.php");?>>Taayel</a></li>

<ol> 
</ol> 
</ol>