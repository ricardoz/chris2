
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks805390 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=805390","http://www.racingpost.com/horses/result_home.sd?race_id=556844","http://www.racingpost.com/horses/result_home.sd?race_id=559683");

var horseLinks809822 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=809822","http://www.racingpost.com/horses/result_home.sd?race_id=551721","http://www.racingpost.com/horses/result_home.sd?race_id=553114","http://www.racingpost.com/horses/result_home.sd?race_id=554393","http://www.racingpost.com/horses/result_home.sd?race_id=555023","http://www.racingpost.com/horses/result_home.sd?race_id=558157","http://www.racingpost.com/horses/result_home.sd?race_id=559684","http://www.racingpost.com/horses/result_home.sd?race_id=560135");

var horseLinks812950 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=812950","http://www.racingpost.com/horses/result_home.sd?race_id=555647","http://www.racingpost.com/horses/result_home.sd?race_id=557448","http://www.racingpost.com/horses/result_home.sd?race_id=559734");

var horseLinks810658 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=810658","http://www.racingpost.com/horses/result_home.sd?race_id=552447","http://www.racingpost.com/horses/result_home.sd?race_id=559573","http://www.racingpost.com/horses/result_home.sd?race_id=560483");

var horseLinks802222 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802222");

var horseLinks817687 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817687");

var horseLinks815202 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=815202","http://www.racingpost.com/horses/result_home.sd?race_id=557506","http://www.racingpost.com/horses/result_home.sd?race_id=558623");

var horseLinks817809 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=817809");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=560912" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=560912" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Avec+Rose&id=805390&rnumber=560912" <?php $thisId=805390; include("markHorse.php");?>>Avec Rose</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Blue+Clumber&id=809822&rnumber=560912" <?php $thisId=809822; include("markHorse.php");?>>Blue Clumber</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Dark+Opal&id=812950&rnumber=560912" <?php $thisId=812950; include("markHorse.php");?>>Dark Opal</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Elusive+Shadow&id=810658&rnumber=560912" <?php $thisId=810658; include("markHorse.php");?>>Elusive Shadow</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Equinox&id=802222&rnumber=560912" <?php $thisId=802222; include("markHorse.php");?>>Equinox</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Hit+The+Note&id=817687&rnumber=560912" <?php $thisId=817687; include("markHorse.php");?>>Hit The Note</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=March&id=815202&rnumber=560912" <?php $thisId=815202; include("markHorse.php");?>>March</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=St+Mary+De+Castro&id=817809&rnumber=560912" <?php $thisId=817809; include("markHorse.php");?>>St Mary De Castro</a></li>

<ol> 
</ol> 
</ol>