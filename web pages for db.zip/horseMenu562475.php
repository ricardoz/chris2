
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks766379 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=766379","http://www.racingpost.com/horses/result_home.sd?race_id=528605","http://www.racingpost.com/horses/result_home.sd?race_id=531422","http://www.racingpost.com/horses/result_home.sd?race_id=533243","http://www.racingpost.com/horses/result_home.sd?race_id=534227","http://www.racingpost.com/horses/result_home.sd?race_id=536649","http://www.racingpost.com/horses/result_home.sd?race_id=540405","http://www.racingpost.com/horses/result_home.sd?race_id=548010","http://www.racingpost.com/horses/result_home.sd?race_id=549335","http://www.racingpost.com/horses/result_home.sd?race_id=551368","http://www.racingpost.com/horses/result_home.sd?race_id=560711","http://www.racingpost.com/horses/result_home.sd?race_id=561303");

var horseLinks757908 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=757908","http://www.racingpost.com/horses/result_home.sd?race_id=504305","http://www.racingpost.com/horses/result_home.sd?race_id=505606","http://www.racingpost.com/horses/result_home.sd?race_id=507585","http://www.racingpost.com/horses/result_home.sd?race_id=509598","http://www.racingpost.com/horses/result_home.sd?race_id=513082","http://www.racingpost.com/horses/result_home.sd?race_id=528329","http://www.racingpost.com/horses/result_home.sd?race_id=529723","http://www.racingpost.com/horses/result_home.sd?race_id=533024","http://www.racingpost.com/horses/result_home.sd?race_id=534146","http://www.racingpost.com/horses/result_home.sd?race_id=535714","http://www.racingpost.com/horses/result_home.sd?race_id=536523","http://www.racingpost.com/horses/result_home.sd?race_id=537962","http://www.racingpost.com/horses/result_home.sd?race_id=543569","http://www.racingpost.com/horses/result_home.sd?race_id=553741","http://www.racingpost.com/horses/result_home.sd?race_id=554991","http://www.racingpost.com/horses/result_home.sd?race_id=560578","http://www.racingpost.com/horses/result_home.sd?race_id=561303");

var horseLinks733715 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=733715","http://www.racingpost.com/horses/result_home.sd?race_id=486116","http://www.racingpost.com/horses/result_home.sd?race_id=487203","http://www.racingpost.com/horses/result_home.sd?race_id=488424","http://www.racingpost.com/horses/result_home.sd?race_id=503642","http://www.racingpost.com/horses/result_home.sd?race_id=509246","http://www.racingpost.com/horses/result_home.sd?race_id=512144","http://www.racingpost.com/horses/result_home.sd?race_id=513097","http://www.racingpost.com/horses/result_home.sd?race_id=513295","http://www.racingpost.com/horses/result_home.sd?race_id=515013","http://www.racingpost.com/horses/result_home.sd?race_id=527788","http://www.racingpost.com/horses/result_home.sd?race_id=531222","http://www.racingpost.com/horses/result_home.sd?race_id=534101","http://www.racingpost.com/horses/result_home.sd?race_id=535012","http://www.racingpost.com/horses/result_home.sd?race_id=537961","http://www.racingpost.com/horses/result_home.sd?race_id=538389","http://www.racingpost.com/horses/result_home.sd?race_id=547656","http://www.racingpost.com/horses/result_home.sd?race_id=551154","http://www.racingpost.com/horses/result_home.sd?race_id=555069","http://www.racingpost.com/horses/result_home.sd?race_id=556905");

var horseLinks765612 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=765612","http://www.racingpost.com/horses/result_home.sd?race_id=513472","http://www.racingpost.com/horses/result_home.sd?race_id=514502","http://www.racingpost.com/horses/result_home.sd?race_id=527036","http://www.racingpost.com/horses/result_home.sd?race_id=527794","http://www.racingpost.com/horses/result_home.sd?race_id=533025","http://www.racingpost.com/horses/result_home.sd?race_id=535693","http://www.racingpost.com/horses/result_home.sd?race_id=537267","http://www.racingpost.com/horses/result_home.sd?race_id=560015","http://www.racingpost.com/horses/result_home.sd?race_id=561346");

var horseLinks737132 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=737132","http://www.racingpost.com/horses/result_home.sd?race_id=485098","http://www.racingpost.com/horses/result_home.sd?race_id=486552","http://www.racingpost.com/horses/result_home.sd?race_id=487650","http://www.racingpost.com/horses/result_home.sd?race_id=489413","http://www.racingpost.com/horses/result_home.sd?race_id=490485","http://www.racingpost.com/horses/result_home.sd?race_id=491264","http://www.racingpost.com/horses/result_home.sd?race_id=502301","http://www.racingpost.com/horses/result_home.sd?race_id=503666","http://www.racingpost.com/horses/result_home.sd?race_id=507054","http://www.racingpost.com/horses/result_home.sd?race_id=511304","http://www.racingpost.com/horses/result_home.sd?race_id=513121","http://www.racingpost.com/horses/result_home.sd?race_id=514544","http://www.racingpost.com/horses/result_home.sd?race_id=515261","http://www.racingpost.com/horses/result_home.sd?race_id=527653","http://www.racingpost.com/horses/result_home.sd?race_id=530445","http://www.racingpost.com/horses/result_home.sd?race_id=533054","http://www.racingpost.com/horses/result_home.sd?race_id=535648","http://www.racingpost.com/horses/result_home.sd?race_id=537543","http://www.racingpost.com/horses/result_home.sd?race_id=552442","http://www.racingpost.com/horses/result_home.sd?race_id=555109","http://www.racingpost.com/horses/result_home.sd?race_id=556935","http://www.racingpost.com/horses/result_home.sd?race_id=560015","http://www.racingpost.com/horses/result_home.sd?race_id=561288");

var horseLinks689647 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=689647","http://www.racingpost.com/horses/result_home.sd?race_id=441969","http://www.racingpost.com/horses/result_home.sd?race_id=455222","http://www.racingpost.com/horses/result_home.sd?race_id=456743","http://www.racingpost.com/horses/result_home.sd?race_id=461508","http://www.racingpost.com/horses/result_home.sd?race_id=466788","http://www.racingpost.com/horses/result_home.sd?race_id=479120","http://www.racingpost.com/horses/result_home.sd?race_id=481116","http://www.racingpost.com/horses/result_home.sd?race_id=482567","http://www.racingpost.com/horses/result_home.sd?race_id=484449","http://www.racingpost.com/horses/result_home.sd?race_id=485566","http://www.racingpost.com/horses/result_home.sd?race_id=486032","http://www.racingpost.com/horses/result_home.sd?race_id=486923","http://www.racingpost.com/horses/result_home.sd?race_id=488392","http://www.racingpost.com/horses/result_home.sd?race_id=489538","http://www.racingpost.com/horses/result_home.sd?race_id=491211","http://www.racingpost.com/horses/result_home.sd?race_id=492017","http://www.racingpost.com/horses/result_home.sd?race_id=502340","http://www.racingpost.com/horses/result_home.sd?race_id=504461","http://www.racingpost.com/horses/result_home.sd?race_id=506325","http://www.racingpost.com/horses/result_home.sd?race_id=507622","http://www.racingpost.com/horses/result_home.sd?race_id=509593","http://www.racingpost.com/horses/result_home.sd?race_id=510490","http://www.racingpost.com/horses/result_home.sd?race_id=511612","http://www.racingpost.com/horses/result_home.sd?race_id=512276","http://www.racingpost.com/horses/result_home.sd?race_id=512655","http://www.racingpost.com/horses/result_home.sd?race_id=514207","http://www.racingpost.com/horses/result_home.sd?race_id=515261","http://www.racingpost.com/horses/result_home.sd?race_id=527653","http://www.racingpost.com/horses/result_home.sd?race_id=529652","http://www.racingpost.com/horses/result_home.sd?race_id=531930","http://www.racingpost.com/horses/result_home.sd?race_id=533054","http://www.racingpost.com/horses/result_home.sd?race_id=535648","http://www.racingpost.com/horses/result_home.sd?race_id=536163","http://www.racingpost.com/horses/result_home.sd?race_id=537161","http://www.racingpost.com/horses/result_home.sd?race_id=537543","http://www.racingpost.com/horses/result_home.sd?race_id=540121","http://www.racingpost.com/horses/result_home.sd?race_id=540935","http://www.racingpost.com/horses/result_home.sd?race_id=551683","http://www.racingpost.com/horses/result_home.sd?race_id=553140","http://www.racingpost.com/horses/result_home.sd?race_id=555069","http://www.racingpost.com/horses/result_home.sd?race_id=555776","http://www.racingpost.com/horses/result_home.sd?race_id=557571");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=562475" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=562475" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Sandagiyr&id=766379&rnumber=562475" <?php $thisId=766379; include("markHorse.php");?>>Sandagiyr</a></li>

<ol> 
<li><a href="horse.php?name=Sandagiyr&id=766379&rnumber=562475&url=/horses/result_home.sd?race_id=561303" id='h2hFormLink'>Trade Storm </a></li> 
</ol> 
<li> <a href="horse.php?name=Trade+Storm&id=757908&rnumber=562475" <?php $thisId=757908; include("markHorse.php");?>>Trade Storm</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Black+Spirit&id=733715&rnumber=562475" <?php $thisId=733715; include("markHorse.php");?>>Black Spirit</a></li>

<ol> 
<li><a href="horse.php?name=Black+Spirit&id=733715&rnumber=562475&url=/horses/result_home.sd?race_id=555069" id='h2hFormLink'>Resurge </a></li> 
</ol> 
<li> <a href="horse.php?name=Specific+Gravity&id=765612&rnumber=562475" <?php $thisId=765612; include("markHorse.php");?>>Specific Gravity</a></li>

<ol> 
<li><a href="horse.php?name=Specific+Gravity&id=765612&rnumber=562475&url=/horses/result_home.sd?race_id=560015" id='h2hFormLink'>Spanish Duke </a></li> 
</ol> 
<li> <a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475" <?php $thisId=737132; include("markHorse.php");?>>Spanish Duke</a></li>

<ol> 
<li><a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475&url=/horses/result_home.sd?race_id=515261" id='h2hFormLink'>Resurge </a></li> 
<li><a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475&url=/horses/result_home.sd?race_id=527653" id='h2hFormLink'>Resurge </a></li> 
<li><a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475&url=/horses/result_home.sd?race_id=533054" id='h2hFormLink'>Resurge </a></li> 
<li><a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475&url=/horses/result_home.sd?race_id=535648" id='h2hFormLink'>Resurge </a></li> 
<li><a href="horse.php?name=Spanish+Duke&id=737132&rnumber=562475&url=/horses/result_home.sd?race_id=537543" id='h2hFormLink'>Resurge </a></li> 
</ol> 
<li> <a href="horse.php?name=Resurge&id=689647&rnumber=562475" <?php $thisId=689647; include("markHorse.php");?>>Resurge</a></li>

<ol> 
</ol> 
</ol>