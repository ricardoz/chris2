
<iframe id='hiddenFrame'

name='hiddenFrame'

src='hiddenFrame.html'></iframe>

<script type='text/javascript'>

var horseLinks780413 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=780413","http://www.racingpost.com/horses/result_home.sd?race_id=531518","http://www.racingpost.com/horses/result_home.sd?race_id=543852","http://www.racingpost.com/horses/result_home.sd?race_id=547087","http://www.racingpost.com/horses/result_home.sd?race_id=548254","http://www.racingpost.com/horses/result_home.sd?race_id=552695","http://www.racingpost.com/horses/result_home.sd?race_id=555908","http://www.racingpost.com/horses/result_home.sd?race_id=558769","http://www.racingpost.com/horses/result_home.sd?race_id=560165");

var horseLinks746938 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=746938","http://www.racingpost.com/horses/result_home.sd?race_id=493459","http://www.racingpost.com/horses/result_home.sd?race_id=497593","http://www.racingpost.com/horses/result_home.sd?race_id=546956","http://www.racingpost.com/horses/result_home.sd?race_id=547807","http://www.racingpost.com/horses/result_home.sd?race_id=549165","http://www.racingpost.com/horses/result_home.sd?race_id=551245","http://www.racingpost.com/horses/result_home.sd?race_id=553830","http://www.racingpost.com/horses/result_home.sd?race_id=556460","http://www.racingpost.com/horses/result_home.sd?race_id=558791","http://www.racingpost.com/horses/result_home.sd?race_id=559781");

var horseLinks705182 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=705182","http://www.racingpost.com/horses/result_home.sd?race_id=457058","http://www.racingpost.com/horses/result_home.sd?race_id=467868","http://www.racingpost.com/horses/result_home.sd?race_id=470242","http://www.racingpost.com/horses/result_home.sd?race_id=473470","http://www.racingpost.com/horses/result_home.sd?race_id=491355","http://www.racingpost.com/horses/result_home.sd?race_id=544702","http://www.racingpost.com/horses/result_home.sd?race_id=547355","http://www.racingpost.com/horses/result_home.sd?race_id=548552","http://www.racingpost.com/horses/result_home.sd?race_id=549579","http://www.racingpost.com/horses/result_home.sd?race_id=551243","http://www.racingpost.com/horses/result_home.sd?race_id=555880","http://www.racingpost.com/horses/result_home.sd?race_id=557009");

var horseLinks799215 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=799215","http://www.racingpost.com/horses/result_home.sd?race_id=551253","http://www.racingpost.com/horses/result_home.sd?race_id=554500");

var horseLinks745358 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=745358","http://www.racingpost.com/horses/result_home.sd?race_id=493459","http://www.racingpost.com/horses/result_home.sd?race_id=497145","http://www.racingpost.com/horses/result_home.sd?race_id=500620","http://www.racingpost.com/horses/result_home.sd?race_id=503688","http://www.racingpost.com/horses/result_home.sd?race_id=516567","http://www.racingpost.com/horses/result_home.sd?race_id=522503","http://www.racingpost.com/horses/result_home.sd?race_id=525551","http://www.racingpost.com/horses/result_home.sd?race_id=528457","http://www.racingpost.com/horses/result_home.sd?race_id=540968","http://www.racingpost.com/horses/result_home.sd?race_id=541781","http://www.racingpost.com/horses/result_home.sd?race_id=543181","http://www.racingpost.com/horses/result_home.sd?race_id=543988","http://www.racingpost.com/horses/result_home.sd?race_id=560822");

var horseLinks760434 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=760434","http://www.racingpost.com/horses/result_home.sd?race_id=509524","http://www.racingpost.com/horses/result_home.sd?race_id=518413","http://www.racingpost.com/horses/result_home.sd?race_id=522111","http://www.racingpost.com/horses/result_home.sd?race_id=524254","http://www.racingpost.com/horses/result_home.sd?race_id=549062","http://www.racingpost.com/horses/result_home.sd?race_id=550042","http://www.racingpost.com/horses/result_home.sd?race_id=551242","http://www.racingpost.com/horses/result_home.sd?race_id=554488","http://www.racingpost.com/horses/result_home.sd?race_id=555811","http://www.racingpost.com/horses/result_home.sd?race_id=558206","http://www.racingpost.com/horses/result_home.sd?race_id=559752","http://www.racingpost.com/horses/result_home.sd?race_id=560178");

var horseLinks802795 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=802795","http://www.racingpost.com/horses/result_home.sd?race_id=546530","http://www.racingpost.com/horses/result_home.sd?race_id=547723","http://www.racingpost.com/horses/result_home.sd?race_id=551866","http://www.racingpost.com/horses/result_home.sd?race_id=553881","http://www.racingpost.com/horses/result_home.sd?race_id=556460","http://www.racingpost.com/horses/result_home.sd?race_id=559750");

var horseLinks796124 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=796124","http://www.racingpost.com/horses/result_home.sd?race_id=540158","http://www.racingpost.com/horses/result_home.sd?race_id=556470","http://www.racingpost.com/horses/result_home.sd?race_id=558768","http://www.racingpost.com/horses/result_home.sd?race_id=560176");

var horseLinks778093 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=778093","http://www.racingpost.com/horses/result_home.sd?race_id=525065","http://www.racingpost.com/horses/result_home.sd?race_id=529183","http://www.racingpost.com/horses/result_home.sd?race_id=530485","http://www.racingpost.com/horses/result_home.sd?race_id=533675","http://www.racingpost.com/horses/result_home.sd?race_id=549165","http://www.racingpost.com/horses/result_home.sd?race_id=550635","http://www.racingpost.com/horses/result_home.sd?race_id=553269","http://www.racingpost.com/horses/result_home.sd?race_id=555889");

var horseLinks813146 =new Array("http://www.racingpost.com/horses/horse_home.sd?horse_id=813146","http://www.racingpost.com/horses/result_home.sd?race_id=555862","http://www.racingpost.com/horses/result_home.sd?race_id=558765","http://www.racingpost.com/horses/result_home.sd?race_id=560824");

</script>

<br/><a href ="today.php" id = "raceLinkInHorseMenu">Site Home</a><br/>

<a href ="race.php?rnumber=561052" id = "raceLinkInHorseMenu">Race Home</a><br/>

<a href ="allHorses.php?rnumber=561052" id = "raceLinkInHorseMenu">All Horses</a>

<br>
<ol type ="1" id='horseInRaceList'><li> <a href="horse.php?name=Latest+Trend&id=780413&rnumber=561052" <?php $thisId=780413; include("markHorse.php");?>>Latest Trend</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Robbie&id=746938&rnumber=561052" <?php $thisId=746938; include("markHorse.php");?>>Robbie</a></li>

<ol> 
<li><a href="horse.php?name=Robbie&id=746938&rnumber=561052&url=/horses/result_home.sd?race_id=493459" id='h2hFormLink'>Bridlingtonbygones </a></li> 
<li><a href="horse.php?name=Robbie&id=746938&rnumber=561052&url=/horses/result_home.sd?race_id=556460" id='h2hFormLink'>I'm A Gangster </a></li> 
<li><a href="horse.php?name=Robbie&id=746938&rnumber=561052&url=/horses/result_home.sd?race_id=549165" id='h2hFormLink'>Tiradia </a></li> 
</ol> 
<li> <a href="horse.php?name=Ballybanks&id=705182&rnumber=561052" <?php $thisId=705182; include("markHorse.php");?>>Ballybanks</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Bremer+Bay&id=799215&rnumber=561052" <?php $thisId=799215; include("markHorse.php");?>>Bremer Bay</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Bridlingtonbygones&id=745358&rnumber=561052" <?php $thisId=745358; include("markHorse.php");?>>Bridlingtonbygones</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=How's+D+Strawboss&id=760434&rnumber=561052" <?php $thisId=760434; include("markHorse.php");?>>How's D Strawboss</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=I'm+A+Gangster&id=802795&rnumber=561052" <?php $thisId=802795; include("markHorse.php");?>>I'm A Gangster</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Special+Boru&id=796124&rnumber=561052" <?php $thisId=796124; include("markHorse.php");?>>Special Boru</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tiradia&id=778093&rnumber=561052" <?php $thisId=778093; include("markHorse.php");?>>Tiradia</a></li>

<ol> 
</ol> 
<li> <a href="horse.php?name=Tennessee+Bird&id=813146&rnumber=561052" <?php $thisId=813146; include("markHorse.php");?>>Tennessee Bird</a></li>

<ol> 
</ol> 
</ol>